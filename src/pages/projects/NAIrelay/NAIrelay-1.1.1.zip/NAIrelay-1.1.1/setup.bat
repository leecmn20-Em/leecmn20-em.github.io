@echo off
setlocal

cd /d "%~dp0"
set "NAIRELAY_VENV_PYTHON=%~dp0.venv\Scripts\python.exe"

if exist "%NAIRELAY_VENV_PYTHON%" goto check_venv

echo [NAIrelay] Creating virtual environment...
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; raise SystemExit(sys.version_info < (3, 10))" >nul 2>&1
    if errorlevel 1 goto python_version_error
    py -3 -m venv "%~dp0.venv"
) else (
    where python >nul 2>&1
    if errorlevel 1 goto python_missing
    python -c "import sys; raise SystemExit(sys.version_info < (3, 10))" >nul 2>&1
    if errorlevel 1 goto python_version_error
    python -m venv "%~dp0.venv"
)

if errorlevel 1 goto venv_error

:check_venv
"%NAIRELAY_VENV_PYTHON%" -c "import sys; raise SystemExit(sys.version_info < (3, 10))" >nul 2>&1
if errorlevel 1 goto python_version_error

echo [NAIrelay] Installing dependencies...
"%NAIRELAY_VENV_PYTHON%" -m pip install -r "%~dp0requirements-windows.txt"
if errorlevel 1 goto install_error

echo.
echo [NAIrelay] Setup complete.
echo [NAIrelay] Run nairelay.bat to start the server.
pause
exit /b 0

:python_missing
echo [NAIrelay] Python was not found. Install Python 3.10 or later first.
goto failed

:python_version_error
echo [NAIrelay] Python 3.10 or later is required.
goto failed

:venv_error
echo [NAIrelay] Failed to create the virtual environment.
goto failed

:install_error
echo [NAIrelay] Failed to install the required packages.

:failed
echo.
pause
exit /b 1
