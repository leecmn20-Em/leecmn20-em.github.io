@echo off
setlocal

cd /d "%~dp0"
set "NAIRELAY_PYTHON=%~dp0.venv\Scripts\python.exe"
set "NAIRELAY_PYTHONW=%~dp0.venv\Scripts\pythonw.exe"

if not exist "%NAIRELAY_PYTHON%" (
    echo [NAIrelay] Virtual environment not found:
    echo %NAIRELAY_PYTHON%
    echo.
    echo Create .venv and install the project dependencies first.
    pause
    exit /b 1
)

if not exist "%NAIRELAY_PYTHONW%" (
    echo [NAIrelay] Windowless Python launcher not found:
    echo %NAIRELAY_PYTHONW%
    echo.
    pause
    exit /b 1
)

"%NAIRELAY_PYTHON%" -c "import fastapi, httpx, pydantic, pystray, uvicorn; from dotenv import load_dotenv; from PIL import Image" >nul 2>&1
if errorlevel 1 (
    echo [NAIrelay] Required packages are not installed.
    echo.
    echo Run:
    echo "%NAIRELAY_PYTHON%" -m pip install -r "%~dp0requirements-windows.txt"
    echo.
    pause
    exit /b 1
)

start "" "%NAIRELAY_PYTHONW%" "%~dp0src\tray.py"

endlocal & exit /b 0
