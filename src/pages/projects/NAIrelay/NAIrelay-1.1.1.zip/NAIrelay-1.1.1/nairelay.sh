#!/usr/bin/env sh

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
NAIRELAY_PYTHON="$SCRIPT_DIR/.venv/bin/python"

if [ ! -x "$NAIRELAY_PYTHON" ]; then
    printf '%s\n' \
        '[NAIrelay] Virtual environment not found:' \
        "$NAIRELAY_PYTHON" \
        '' \
        '[NAIrelay] Create .venv and install the project dependencies first.'
    exit 1
fi

printf '%s\n' \
    '[NAIrelay] Starting server...' \
    '[NAIrelay] Press Ctrl+C to stop.' \
    ''

"$NAIRELAY_PYTHON" "$SCRIPT_DIR/src/main.py"
NAIRELAY_EXIT_CODE=$?

if [ "$NAIRELAY_EXIT_CODE" -ne 0 ]; then
    printf '\n[NAIrelay] Server stopped with exit code %s.\n' "$NAIRELAY_EXIT_CODE"
fi

exit "$NAIRELAY_EXIT_CODE"
