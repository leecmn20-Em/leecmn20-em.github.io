# NAIrelay

## 설치

Python 3.10 이상이 필요합니다.
작동에 필요한 Python 패키지는 requirements.txt 및 requirements-windows.txt에서 확인할 수 있습니다.
아래 설정 파일은 `.venv` 가상환경을 생성하고 운영체제에 맞는 requirements를 설치합니다. 기존 `.venv`가 있으면 그대로 사용하면서 필요한 패키지를 다시 확인합니다.

### Windows

`setup.bat`을 더블 클릭합니다.

### Linux / Android Ubuntu

```sh
sh setup.sh
```

## 실행

### Windows 배치 파일

`nairelay.bat`을 더블 클릭하여 NAIrelay 서버와 트레이 아이콘을 실행합니다.

### Linux / Android Ubuntu 셸 파일

```sh
./nairelay.sh
```

셸에서는 트레이 아이콘 없이 현재 터미널에서 서버가 실행됩니다. 기본 관리자 페이지는 다음 주소에서 열 수 있습니다.

```text
http://127.0.0.1:8000/admin
```

서버를 종료하려면 실행 중인 터미널에서 `Ctrl+C`를 누릅니다.

## 최초 설정

관리자 페이지의 `Config`에서 NovelAI token과 Relay access key를 저장합니다.
NovelAI token에는 본인의 NovelAI API 키를 저장합니다.
Relay access key는 알 수 없는 출처의 호출을 막기 위한 2차 비밀번호로, 원하는 값으로 설정 후 URL 작성 시에 같은 값을 이용합니다.

## 이미지 요청 캐시

캐시 키는 URL에 직접 입력한 필드만 사용합니다. 접근 키 `key`는 제외하고, 따옴표 제거와 타입 변환을 거친 값을 필드 이름순으로 정렬한 JSON으로 만들어 SHA-256 해시를 계산합니다. 생략한 필드에 적용되는 기본값은 해시에 들어가지 않습니다.

- `?prompt=cat&steps=28`과 `?steps="28"&prompt="cat"`은 같은 캐시를 사용합니다.
- `?prompt=cat`과 `?prompt=cat&steps=28`은 현재 steps 기본값이 28이어도 서로 다른 캐시를 사용합니다.
- `style`, `vibe`, `negative_prompt`, `char1_uc`~`char6_uc`의 빈 값은 생략과 동일하게 취급합니다. `&style=`, `&style=""`, style 생략은 같은 캐시를 사용합니다.
- 숫자·불리언·선택형 필드와 캐릭터 프롬프트 등에서 빈 값이 허용되지 않는 경우에는 기존처럼 요청 검증 오류가 발생합니다.
- 명시한 `style`·`vibe` 참조와 `rule` 값은 해시에 포함됩니다. 프리셋 내용, 활성 규칙 목록, 최종 조립된 프롬프트는 포함하지 않으므로 해당 설정을 수정해도 같은 요청의 캐시는 유지됩니다.

캐시는 `favorite` 폴더를 먼저 조회하고, 다음으로 `images` 폴더를 조회합니다. 캐시가 없을 때 현재 설정으로 이미지를 생성합니다.

요청 캐시 버전 2부터 이 기준을 사용합니다. 이전 캐시는 URL에 실제로 입력한 필드 목록을 알 수 없어 자동 변환하거나 재사용하지 않으며, 기존 이미지 파일은 그대로 보존됩니다.
