#!/usr/bin/env sh

set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
NAIRELAY_VENV_PYTHON="$SCRIPT_DIR/.venv/bin/python"

supports_nairelay() {
    "$1" -c 'import sys; raise SystemExit(sys.version_info < (3, 10))' >/dev/null 2>&1
}

if [ ! -x "$NAIRELAY_VENV_PYTHON" ]; then
    NAIRELAY_SETUP_PYTHON=""
    for candidate in python3 python; do
        if command -v "$candidate" >/dev/null 2>&1 && supports_nairelay "$candidate"; then
            NAIRELAY_SETUP_PYTHON=$candidate
            break
        fi
    done

    if [ -z "$NAIRELAY_SETUP_PYTHON" ]; then
        printf '%s\n' '[NAIrelay] Python 3.10 or later was not found.'
        exit 1
    fi

    printf '%s\n' '[NAIrelay] Creating virtual environment...'
    if ! "$NAIRELAY_SETUP_PYTHON" -m venv "$SCRIPT_DIR/.venv"; then
        printf '%s\n' \
            '[NAIrelay] Failed to create the virtual environment.' \
            '[NAIrelay] On Ubuntu, install python3-venv and try again.'
        exit 1
    fi
fi

if ! supports_nairelay "$NAIRELAY_VENV_PYTHON"; then
    printf '%s\n' '[NAIrelay] The existing .venv does not use Python 3.10 or later.'
    exit 1
fi

printf '%s\n' '[NAIrelay] Installing dependencies...'
if ! "$NAIRELAY_VENV_PYTHON" -m pip install -r "$SCRIPT_DIR/requirements.txt"; then
    printf '%s\n' '[NAIrelay] Failed to install the required packages.'
    exit 1
fi

chmod +x "$SCRIPT_DIR/nairelay.sh" 2>/dev/null || true

printf '%s\n' \
    '' \
    '[NAIrelay] Setup complete.' \
    '[NAIrelay] Run ./nairelay.sh to start the server.'
