from collections.abc import Iterable
from typing import Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    PrivateAttr,
    field_validator,
    model_validator,
)


ModelName = Literal[
    "naid5f",
    "naid5c",
    "naid4.5f",
    "naid4.5c",
    "naid4f",
    "naid4c",
    "naid3",
]
SamplerName = Literal[
    "k_euler",
    "k_euler_ancestral",
    "k_dpmpp_2m",
    "k_dpmpp_2s_ancestral",
    "k_dpmpp_sde",
    "k_dpmpp_2m_sde",
    "ddim_v3",
]
SchedulerName = Literal["karras", "native", "exponential", "polyexponential"]
RatingName = Literal["general", "sensitive", "questionable", "explicit"]
UCPresetName = Literal["heavy", "light", "human_focus", "furry_focus", "none"]


class GenerationRequest(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
        str_strip_whitespace=True,
    )

    _cache_fields: frozenset[str] = PrivateAttr(default_factory=frozenset)

    def model_post_init(self, context: object) -> None:
        # Capture inputs before model validators assign derived defaults.
        self.set_cache_fields(self.model_fields_set)

    def set_cache_fields(self, fields: Iterable[str]) -> None:
        # FastAPI supplies defaults to query models; the route supplies the
        # actual URL field names instead of relying on model_fields_set.
        self._cache_fields = frozenset(fields).intersection(type(self).model_fields)

    def cache_request_data(self) -> dict[str, object]:
        data = self.model_dump(mode="json", include=self._cache_fields)
        # Maintain this list when adding fields: if an empty input has the
        # same generation behavior as omission, add the field here so both
        # requests share a cache key. This is not inferred from Field defaults.
        # Values are already normalized; extend the filtering below if a new
        # field normalizes empty input to something other than "" or None.
        empty_as_omitted = {
            "style",
            "vibe",
            "negative_prompt",
            *(f"char{index}_uc" for index in range(1, 7)),
        }
        return {
            name: value
            for name, value in data.items()
            if not (name in empty_as_omitted and value in ("", None))
        }

    @field_validator("*", mode="before")
    @classmethod
    def strip_optional_quotes(cls, value: object) -> object:
        if (
            isinstance(value, str)
            and len(value) >= 2
            and value[0] == value[-1]
            and value[0] in {'"', "'"}
        ):
            return value[1:-1]
        return value

    @field_validator(
        "char1_uc",
        "char2_uc",
        "char3_uc",
        "char4_uc",
        "char5_uc",
        "char6_uc",
        mode="after",
    )
    @classmethod
    def normalize_empty_character_uc(cls, value: str | None) -> str | None:
        if value is not None and not value.strip(" ,"):
            return None
        return value

    @model_validator(mode="after")
    def apply_model_specific_uc_default(self) -> "GenerationRequest":
        furry_models = {"naid5f", "naid5c", "naid4.5f", "naid4.5c"}

        if self.furry and self.model not in furry_models:
            raise ValueError("Furry mode is only supported by NAI V4.5 or V5 models.")

        if self.uc_preset == "furry_focus" and self.model not in furry_models:
            raise ValueError(
                "The furry_focus UC preset requires an NAI V4.5 or V5 model."
            )

        if self.uc_preset is None:
            if self.furry:
                self.uc_preset = "furry_focus"
            elif self.model in {"naid4f", "naid4c"}:
                self.uc_preset = "heavy"
            else:
                self.uc_preset = "human_focus"
        return self

    @model_validator(mode="after")
    def validate_character_prompts(self) -> "GenerationRequest":
        character_gap_found = False
        has_characters = False

        for index in range(1, 7):
            prompt = getattr(self, f"char{index}")
            negative_prompt = getattr(self, f"char{index}_uc")

            if prompt is None:
                character_gap_found = True
                if negative_prompt:
                    raise ValueError(
                        f"char{index}_uc requires char{index}."
                    )
                continue

            if character_gap_found:
                raise ValueError(
                    "Character prompts must be numbered consecutively from char1."
                )
            has_characters = True

        if has_characters and self.model == "naid3":
            raise ValueError(
                "Character prompts are only supported by NAI V4 or later models."
            )
        return self

    def character_prompts(self) -> list[tuple[str, str]]:
        characters: list[tuple[str, str]] = []
        for index in range(1, 7):
            prompt = getattr(self, f"char{index}")
            if prompt is None:
                break
            characters.append((prompt, getattr(self, f"char{index}_uc") or ""))
        return characters

    # New URL fields are automatically hashed only when explicitly supplied.
    # If a new field treats empty input as omission, also update
    # cache_request_data() above; defining the field/default alone is not enough.
    prompt: str = Field(
        min_length=1,
        max_length=10_000,
        description="Prompt used to generate the image.",
    )
    key: str | None = Field(
        default=None,
        max_length=32,
        exclude=True,
        repr=False,
        description="Local NAIrelay access key; excluded from the image cache key.",
    )
    style: str | None = Field(
        default=None,
        max_length=160,
        description=(
            "Optional style preset reference in 'file_id:preset_name' format; "
            "empty uses the selected default and 'None' disables styles; "
            "the supplied reference is included in the image cache key."
        ),
    )
    vibe: str | None = Field(
        default=None,
        max_length=160,
        description=(
            "Optional Vibe preset reference in 'file_id:preset_name' format; "
            "the supplied reference, not its contents, "
            "is included in the image cache key."
        ),
    )
    rule: bool = Field(
        default=True,
        description=(
            "Apply every rule enabled in the local Rules page; "
            "included in the image cache key when explicitly supplied."
        ),
    )
    negative_prompt: str = Field(
        default="",
        max_length=10_000,
        description="Prompt describing elements to avoid.",
    )
    char1: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 1.",
    )
    char1_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 1.",
    )
    char2: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 2.",
    )
    char2_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 2.",
    )
    char3: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 3.",
    )
    char3_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 3.",
    )
    char4: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 4.",
    )
    char4_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 4.",
    )
    char5: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 5.",
    )
    char5_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 5.",
    )
    char6: str | None = Field(
        default=None,
        min_length=1,
        max_length=10_000,
        description="Positive prompt for character 6.",
    )
    char6_uc: str | None = Field(
        default=None,
        max_length=10_000,
        description="Negative prompt for character 6.",
    )
    width: int = Field(
        default=1024,
        ge=64,
        le=2048,
        multiple_of=64,
        description="Output width in pixels.",
    )
    height: int = Field(
        default=1024,
        ge=64,
        le=2048,
        multiple_of=64,
        description="Output height in pixels.",
    )
    seed: int | None = Field(
        default=None,
        ge=0,
        le=4_294_967_295,
        description="Optional seed used to reproduce a generation.",
    )
    model: ModelName = Field(
        default="naid4.5f",
        description="NovelAI image model preset.",
    )
    steps: int = Field(
        default=28,
        ge=1,
        le=150,
        description="Number of sampling steps.",
    )
    cfg_scale: float = Field(
        default=7.0,
        ge=0.0,
        le=30.0,
        description="How strongly the image follows the prompt.",
    )
    cfg_rescale: float = Field(
        default=0.4,
        ge=0.0,
        le=1.0,
        description="CFG saturation correction strength.",
    )
    sampler: SamplerName = Field(
        default="k_euler_ancestral",
        description="Sampling algorithm.",
    )
    scheduler: SchedulerName = Field(
        default="karras",
        description="Noise schedule used during sampling.",
    )
    deliberate_euler_ancestral_bug: bool = Field(
        default=False,
        description="Use NovelAI's legacy Euler Ancestral compatibility behavior.",
    )
    var_plus: bool = Field(
        default=False,
        description="Enable the VAR+ skip-CFG behavior.",
    )
    quality_tags: bool = Field(
        default=True,
        description="Append the recommended quality tags for the selected NAI model.",
    )
    furry: bool = Field(
        default=False,
        description="Use the NAI V4.5/V5 furry dataset and its default UC preset.",
    )
    rating: RatingName = Field(
        default="sensitive",
        description="Append rating tags to the positive and negative prompts.",
    )
    uc_preset: UCPresetName | None = Field(
        default=None,
        description="Prepend a model-specific UC preset; omit for the model default.",
    )
