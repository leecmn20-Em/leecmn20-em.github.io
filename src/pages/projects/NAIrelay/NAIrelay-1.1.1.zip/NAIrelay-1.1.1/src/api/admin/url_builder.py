import html
import json
from urllib.parse import quote

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

import config
from models.generation import GenerationRequest
from .layout import render_page


router = APIRouter()

def _url_content(request: Request) -> str:
    image_url = str(request.url_for("relay_image"))
    access_key = config.NAIRELAY_ACCESS_KEY or ""
    basic_generation_url = f"{image_url}?key={quote(access_key, safe='')}"
    special_defaults = {
        "seed": "Default: random",
        "style": "Default: selected preset",
        "vibe": "Default: none",
        "rule": "Default: true (use n/false to disable)",
        "uc_preset": "Default: model-specific",
    }
    field_placeholders = {}
    for field_name, field_info in GenerationRequest.model_fields.items():
        if field_name == "key":
            continue
        if field_name in special_defaults:
            placeholder = special_defaults[field_name]
        elif field_info.is_required():
            placeholder = "Required (no default)"
        elif field_info.default is None:
            placeholder = "Default: omitted"
        elif field_info.default == "":
            placeholder = "Default: empty"
        elif isinstance(field_info.default, bool):
            placeholder = f"Default: {str(field_info.default).lower()}"
        else:
            placeholder = f"Default: {field_info.default}"
        field_placeholders[field_name] = placeholder

    serialized_field_placeholders = json.dumps(
        field_placeholders,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    field_options = "".join(
        f'<option value="{html.escape(field_name, quote=True)}"></option>'
        for field_name in GenerationRequest.model_fields
        if field_name != "key"
    )
    key_notice = ""
    if not config.NAIRELAY_ACCESS_KEY:
        key_notice = (
            '<p class="notice error">Configure a relay access key before using '
            "this URL.</p>"
        )

    return f"""
<section class="panel generation-panel">
    <strong>Basic generation URL</strong>
    <div class="copy-row">
        <input
            id="basic-generation-url"
            type="text"
            value="{html.escape(basic_generation_url, quote=True)}"
            readonly
            spellcheck="false"
            aria-label="Basic generation URL"
        >
        <button id="copy-basic-generation-url" type="button">Copy</button>
    </div>
    {key_notice}
</section>
<section
    id="url-builder"
    class="panel generation-panel"
    data-image-url="{html.escape(image_url, quote=True)}"
    data-access-key="{html.escape(access_key, quote=True)}"
>
    <strong>URL builder</strong>
    <datalist id="generation-field-names">{field_options}</datalist>
    <div id="url-fields" class="url-fields"></div>
    <button id="add-url-field" class="url-add-button" type="button">Add field</button>
    <div class="url-output">
        <strong>Generated URL</strong>
        <div class="copy-row">
            <input id="generation-url" type="text" readonly spellcheck="false" aria-label="Generated URL">
            <button id="copy-generation-url" type="button">Copy</button>
            <button id="render-generation-url" type="button">Render</button>
        </div>
    </div>
    <div id="generation-preview" class="generation-preview" hidden>
        <span id="generation-preview-status">Loading image...</span>
        <img id="generation-preview-image" alt="Generated image preview" hidden>
    </div>
    <template id="url-field-template">
        <div class="url-field">
            <input
                class="url-field-name"
                type="text"
                list="generation-field-names"
                maxlength="64"
                placeholder="Field name"
                aria-label="Field name"
                autocomplete="off"
            >
            <textarea
                class="url-field-value"
                maxlength="10000"
                placeholder="Prompt or value"
                aria-label="Prompt or value"
            ></textarea>
            <button class="url-field-remove" type="button">Remove</button>
        </div>
    </template>
</section>
<script>
(() => {{
    const builder = document.getElementById("url-builder");
    const fields = document.getElementById("url-fields");
    const template = document.getElementById("url-field-template");
    const addButton = document.getElementById("add-url-field");
    const output = document.getElementById("generation-url");
    const copyButton = document.getElementById("copy-generation-url");
    const renderButton = document.getElementById("render-generation-url");
    const preview = document.getElementById("generation-preview");
    const previewStatus = document.getElementById("generation-preview-status");
    const previewImage = document.getElementById("generation-preview-image");
    const basicOutput = document.getElementById("basic-generation-url");
    const basicCopyButton = document.getElementById("copy-basic-generation-url");
    const fieldPlaceholders = {serialized_field_placeholders};
    const storageKey = "nairelay.url-builder.v1";

    const updateValuePlaceholder = (field) => {{
        const name = field.querySelector(".url-field-name").value.trim();
        const valueInput = field.querySelector(".url-field-value");
        if (!name) {{
            valueInput.placeholder = "Select or enter a field name";
            return;
        }}
        valueInput.placeholder = fieldPlaceholders[name] ?? "This field may not exist";
    }};

    const readFields = () => Array.from(fields.querySelectorAll(".url-field")).map(
        (field) => ({{
            name: field.querySelector(".url-field-name").value,
            value: field.querySelector(".url-field-value").value,
        }}),
    );

    const buildUrl = (entries) => {{
        const query = [];
        query.push(`key=${{encodeURIComponent(builder.dataset.accessKey)}}`);

        entries.forEach((entry) => {{
            const name = entry.name.trim();
            const value = entry.value;
            if (!name || !value) return;
            query.push(`${{encodeURIComponent(name)}}=${{encodeURIComponent(value)}}`);
        }});

        return `${{builder.dataset.imageUrl}}?${{query.join("&")}}`;
    }};

    const updateUrl = () => {{
        output.value = buildUrl(readFields());
    }};

    const normalizeStoredFields = (value) => {{
        if (!Array.isArray(value)) return null;
        const normalized = [];
        for (const entry of value.slice(0, 64)) {{
            if (
                !entry
                || typeof entry.name !== "string"
                || typeof entry.value !== "string"
            ) return null;
            normalized.push({{
                name: entry.name.slice(0, 64),
                value: entry.value.slice(0, 10000),
            }});
        }}
        return normalized;
    }};

    const saveState = () => {{
        try {{
            sessionStorage.setItem(storageKey, JSON.stringify({{
                fields: readFields(),
            }}));
        }} catch {{}}
    }};

    const addField = (
        name = "",
        value = "",
        shouldFocus = true,
        shouldSave = true,
    ) => {{
        const field = template.content.firstElementChild.cloneNode(true);
        field.querySelector(".url-field-name").value = name;
        field.querySelector(".url-field-value").value = value;
        updateValuePlaceholder(field);
        fields.appendChild(field);
        if (shouldFocus) {{
            field.querySelector(name ? ".url-field-value" : ".url-field-name").focus();
        }}
        updateUrl();
        if (shouldSave) saveState();
    }};

    addButton.addEventListener("click", () => addField());
    fields.addEventListener("input", (event) => {{
        if (event.target.matches(".url-field-name")) {{
            updateValuePlaceholder(event.target.closest(".url-field"));
        }}
        updateUrl();
        saveState();
    }});
    fields.addEventListener("click", (event) => {{
        const removeButton = event.target.closest(".url-field-remove");
        if (!removeButton) return;
        removeButton.closest(".url-field").remove();
        updateUrl();
        saveState();
    }});

    const attachCopyButton = (input, button) => {{
        button.addEventListener("click", async () => {{
            let copied = false;
            if (navigator.clipboard?.writeText) {{
                try {{
                    await navigator.clipboard.writeText(input.value);
                    copied = true;
                }} catch {{}}
            }}
            if (!copied) {{
                input.focus();
                input.select();
                copied = document.execCommand("copy");
                input.setSelectionRange(0, 0);
            }}
            button.textContent = copied ? "Copied" : "Copy failed";
            window.setTimeout(() => {{ button.textContent = "Copy"; }}, 1500);
        }});
    }};

    attachCopyButton(basicOutput, basicCopyButton);
    attachCopyButton(output, copyButton);

    const renderPreview = (entries) => {{
        const snapshot = entries.map((entry) => ({{ ...entry }}));
        preview.hidden = false;
        previewStatus.hidden = false;
        previewStatus.textContent = "Loading image...";
        previewImage.hidden = true;
        previewImage.removeAttribute("src");

        previewImage.onload = () => {{
            previewStatus.hidden = true;
            previewImage.hidden = false;
        }};
        previewImage.onerror = () => {{
            previewImage.hidden = true;
            previewStatus.hidden = false;
            previewStatus.textContent = "Image generation failed. Check the URL fields and server log.";
        }};
        previewImage.src = buildUrl(snapshot);
    }};

    renderButton.addEventListener("click", () => {{
        renderPreview(readFields());
    }});

    let storedState = null;
    try {{
        storedState = JSON.parse(sessionStorage.getItem(storageKey));
    }} catch {{}}

    const restoredFields = normalizeStoredFields(storedState?.fields);
    if (restoredFields === null) {{
        addField("prompt", "", false, false);
    }} else {{
        restoredFields.forEach((field) => {{
            addField(field.name, field.value, false, false);
        }});
    }}
    updateUrl();
    saveState();
}})();
</script>
"""



@router.get("/admin/url", response_class=HTMLResponse, include_in_schema=False)
def url_page(request: Request) -> HTMLResponse:
    return render_page("URL", "url", _url_content(request))

