import html


def render_vibe_tabs(active: str) -> str:
    links = (
        ("presets", "/admin/vibes/presets", "Presets"),
        ("library", "/admin/vibes/library", "Library"),
    )
    items = "".join(
        f'<a class="{"active" if key == active else ""}" '
        f'href="{html.escape(href, quote=True)}">{html.escape(label)}</a>'
        for key, href, label in links
    )
    return f'<nav class="section-tabs" aria-label="Vibe sections">{items}</nav>'
