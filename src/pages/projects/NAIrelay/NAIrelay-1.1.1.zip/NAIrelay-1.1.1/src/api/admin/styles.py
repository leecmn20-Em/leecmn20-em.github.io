import html
import json
from urllib.parse import parse_qs, quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

import config
from services.style_presets import (
    StylePreset,
    StylePresetError,
    create_preset,
    delete_preset,
    load_catalog,
    save_preset_order,
    update_preset,
)
from .layout import render_page
from .security import require_same_origin
from .style_navigation import render_style_navigation


router = APIRouter()


def _style_state(preset: StylePreset) -> dict[str, str]:
    return {
        "reference": preset.reference,
        "name": preset.name,
        "prompt": preset.prompt,
        "negative_prompt": preset.negative_prompt,
        "prompt_excludes": preset.prompt_excludes,
        "negative_prompt_excludes": preset.negative_prompt_excludes,
    }


def _default_style_state() -> dict[str, str]:
    reference = config.NAIRELAY_STYLE_PRESET or ""
    preset = load_catalog().find(reference) if reference else None
    if preset is not None:
        return {
            "reference": reference,
            "name": preset.name,
            "status": reference,
            "status_class": "ok",
        }
    if reference:
        return {
            "reference": reference,
            "name": "Missing preset",
            "status": f"Missing · {reference}",
            "status_class": "warn",
        }
    return {
        "reference": "",
        "name": "No preset",
        "status": "None",
        "status_class": "",
    }


def _wants_json(request: Request) -> bool:
    return request.headers.get("x-requested-with") == "fetch"


@router.get("/admin/styles", response_class=HTMLResponse, include_in_schema=False)
def styles_page(view: str | None = None, new: bool = False) -> HTMLResponse:
    return render_page(
        "Styles",
        "styles",
        render_style_navigation("presets")
        + _styles_content(viewed_reference=view, show_new=new),
    )


def _style_card(
    preset: StylePreset,
    *,
    editor_id: str,
    selected_reference: str,
    expanded: bool = False,
) -> str:
    reference = html.escape(preset.reference, quote=True)
    hidden = "" if expanded else " hidden"
    aria_expanded = "true" if expanded else "false"
    if preset.reference == selected_reference:
        default_action = '<span class="preset-default-badge">Default</span>'
    else:
        default_action = f"""
<form class="style-select-form" method="post" action="/admin/styles/select">
    <input type="hidden" name="reference" value="{reference}">
    <button type="submit">Use as default</button>
</form>"""

    return f"""
<section class="panel preset-card" data-reference="{reference}">
    <div class="preset-card-header">
        <button class="preset-card-toggle" type="button" aria-expanded="{aria_expanded}" aria-controls="{editor_id}">
            <span class="preset-card-identity">
                <strong>{html.escape(preset.name)}</strong>
                <code>{reference}</code>
            </span>
        </button>
        <div class="preset-card-controls">
            <div class="preset-card-default-action">{default_action}</div>
            <form class="preset-delete-form" method="post" action="/admin/styles/delete">
                <input type="hidden" name="reference" value="{reference}">
                <button class="danger" type="submit">Delete</button>
            </form>
            <div class="preset-order-buttons" aria-label="Reorder {html.escape(preset.name, quote=True)}">
                <button type="button" class="preset-move-button" data-direction="-1" aria-label="Move {html.escape(preset.name, quote=True)} up">↑</button>
                <button type="button" class="preset-move-button" data-direction="1" aria-label="Move {html.escape(preset.name, quote=True)} down">↓</button>
            </div>
            <button type="button" class="preset-drag-handle" draggable="true" aria-label="Reorder {html.escape(preset.name, quote=True)}" title="Drag to reorder">⠿</button>
        </div>
    </div>
    <form id="{editor_id}" class="preset-form preset-update-form" method="post" action="/admin/styles/update"{hidden}>
        <input type="hidden" name="reference" value="{reference}">
        <label>
            Positive prompt
            <textarea name="prompt" maxlength="10000" placeholder="Prompt appended to the positive prompt">{html.escape(preset.prompt)}</textarea>
        </label>
        <label>
            Negative prompt
            <textarea name="negative_prompt" maxlength="10000" placeholder="Prompt appended to the negative prompt">{html.escape(preset.negative_prompt)}</textarea>
        </label>
        <label>
            Positive prompt exclusions
            <textarea class="exclusion-input" name="prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(preset.prompt_excludes)}</textarea>
        </label>
        <label>
            Negative prompt exclusions
            <textarea class="exclusion-input" name="negative_prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(preset.negative_prompt_excludes)}</textarea>
        </label>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit">Save preset</button></div>
    </form>
</section>"""


def _styles_content(
    message: str = "",
    error: bool = False,
    viewed_reference: str | None = None,
    show_new: bool = False,
    create_values: dict[str, str] | None = None,
) -> str:
    notice = ""
    if message:
        notice_class = "error" if error else "ok"
        notice = f'<p class="notice {notice_class}">{html.escape(message)}</p>'

    catalog = load_catalog()
    selected_reference = config.NAIRELAY_STYLE_PRESET or ""
    selected_preset = catalog.find(selected_reference) if selected_reference else None

    if selected_preset is not None:
        selected_name = selected_preset.name
        selected_status = selected_preset.reference
        selected_class = "ok"
    elif selected_reference:
        selected_name = "Missing preset"
        selected_status = f"Missing — {selected_reference}"
        selected_class = "warn"
    else:
        selected_name = "No preset"
        selected_status = "None"
        selected_class = ""

    catalog_notices = "".join(
        f'<p class="notice error">{html.escape(catalog_error)}</p>'
        for catalog_error in catalog.errors
    )

    cards = []
    for index, preset in enumerate(catalog.presets):
        cards.append(
            _style_card(
                preset,
                editor_id=f"style-preset-editor-{index}",
                selected_reference=selected_reference,
                expanded=preset.reference == viewed_reference,
            )
        )

    if not cards:
        cards.append(
            '<section class="panel preset-list-empty"><p class="empty">No style presets yet.</p></section>'
        )

    values = create_values or {}
    new_card = ""
    if show_new:
        new_card = f"""
<section class="panel preset-card new-preset-card">
    <div class="preset-card-header">
        <div class="preset-card-identity">
            <strong>New preset</strong>
            <span>Create a new style preset.</span>
        </div>
        <a class="button-link" href="/admin/styles">Cancel</a>
    </div>
    <form class="preset-form preset-create-form" method="post" action="/admin/styles/create">
        <div class="field-row">
            <label>
                File ID
                <input name="file_id" value="{html.escape(values.get('file_id', ''), quote=True)}" maxlength="64" pattern="[A-Za-z0-9_-]{{1,64}}" placeholder="custom" required>
            </label>
            <label>
                Preset name
                <input name="name" value="{html.escape(values.get('name', ''), quote=True)}" maxlength="80" placeholder="Cinematic" required>
            </label>
        </div>
        <label>
            Positive prompt
            <textarea name="prompt" maxlength="10000" placeholder="Prompt appended to the positive prompt">{html.escape(values.get('prompt', ''))}</textarea>
        </label>
        <label>
            Negative prompt
            <textarea name="negative_prompt" maxlength="10000" placeholder="Prompt appended to the negative prompt">{html.escape(values.get('negative_prompt', ''))}</textarea>
        </label>
        <label>
            Positive prompt exclusions
            <textarea class="exclusion-input" name="prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(values.get('prompt_excludes', ''))}</textarea>
        </label>
        <label>
            Negative prompt exclusions
            <textarea class="exclusion-input" name="negative_prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(values.get('negative_prompt_excludes', ''))}</textarea>
        </label>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit">Create preset</button></div>
    </form>
</section>"""

    top_action_href = "/admin/styles" if show_new else "/admin/styles?new=1"
    top_action_label = "Close new preset" if show_new else "New preset"
    clear_default = ""
    if selected_reference:
        clear_default = """
<form class="style-select-form" method="post" action="/admin/styles/select">
    <input type="hidden" name="reference" value="">
    <button type="submit">Clear default</button>
</form>"""

    return f"""
<section class="panel styles-toolbar">
    <div class="setting">
        <div class="default-style-status">
            <strong>Default style</strong>
            <span id="default-style-name" class="{selected_class}">{html.escape(selected_name)}</span>
            <code id="default-style-reference">{html.escape(selected_status)}</code>
        </div>
        <div class="styles-toolbar-actions">
            <span id="style-order-status" class="style-order-status" aria-live="polite"></span>
            <span id="style-action-status" class="style-order-status" aria-live="polite"></span>
            <div id="clear-default-action">{clear_default}</div>
            <a id="new-style-action" class="button-link" href="{top_action_href}">{top_action_label}</a>
        </div>
    </div>
</section>
{notice}
{catalog_notices}
{new_card}
<div class="preset-card-list">{''.join(cards)}</div>
<script>
(() => {{
    const list = document.querySelector(".preset-card-list");
    const orderStatus = document.getElementById("style-order-status");
    const actionStatus = document.getElementById("style-action-status");
    const defaultName = document.getElementById("default-style-name");
    const defaultReference = document.getElementById("default-style-reference");
    const clearDefaultAction = document.getElementById("clear-default-action");
    const newStyleAction = document.getElementById("new-style-action");
    let draggedCard = null;
    let orderBeforeDrag = [];
    let saving = false;
    let defaultSaving = false;

    const cards = () => Array.from(list.querySelectorAll(".preset-card[data-reference]"));
    const order = () => cards().map((card) => card.dataset.reference);
    const sameOrder = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);

    const appendHiddenInput = (form, name, value) => {{
        const input = document.createElement("input");
        input.type = "hidden";
        input.name = name;
        input.value = value;
        form.appendChild(input);
    }};

    const makeSelectForm = (reference, label) => {{
        const form = document.createElement("form");
        form.className = "style-select-form";
        form.method = "post";
        form.action = "/admin/styles/select";
        appendHiddenInput(form, "reference", reference);
        const button = document.createElement("button");
        button.type = "submit";
        button.textContent = label;
        form.appendChild(button);
        return form;
    }};

    const setFormStatus = (form, message, error = false) => {{
        const formStatus = form.querySelector(".preset-card-status");
        if (!formStatus) return;
        formStatus.textContent = message;
        formStatus.classList.toggle("error", error);
        formStatus.classList.toggle("ok", !error);
        formStatus.hidden = !message;
    }};

    const requestMutation = async (form) => {{
        const response = await fetch(form.action, {{
            method: "POST",
            headers: {{
                "Accept": "application/json",
                "X-Requested-With": "fetch",
            }},
            body: new URLSearchParams(new FormData(form)),
        }});
        let payload = {{}};
        try {{
            payload = await response.json();
        }} catch {{}}
        if (!response.ok) {{
            throw new Error(payload.detail || "Style operation failed.");
        }}
        return payload;
    }};

    const applyPresetState = (form, preset) => {{
        for (const field of ["prompt", "negative_prompt", "prompt_excludes", "negative_prompt_excludes"]) {{
            form.elements[field].value = preset[field];
        }}
    }};

    const applyDefaultState = (state) => {{
        defaultName.textContent = state.name;
        defaultName.className = state.status_class;
        defaultReference.textContent = state.status;

        cards().forEach((card) => {{
            const container = card.querySelector(".preset-card-default-action");
            container.replaceChildren();
            if (card.dataset.reference === state.reference) {{
                const badge = document.createElement("span");
                badge.className = "preset-default-badge";
                badge.textContent = "Default";
                container.appendChild(badge);
            }} else {{
                container.appendChild(makeSelectForm(card.dataset.reference, "Use as default"));
            }}
        }});

        clearDefaultAction.replaceChildren();
        if (state.reference) {{
            clearDefaultAction.appendChild(makeSelectForm("", "Clear default"));
        }}
    }};

    const refreshMoveButtons = () => {{
        const currentCards = cards();
        currentCards.forEach((card, index) => {{
            card.querySelectorAll(".preset-move-button").forEach((button) => {{
                const direction = Number(button.dataset.direction);
                button.disabled = saving || (direction < 0 ? index === 0 : index === currentCards.length - 1);
            }});
            const handle = card.querySelector(".preset-drag-handle");
            handle.draggable = !saving;
            handle.disabled = saving;
        }});
    }};

    const restoreOrder = (references) => {{
        const byReference = new Map(cards().map((card) => [card.dataset.reference, card]));
        references.forEach((reference) => {{
            const card = byReference.get(reference);
            if (card) list.appendChild(card);
        }});
    }};

    const saveOrder = async (previousOrder) => {{
        saving = true;
        orderStatus.textContent = "Saving order...";
        orderStatus.classList.remove("error");
        refreshMoveButtons();

        try {{
            const response = await fetch("/admin/styles/order", {{
                method: "POST",
                headers: {{"Content-Type": "application/json"}},
                body: JSON.stringify({{references: order()}}),
            }});
            if (!response.ok) {{
                let message = "Could not save style order.";
                try {{
                    const payload = await response.json();
                    if (payload.detail) message = payload.detail;
                }} catch (_) {{}}
                throw new Error(message);
            }}
            orderStatus.textContent = "Order saved";
        }} catch (error) {{
            restoreOrder(previousOrder);
            orderStatus.textContent = error.message;
            orderStatus.classList.add("error");
        }} finally {{
            saving = false;
            refreshMoveButtons();
        }}
    }};

    list.addEventListener("dragover", (event) => {{
        if (!draggedCard || saving) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
        const target = event.target.closest(".preset-card[data-reference]");
        if (!target || target === draggedCard) return;
        const bounds = target.getBoundingClientRect();
        list.insertBefore(draggedCard, event.clientY < bounds.top + bounds.height / 2 ? target : target.nextSibling);
    }});
    list.addEventListener("drop", (event) => {{
        if (draggedCard) event.preventDefault();
    }});

    list.addEventListener("dragstart", (event) => {{
        const handle = event.target.closest(".preset-drag-handle");
        if (!handle) return;
        if (saving) {{
            event.preventDefault();
            return;
        }}
        draggedCard = handle.closest(".preset-card[data-reference]");
        orderBeforeDrag = order();
        draggedCard.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", draggedCard.dataset.reference);
    }});

    list.addEventListener("dragend", (event) => {{
        if (!event.target.closest(".preset-drag-handle") || !draggedCard) return;
        draggedCard.classList.remove("dragging");
        draggedCard = null;
        const changed = !sameOrder(orderBeforeDrag, order());
        refreshMoveButtons();
        if (changed) saveOrder(orderBeforeDrag);
    }});

    list.addEventListener("click", (event) => {{
        const toggle = event.target.closest(".preset-card-toggle");
        if (toggle) {{
            const editor = document.getElementById(toggle.getAttribute("aria-controls"));
            const expanded = toggle.getAttribute("aria-expanded") === "true";
            toggle.setAttribute("aria-expanded", String(!expanded));
            editor.hidden = expanded;
            return;
        }}

        const button = event.target.closest(".preset-move-button");
        if (!button || saving) return;
        const card = button.closest(".preset-card[data-reference]");
        const previousOrder = order();
        if (Number(button.dataset.direction) < 0) {{
            const previous = card.previousElementSibling;
            if (previous) list.insertBefore(card, previous);
        }} else {{
            const next = card.nextElementSibling;
            if (next) list.insertBefore(next, card);
        }}
        refreshMoveButtons();
        if (!sameOrder(previousOrder, order())) saveOrder(previousOrder);
    }});

    list.addEventListener("input", (event) => {{
        const form = event.target.closest(".preset-update-form");
        if (!form) return;
        form.dataset.editRevision = String(
            Number(form.dataset.editRevision || "0") + 1
        );
        const formStatus = form.querySelector(".preset-card-status");
        if (formStatus.classList.contains("ok")) setFormStatus(form, "");
    }});

    document.addEventListener("submit", async (event) => {{
        const form = event.target.closest(
            ".style-select-form, .preset-delete-form, .preset-update-form, .preset-create-form"
        );
        if (!form) return;
        event.preventDefault();

        if (form.classList.contains("preset-delete-form")) {{
            if (saving || defaultSaving) return;
            const card = form.closest(".preset-card[data-reference]");
            const reference = card.dataset.reference;
            if (!window.confirm(`Delete style preset "${{reference}}"?`)) return;

            const button = form.querySelector('button[type="submit"]');
            button.disabled = true;
            button.textContent = "Deleting...";
            try {{
                const payload = await requestMutation(form);
                card.remove();
                applyDefaultState(payload.default_style);
                if (!cards().length) {{
                    const empty = document.createElement("section");
                    empty.className = "panel preset-list-empty";
                    empty.innerHTML = '<p class="empty">No style presets yet.</p>';
                    list.replaceChildren(empty);
                }}
                refreshMoveButtons();
                actionStatus.textContent = "Preset deleted";
                actionStatus.classList.remove("error");
                const currentUrl = new URL(window.location.href);
                if (currentUrl.searchParams.get("view") === reference) {{
                    window.history.replaceState(null, "", "/admin/styles");
                }}
            }} catch (error) {{
                actionStatus.textContent = error.message;
                actionStatus.classList.add("error");
                if (button.isConnected) {{
                    button.disabled = false;
                    button.textContent = "Delete";
                }}
            }}
            return;
        }}

        if (form.classList.contains("style-select-form")) {{
            if (defaultSaving) return;
            defaultSaving = true;
            const button = form.querySelector('button[type="submit"]');
            const originalLabel = button.textContent;
            document.querySelectorAll(".style-select-form button").forEach((button) => {{
                button.disabled = true;
            }});
            button.textContent = "Updating...";
            try {{
                const payload = await requestMutation(form);
                applyDefaultState(payload.default_style);
                actionStatus.textContent = "Default updated";
                actionStatus.classList.remove("error");
            }} catch (error) {{
                actionStatus.textContent = error.message;
                actionStatus.classList.add("error");
            }} finally {{
                defaultSaving = false;
                if (button.isConnected) button.textContent = originalLabel;
                document.querySelectorAll(".style-select-form button").forEach((button) => {{
                    button.disabled = false;
                }});
            }}
            return;
        }}

        const button = form.querySelector('button[type="submit"]');
        const creating = form.classList.contains("preset-create-form");
        const submittedRevision = form.dataset.editRevision || "0";
        button.disabled = true;
        button.textContent = creating ? "Creating..." : "Saving...";
        try {{
            const payload = await requestMutation(form);
            if (!creating) {{
                if ((form.dataset.editRevision || "0") === submittedRevision) {{
                    applyPresetState(form, payload.preset);
                    setFormStatus(form, "Preset saved.");
                }}
                return;
            }}

            const template = document.createElement("template");
            template.innerHTML = payload.card_html.trim();
            const card = template.content.firstElementChild;
            if (!cards().length) list.replaceChildren();
            list.appendChild(card);
            applyDefaultState(payload.default_style);
            document.querySelector(".new-preset-card").remove();
            newStyleAction.href = "/admin/styles?new=1";
            newStyleAction.textContent = "New preset";
            window.history.replaceState(
                null,
                "",
                `/admin/styles?view=${{encodeURIComponent(payload.preset.reference)}}`,
            );
            setFormStatus(card.querySelector(".preset-update-form"), "Preset created.");
            refreshMoveButtons();
        }} catch (error) {{
            setFormStatus(form, error.message, true);
        }} finally {{
            if (button.isConnected) {{
                button.disabled = false;
                button.textContent = creating ? "Create preset" : "Save preset";
            }}
        }}
    }});

    refreshMoveButtons();
}})();
</script>
"""



async def _read_style_form(request: Request) -> dict[str, list[str]]:
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        return parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error


def _style_error_response(
    message: str,
    viewed_reference: str | None = None,
    *,
    show_new: bool = False,
    create_values: dict[str, str] | None = None,
) -> HTMLResponse:
    response = render_page(
        "Styles",
        "styles",
        render_style_navigation("presets") + _styles_content(
            message,
            error=True,
            viewed_reference=viewed_reference,
            show_new=show_new,
            create_values=create_values,
        ),
    )
    response.status_code = 400
    return response


@router.post("/admin/styles/select", include_in_schema=False)
async def select_style_preset(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_style_form(request)
    reference = form.get("reference", [""])[0].strip()

    if reference and load_catalog().find(reference) is None:
        message = "Selected style preset does not exist."
        if _wants_json(request):
            return JSONResponse({"detail": message}, status_code=400)
        return _style_error_response(message)

    config.update_style_preset(reference or None)
    if _wants_json(request):
        return JSONResponse({"default_style": _default_style_state()})
    return RedirectResponse("/admin/styles", status_code=303)


@router.post("/admin/styles/order", include_in_schema=False)
async def save_style_preset_order(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=400, detail="Invalid JSON body.") from error

    references = payload.get("references") if isinstance(payload, dict) else None
    if not isinstance(references, list):
        raise HTTPException(
            status_code=400,
            detail="'references' must be a list.",
        )

    try:
        save_preset_order(references)
    except (StylePresetError, ValueError) as error:
        raise HTTPException(status_code=400, detail=str(error)) from error

    return Response(status_code=204)


@router.post("/admin/styles/create", include_in_schema=False)
async def create_style_preset(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_style_form(request)

    try:
        preset = create_preset(
            file_id=form.get("file_id", [""])[0],
            name=form.get("name", [""])[0],
            prompt=form.get("prompt", [""])[0],
            negative_prompt=form.get("negative_prompt", [""])[0],
            prompt_excludes=form.get("prompt_excludes", [""])[0],
            negative_prompt_excludes=form.get("negative_prompt_excludes", [""])[0],
        )
    except (StylePresetError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _style_error_response(
            str(error),
            show_new=True,
            create_values={
                field: form.get(field, [""])[0]
                for field in (
                    "file_id",
                    "name",
                    "prompt",
                    "negative_prompt",
                    "prompt_excludes",
                    "negative_prompt_excludes",
                )
            },
        )

    if _wants_json(request):
        return JSONResponse(
            {
                "preset": _style_state(preset),
                "default_style": _default_style_state(),
                "card_html": _style_card(
                    preset,
                    editor_id="style-preset-editor-created",
                    selected_reference=config.NAIRELAY_STYLE_PRESET or "",
                    expanded=True,
                ),
            },
            status_code=201,
        )

    encoded_reference = quote(preset.reference, safe="")
    return RedirectResponse(
        f"/admin/styles?view={encoded_reference}",
        status_code=303,
    )


@router.post("/admin/styles/update", include_in_schema=False)
async def save_style_preset(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_style_form(request)
    reference = form.get("reference", [""])[0]

    try:
        preset = update_preset(
            reference=reference,
            prompt=form.get("prompt", [""])[0],
            negative_prompt=form.get("negative_prompt", [""])[0],
            prompt_excludes=form.get("prompt_excludes", [""])[0],
            negative_prompt_excludes=form.get("negative_prompt_excludes", [""])[0],
        )
    except (StylePresetError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _style_error_response(str(error), viewed_reference=reference)

    if _wants_json(request):
        return JSONResponse({"preset": _style_state(preset)})

    encoded_reference = quote(preset.reference, safe="")
    return RedirectResponse(
        f"/admin/styles?view={encoded_reference}",
        status_code=303,
    )


@router.post("/admin/styles/delete", include_in_schema=False)
async def remove_style_preset(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_style_form(request)
    reference = form.get("reference", [""])[0]

    try:
        delete_preset(reference)
        if config.NAIRELAY_STYLE_PRESET == reference:
            config.update_style_preset(None)
    except (StylePresetError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _style_error_response(str(error), viewed_reference=reference)

    if _wants_json(request):
        return JSONResponse(
            {
                "deleted_reference": reference,
                "default_style": _default_style_state(),
            }
        )
    return RedirectResponse("/admin/styles", status_code=303)
