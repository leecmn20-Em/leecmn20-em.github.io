import html

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from services.account import NovelAIAccountError, get_account_info
from .layout import render_page


router = APIRouter()


def _status_row(label: str, value: str, state: str = "") -> str:
    return (
        '<div class="row">'
        f"<span>{html.escape(label)}</span>"
        f'<strong class="{state}">{html.escape(value)}</strong>'
        "</div>"
    )


@router.get("/admin/account", response_class=HTMLResponse, include_in_schema=False)
async def account_page() -> HTMLResponse:
    try:
        account = await get_account_info()
    except NovelAIAccountError as error:
        content = f"""
<div class="account-actions">
    <a class="button-link" href="/admin/account">Retry</a>
</div>
<div class="notice error">{html.escape(str(error))}</div>
"""
        return render_page("Account", "account", content)

    content = f"""
<div class="account-actions">
    <a class="button-link" href="/admin/account">Refresh</a>
</div>
<section class="panel">
    {_status_row('NovelAI connection', 'Connected', 'ok')}
    {_status_row('Opus unlimited priority', 'Active' if account.opus else 'Inactive', 'ok' if account.opus else '')}
    {_status_row('Fixed Anlas', f'{account.fixed_anlas:,}')}
    {_status_row('Purchased Anlas', f'{account.purchased_anlas:,}')}
    {_status_row('Total Anlas', f'{account.total_anlas:,}')}
</section>
"""
    return render_page("Account", "account", content)
