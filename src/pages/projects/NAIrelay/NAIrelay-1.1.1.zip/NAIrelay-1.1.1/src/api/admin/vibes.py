import base64
import binascii
import html
import json
from urllib.parse import parse_qs, quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

from services.vibe_transfer import (
    MAX_SOURCE_IMAGE_BYTES,
    MODEL_NAMES,
    StoredVibe,
    VibeTransferError,
    add_vibe_encoding,
    create_vibe,
    delete_vibe,
    delete_vibe_encoding,
    load_vibe_catalog,
    rename_vibe,
    save_vibe_order,
)
from .layout import render_page
from .security import require_same_origin
from .vibe_navigation import render_vibe_tabs


router = APIRouter()
MAX_CREATE_BODY_BYTES = 33_554_432


def _vibe_state(vibe: StoredVibe) -> dict[str, object]:
    return {
        "reference": vibe.reference,
        "name": vibe.name,
        "models": list(vibe.model_abbreviations),
        "encodings": [
            {
                "model": encoding.model,
                "model_abbreviation": encoding.model_abbreviation,
                "information_extracted": encoding.information_extracted,
            }
            for encoding in vibe.encodings
        ],
    }


def _current_vibe_state(reference: str) -> dict[str, object]:
    vibe = load_vibe_catalog().find(reference)
    if vibe is None:
        raise VibeTransferError(f"Vibe '{reference}' does not exist.")
    return _vibe_state(vibe)


def _wants_json(request: Request) -> bool:
    return request.headers.get("x-requested-with") == "fetch"


@router.get(
    "/admin/vibes/library",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def vibes_page(view: str | None = None, new: bool = False) -> HTMLResponse:
    return render_page(
        "Vibes",
        "vibes",
        _vibes_content(viewed_reference=view, show_new=new),
    )


def _vibes_content(
    message: str = "",
    error: bool = False,
    viewed_reference: str | None = None,
    show_new: bool = False,
) -> str:
    notice = ""
    if message:
        notice_class = "error" if error else "ok"
        notice = f'<p class="notice {notice_class}">{html.escape(message)}</p>'

    catalog = load_vibe_catalog()
    catalog_notices = "".join(
        f'<p class="notice error">{html.escape(catalog_error)}</p>'
        for catalog_error in catalog.errors
    )
    model_options = "".join(
        f'<option value="{html.escape(model_key, quote=True)}"'
        f'{" selected" if model_key == "naid4.5f" else ""}>'
        f"{html.escape(model_key.upper())}</option>"
        for model_key in MODEL_NAMES
    )

    cards = []
    for index, vibe in enumerate(catalog.vibes):
        editor_id = f"vibe-editor-{index}"
        expanded = vibe.reference == viewed_reference
        hidden = "" if expanded else " hidden"
        aria_expanded = "true" if expanded else "false"
        name = html.escape(vibe.name)
        reference = html.escape(vibe.reference, quote=True)
        models = ", ".join(vibe.model_abbreviations) or "Not encoded"

        encoding_rows = []
        for encoding in vibe.encodings:
            model = html.escape(encoding.model, quote=True)
            information_value = format(encoding.information_extracted, ".15g")
            encoding_rows.append(f"""
<div class="vibe-encoding-row">
    <div class="vibe-encoding-meta">
        <span>Model</span>
        <strong>{html.escape(encoding.model_abbreviation)}</strong>
        <span>Information extracted</span>
        <strong>{information_value}</strong>
    </div>
    <form class="vibe-encoding-delete" method="post" action="/admin/vibes/encoding/delete">
        <input type="hidden" name="reference" value="{reference}">
        <input type="hidden" name="model" value="{model}">
        <input type="hidden" name="information_extracted" value="{information_value}">
        <button class="danger" type="submit">Delete</button>
    </form>
</div>""")
        if not encoding_rows:
            encoding_rows.append(
                '<p class="vibe-encoding-empty">No encodings yet.</p>'
            )
        encoding_count = len(vibe.encodings)
        encoding_count_label = (
            "1 encoding" if encoding_count == 1 else f"{encoding_count} encodings"
        )

        cards.append(f"""
<section class="panel preset-card vibe-card" data-reference="{reference}">
    <div class="preset-card-header">
        <button class="preset-card-toggle" type="button" aria-expanded="{aria_expanded}" aria-controls="{editor_id}">
            <span class="preset-card-identity">
                <strong>{name}</strong>
                <code>{html.escape(models)}</code>
            </span>
        </button>
        <div class="preset-card-controls">
            <form class="vibe-delete" method="post" action="/admin/vibes/delete" data-vibe-name="{html.escape(vibe.name, quote=True)}">
                <input type="hidden" name="reference" value="{reference}">
                <button class="danger" type="submit">Delete vibe</button>
            </form>
            <div class="preset-order-buttons" aria-label="Reorder {html.escape(vibe.name, quote=True)}">
                <button type="button" class="preset-move-button" data-direction="-1" aria-label="Move {html.escape(vibe.name, quote=True)} up">↑</button>
                <button type="button" class="preset-move-button" data-direction="1" aria-label="Move {html.escape(vibe.name, quote=True)} down">↓</button>
            </div>
            <button type="button" class="preset-drag-handle" draggable="true" aria-label="Reorder {html.escape(vibe.name, quote=True)}" title="Drag to reorder">⠿</button>
        </div>
    </div>
    <div id="{editor_id}" class="vibe-card-body"{hidden}>
        <figure class="vibe-preview">
            <img src="{html.escape(vibe.image_data_url, quote=True)}" alt="Source image for {html.escape(vibe.name, quote=True)}" loading="lazy">
        </figure>
        <div class="vibe-encoding-panel">
            <form class="vibe-rename" method="post" action="/admin/vibes/rename">
                <input type="hidden" name="reference" value="{reference}">
                <label>
                    Name
                    <input name="name" value="{html.escape(vibe.name, quote=True)}" maxlength="100" required>
                </label>
                <button type="submit">Save name</button>
            </form>
            <div class="vibe-encoding-heading">
                <strong>Encodings</strong>
                <span>{encoding_count_label}</span>
            </div>
            <div class="vibe-encoding-list">{''.join(encoding_rows)}</div>
            <p class="vibe-card-status notice error" aria-live="polite" hidden></p>
            <form class="vibe-encoding-add" method="post" action="/admin/vibes/encoding/add">
                <input type="hidden" name="reference" value="{reference}">
                <label>
                    Model
                    <select name="model">{model_options}</select>
                </label>
                <label>
                    Information extracted
                    <input type="number" name="information_extracted" value="1" min="0.01" max="1" step="0.01" required>
                </label>
                <button type="submit">Add encoding</button>
            </form>
        </div>
    </div>
</section>""")

    if not cards:
        cards.append(
            '<section class="panel"><p class="empty">No saved vibes yet.</p></section>'
        )

    new_card = ""
    if show_new:
        new_card = """
<section class="panel preset-card new-preset-card">
    <div class="preset-card-header">
        <div class="preset-card-identity">
            <strong>New vibe</strong>
            <span>Store a source image before encoding it.</span>
        </div>
        <a class="button-link" href="/admin/vibes/library">Cancel</a>
    </div>
    <form id="vibe-create-form" class="preset-form vibe-create-form">
        <label>
            Name
            <input name="name" maxlength="100" placeholder="Soft watercolor" required>
        </label>
        <label>
            Source image
            <input name="image" type="file" accept="image/png,image/jpeg,image/gif,image/webp" required>
        </label>
        <p id="vibe-create-error" class="notice error" hidden></p>
        <div class="form-actions"><button type="submit">Create vibe</button></div>
    </form>
</section>"""

    top_action_href = (
        "/admin/vibes/library"
        if show_new
        else "/admin/vibes/library?new=1"
    )
    top_action_label = "Close new vibe" if show_new else "New vibe"
    vibe_count = len(catalog.vibes)
    count_label = "1 vibe" if vibe_count == 1 else f"{vibe_count} vibes"
    return f"""
{render_vibe_tabs("library")}
<section class="panel vibes-toolbar">
    <div class="setting">
        <div>
            <strong>Saved vibes</strong>
            <span id="vibe-count">{count_label}</span>
        </div>
        <div class="styles-toolbar-actions">
            <span id="vibe-order-status" class="style-order-status" aria-live="polite"></span>
            <a class="button-link" href="{top_action_href}">{top_action_label}</a>
        </div>
    </div>
</section>
{notice}
{catalog_notices}
{new_card}
<div class="preset-card-list vibe-card-list">{''.join(cards)}</div>
<script>
(() => {{
    document.querySelectorAll(".vibe-card .preset-card-toggle").forEach((toggle) => {{
        const details = document.getElementById(toggle.getAttribute("aria-controls"));
        toggle.addEventListener("click", () => {{
            const expanded = toggle.getAttribute("aria-expanded") === "true";
            toggle.setAttribute("aria-expanded", String(!expanded));
            details.hidden = expanded;
        }});
    }});

    const vibeList = document.querySelector(".vibe-card-list");
    const vibeCount = document.getElementById("vibe-count");
    const orderStatus = document.getElementById("vibe-order-status");
    let draggedCard = null;
    let orderBeforeDrag = [];
    let savingOrder = false;

    const cards = () => Array.from(vibeList.querySelectorAll(".vibe-card[data-reference]"));
    const order = () => cards().map((card) => card.dataset.reference);
    const sameOrder = (left, right) => left.length === right.length &&
        left.every((value, index) => value === right[index]);

    const appendHiddenInput = (form, name, value) => {{
        const input = document.createElement("input");
        input.type = "hidden";
        input.name = name;
        input.value = value;
        form.appendChild(input);
    }};

    const applyVibeState = (card, state) => {{
        card.querySelector(".preset-card-identity strong").textContent = state.name;
        card.querySelector(".vibe-delete").dataset.vibeName = state.name;
        card.querySelector(".vibe-rename input[name='name']").value = state.name;
        const models = state.models.length ? state.models.join(", ") : "Not encoded";
        card.querySelector(".preset-card-identity code").textContent = models;
        const count = state.encodings.length;
        card.querySelector(".vibe-encoding-heading span").textContent =
            count === 1 ? "1 encoding" : `${{count}} encodings`;

        const list = card.querySelector(".vibe-encoding-list");
        list.replaceChildren();
        if (!count) {{
            const empty = document.createElement("p");
            empty.className = "vibe-encoding-empty";
            empty.textContent = "No encodings yet.";
            list.appendChild(empty);
            return;
        }}

        state.encodings.forEach((encoding) => {{
            const row = document.createElement("div");
            row.className = "vibe-encoding-row";
            const meta = document.createElement("div");
            meta.className = "vibe-encoding-meta";
            [["Model", encoding.model_abbreviation], ["Information extracted", String(encoding.information_extracted)]].forEach(([label, value]) => {{
                const labelElement = document.createElement("span");
                labelElement.textContent = label;
                const valueElement = document.createElement("strong");
                valueElement.textContent = value;
                meta.append(labelElement, valueElement);
            }});

            const form = document.createElement("form");
            form.className = "vibe-encoding-delete";
            form.method = "post";
            form.action = "/admin/vibes/encoding/delete";
            appendHiddenInput(form, "reference", state.reference);
            appendHiddenInput(form, "model", encoding.model);
            appendHiddenInput(form, "information_extracted", String(encoding.information_extracted));
            const button = document.createElement("button");
            button.className = "danger";
            button.type = "submit";
            button.textContent = "Delete";
            form.appendChild(button);
            row.append(meta, form);
            list.appendChild(row);
        }});
    }};

    const requestMutation = async (form) => {{
        const response = await fetch(form.action, {{
            method: "POST",
            headers: {{
                "Accept": "application/json",
                "X-Requested-With": "fetch",
            }},
            body: new URLSearchParams(new FormData(form)),
        }});
        let payload = {{}};
        try {{
            payload = await response.json();
        }} catch {{}}
        if (!response.ok) {{
            throw new Error(payload.detail || "Vibe operation failed.");
        }}
        return payload;
    }};

    const refreshMoveButtons = () => {{
        const currentCards = cards();
        currentCards.forEach((card, index) => {{
            card.querySelectorAll(".preset-move-button").forEach((button) => {{
                const direction = Number(button.dataset.direction);
                button.disabled = savingOrder ||
                    (direction < 0 ? index === 0 : index === currentCards.length - 1);
            }});
            const handle = card.querySelector(".preset-drag-handle");
            handle.draggable = !savingOrder;
            handle.disabled = savingOrder;
        }});
    }};

    const restoreOrder = (references) => {{
        const byReference = new Map(
            cards().map((card) => [card.dataset.reference, card])
        );
        references.forEach((reference) => {{
            const card = byReference.get(reference);
            if (card) vibeList.appendChild(card);
        }});
    }};

    const saveOrder = async (previousOrder) => {{
        savingOrder = true;
        orderStatus.textContent = "Saving order...";
        orderStatus.classList.remove("error");
        refreshMoveButtons();
        try {{
            const response = await fetch("/admin/vibes/order", {{
                method: "POST",
                headers: {{"Content-Type": "application/json"}},
                body: JSON.stringify({{references: order()}}),
            }});
            if (!response.ok) {{
                let message = "Could not save Vibe order.";
                try {{
                    const payload = await response.json();
                    if (payload.detail) message = payload.detail;
                }} catch {{}}
                throw new Error(message);
            }}
            orderStatus.textContent = "Order saved";
        }} catch (error) {{
            restoreOrder(previousOrder);
            orderStatus.textContent = error.message;
            orderStatus.classList.add("error");
        }} finally {{
            savingOrder = false;
            refreshMoveButtons();
        }}
    }};

    vibeList.addEventListener("dragover", (event) => {{
        if (!draggedCard || savingOrder) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
        const target = event.target.closest(".vibe-card[data-reference]");
        if (!target || target === draggedCard) return;
        const bounds = target.getBoundingClientRect();
        vibeList.insertBefore(
            draggedCard,
            event.clientY < bounds.top + bounds.height / 2
                ? target
                : target.nextSibling,
        );
    }});

    vibeList.addEventListener("drop", (event) => {{
        if (draggedCard) event.preventDefault();
    }});

    vibeList.addEventListener("dragstart", (event) => {{
        const handle = event.target.closest(".preset-drag-handle");
        if (!handle) return;
        if (savingOrder) {{
            event.preventDefault();
            return;
        }}
        draggedCard = handle.closest(".vibe-card[data-reference]");
        orderBeforeDrag = order();
        draggedCard.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", draggedCard.dataset.reference);
    }});

    vibeList.addEventListener("dragend", (event) => {{
        if (!event.target.closest(".preset-drag-handle") || !draggedCard) return;
        draggedCard.classList.remove("dragging");
        draggedCard = null;
        const changed = !sameOrder(orderBeforeDrag, order());
        refreshMoveButtons();
        if (changed) saveOrder(orderBeforeDrag);
    }});

    vibeList.addEventListener("click", (event) => {{
        const button = event.target.closest(".preset-move-button");
        if (!button || savingOrder) return;
        const card = button.closest(".vibe-card[data-reference]");
        const previousOrder = order();
        if (Number(button.dataset.direction) < 0) {{
            const previous = card.previousElementSibling;
            if (previous) vibeList.insertBefore(card, previous);
        }} else {{
            const next = card.nextElementSibling;
            if (next) vibeList.insertBefore(next, card);
        }}
        refreshMoveButtons();
        if (!sameOrder(previousOrder, order())) saveOrder(previousOrder);
    }});

    vibeList.addEventListener("submit", async (event) => {{
        const form = event.target.closest(".vibe-rename, .vibe-encoding-add, .vibe-encoding-delete, .vibe-delete");
        if (!form) return;
        event.preventDefault();
        const card = form.closest(".vibe-card");
        const status = card.querySelector(".vibe-card-status");
        const button = form.querySelector('button[type="submit"]');
        const originalLabel = button.textContent;

        if (form.classList.contains("vibe-encoding-delete") && !window.confirm("Delete this encoded Vibe value?")) return;
        if (form.classList.contains("vibe-delete")) {{
            if (savingOrder) return;
            const name = form.dataset.vibeName;
            if (!window.confirm(`Delete Vibe "${{name}}" and all of its encodings?`)) return;
        }}

        button.disabled = true;
        button.textContent = form.classList.contains("vibe-encoding-add")
            ? "Encoding..."
            : form.classList.contains("vibe-rename")
                ? "Saving..."
                : "Deleting...";
        try {{
            const payload = await requestMutation(form);
            if (form.classList.contains("vibe-delete")) {{
                card.remove();
                vibeCount.textContent = payload.vibe_count === 1
                    ? "1 vibe"
                    : `${{payload.vibe_count}} vibes`;
                if (payload.vibe_count === 0) {{
                    const empty = document.createElement("section");
                    empty.className = "panel";
                    const text = document.createElement("p");
                    text.className = "empty";
                    text.textContent = "No saved vibes yet.";
                    empty.appendChild(text);
                    vibeList.appendChild(empty);
                }}
                refreshMoveButtons();
                return;
            }}
            applyVibeState(card, payload.vibe);
            status.textContent = "";
            status.hidden = true;
            button.disabled = false;
            button.textContent = originalLabel;
        }} catch (error) {{
            const toggle = card.querySelector(".preset-card-toggle");
            const details = document.getElementById(toggle.getAttribute("aria-controls"));
            toggle.setAttribute("aria-expanded", "true");
            details.hidden = false;
            status.textContent = error.message;
            status.hidden = false;
            button.disabled = false;
            button.textContent = originalLabel;
        }}
    }});

    const createForm = document.getElementById("vibe-create-form");
    if (createForm) {{
        const errorNotice = document.getElementById("vibe-create-error");
        const submitButton = createForm.querySelector('button[type="submit"]');
        createForm.addEventListener("submit", async (event) => {{
            event.preventDefault();
            const file = createForm.elements.image.files[0];
            if (!file) return;
            if (file.size > {MAX_SOURCE_IMAGE_BYTES}) {{
                errorNotice.textContent = "Vibe source image must be at most 20 MB.";
                errorNotice.hidden = false;
                return;
            }}

            submitButton.disabled = true;
            submitButton.textContent = "Creating...";
            try {{
                const dataUrl = await new Promise((resolve, reject) => {{
                    const reader = new FileReader();
                    reader.onload = () => resolve(reader.result);
                    reader.onerror = () => reject(new Error("Could not read the source image."));
                    reader.readAsDataURL(file);
                }});
                const response = await fetch("/admin/vibes/create", {{
                    method: "POST",
                    headers: {{"Content-Type": "application/json"}},
                    body: JSON.stringify({{
                        name: createForm.elements.name.value,
                        image_base64: String(dataUrl).split(",", 2)[1],
                    }}),
                }});
                const payload = await response.json();
                if (!response.ok) throw new Error(payload.detail || "Could not create Vibe.");
                window.location.assign(`/admin/vibes/library?view=${{encodeURIComponent(payload.reference)}}`);
            }} catch (error) {{
                errorNotice.textContent = error.message;
                errorNotice.hidden = false;
                submitButton.disabled = false;
                submitButton.textContent = "Create vibe";
            }}
        }});
    }}
    refreshMoveButtons();
}})();
</script>
"""


async def _read_vibe_form(request: Request) -> dict[str, list[str]]:
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        return parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error


def _vibe_error_response(message: str, reference: str | None = None) -> HTMLResponse:
    response = render_page(
        "Vibes",
        "vibes",
        _vibes_content(message, error=True, viewed_reference=reference),
    )
    response.status_code = 400
    return response


@router.post("/admin/vibes/create", include_in_schema=False)
async def create_stored_vibe(request: Request) -> JSONResponse:
    require_same_origin(request)
    body = await request.body()
    if len(body) > MAX_CREATE_BODY_BYTES:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=400, detail="Invalid JSON body.") from error
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid JSON body.")

    name = payload.get("name")
    image_base64 = payload.get("image_base64")
    if not isinstance(name, str) or not isinstance(image_base64, str):
        raise HTTPException(status_code=400, detail="Name and source image are required.")
    try:
        image = base64.b64decode(image_base64, validate=True)
        vibe = create_vibe(name=name, image=image)
    except (ValueError, binascii.Error, VibeTransferError) as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    return JSONResponse({"reference": vibe.reference}, status_code=201)


@router.post("/admin/vibes/order", include_in_schema=False)
async def save_stored_vibe_order(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=400, detail="Invalid JSON body.") from error
    references = payload.get("references") if isinstance(payload, dict) else None
    if not isinstance(references, list):
        raise HTTPException(status_code=400, detail="'references' must be a list.")
    try:
        save_vibe_order(references)
    except (VibeTransferError, ValueError) as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    return Response(status_code=204)


@router.post("/admin/vibes/rename", include_in_schema=False)
async def rename_stored_vibe(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_vibe_form(request)
    reference = form.get("reference", [""])[0]
    try:
        vibe = rename_vibe(
            reference,
            name=form.get("name", [""])[0],
        )
    except (ValueError, VibeTransferError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _vibe_error_response(str(error), reference)
    if _wants_json(request):
        return JSONResponse({"vibe": _vibe_state(vibe)})
    return RedirectResponse(
        f"/admin/vibes/library?view={quote(reference, safe='')}",
        status_code=303,
    )


@router.post("/admin/vibes/encoding/add", include_in_schema=False)
async def add_stored_vibe_encoding(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_vibe_form(request)
    reference = form.get("reference", [""])[0]
    try:
        await add_vibe_encoding(
            reference,
            model=form.get("model", [""])[0],
            information_extracted=float(
                form.get("information_extracted", [""])[0]
            ),
        )
    except (ValueError, VibeTransferError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _vibe_error_response(str(error), reference)
    if _wants_json(request):
        return JSONResponse({"vibe": _current_vibe_state(reference)})
    return RedirectResponse(
        f"/admin/vibes/library?view={quote(reference, safe='')}",
        status_code=303,
    )


@router.post("/admin/vibes/delete", include_in_schema=False)
async def remove_stored_vibe(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_vibe_form(request)
    reference = form.get("reference", [""])[0]
    try:
        await delete_vibe(reference)
    except VibeTransferError as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _vibe_error_response(str(error), reference)
    if _wants_json(request):
        return JSONResponse(
            {
                "reference": reference,
                "vibe_count": len(load_vibe_catalog().vibes),
            }
        )
    return RedirectResponse("/admin/vibes/library", status_code=303)


@router.post("/admin/vibes/encoding/delete", include_in_schema=False)
async def remove_stored_vibe_encoding(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_vibe_form(request)
    reference = form.get("reference", [""])[0]
    try:
        await delete_vibe_encoding(
            reference,
            model=form.get("model", [""])[0],
            information_extracted=float(
                form.get("information_extracted", [""])[0]
            ),
        )
    except (ValueError, VibeTransferError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _vibe_error_response(str(error), reference)
    if _wants_json(request):
        return JSONResponse({"vibe": _current_vibe_state(reference)})
    return RedirectResponse(
        f"/admin/vibes/library?view={quote(reference, safe='')}",
        status_code=303,
    )
