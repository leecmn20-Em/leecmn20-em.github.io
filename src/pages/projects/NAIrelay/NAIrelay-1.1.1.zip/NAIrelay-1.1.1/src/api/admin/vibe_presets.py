import html
import json

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

from services.vibe_presets import (
    MAX_VIBES_PER_PRESET,
    VibePreset,
    VibePresetError,
    create_preset,
    delete_preset,
    load_catalog as load_preset_catalog,
    save_preset_order,
    update_preset,
)
from services.vibe_transfer import StoredVibe, load_vibe_catalog
from .layout import render_page
from .security import require_same_origin
from .vibe_navigation import render_vibe_tabs


router = APIRouter()
MAX_REQUEST_BODY_BYTES = 262_144


def _fraction_key(value: float) -> str:
    return format(value, ".15g")


def _preset_state(preset: VibePreset) -> dict[str, object]:
    return {
        "reference": preset.reference,
        "name": preset.name,
        "normalize_reference_strengths": preset.normalize_reference_strengths,
        "vibes": [
            {
                "reference": item.reference,
                "information_extracted": item.information_extracted,
                "strength": item.strength,
            }
            for item in preset.vibes
        ],
    }


def _library_state(vibes: tuple[StoredVibe, ...]) -> list[dict[str, object]]:
    result = []
    for vibe in vibes:
        information: dict[str, dict[str, object]] = {}
        for encoding in vibe.encodings:
            key = _fraction_key(encoding.information_extracted)
            item = information.setdefault(
                key,
                {"value": encoding.information_extracted, "models": []},
            )
            models = item["models"]
            if isinstance(models, list) and encoding.model_abbreviation not in models:
                models.append(encoding.model_abbreviation)
        if information:
            result.append(
                {
                    "reference": vibe.reference,
                    "name": vibe.name,
                    "information": sorted(
                        information.values(),
                        key=lambda option: float(option["value"]),
                    ),
                }
            )
    return result


def _vibe_options(
    library: list[dict[str, object]],
    selected_reference: str,
) -> str:
    options = []
    known_references = set()
    for vibe in library:
        reference = str(vibe["reference"])
        known_references.add(reference)
        selected = " selected" if reference == selected_reference else ""
        options.append(
            f'<option value="{html.escape(reference, quote=True)}"{selected}>'
            f'{html.escape(str(vibe["name"]))}</option>'
        )
    if selected_reference and selected_reference not in known_references:
        options.append(
            f'<option value="{html.escape(selected_reference, quote=True)}" selected>'
            f'Missing: {html.escape(selected_reference)}</option>'
        )
    if not options:
        return '<option value="">No encoded Vibes available</option>'
    return "".join(options)


def _information_options(
    library: list[dict[str, object]],
    selected_reference: str,
    selected_information: float,
) -> str:
    selected_key = _fraction_key(selected_information)
    information = next(
        (
            vibe["information"]
            for vibe in library
            if vibe["reference"] == selected_reference
        ),
        [],
    )
    options = []
    known_values = set()
    if isinstance(information, list):
        for item in information:
            if not isinstance(item, dict):
                continue
            value = float(item["value"])
            value_key = _fraction_key(value)
            known_values.add(value_key)
            models = item.get("models", [])
            model_label = ", ".join(str(model) for model in models)
            label = value_key if not model_label else f"{value_key} ({model_label})"
            selected = " selected" if value_key == selected_key else ""
            options.append(
                f'<option value="{value_key}"{selected}>{html.escape(label)}</option>'
            )
    if selected_key not in known_values:
        options.append(
            f'<option value="{selected_key}" selected>'
            f'Missing: {html.escape(selected_key)}</option>'
        )
    return "".join(options)


def _vibe_set_row(
    library: list[dict[str, object]],
    *,
    reference: str,
    information_extracted: float,
    strength: float,
) -> str:
    strength_value = _fraction_key(strength)
    return f"""
<div class="vibe-preset-set">
    <label>
        Vibe
        <select class="vibe-preset-reference" required>
            {_vibe_options(library, reference)}
        </select>
    </label>
    <label>
        Information extracted
        <select class="vibe-preset-information" required>
            {_information_options(library, reference, information_extracted)}
        </select>
    </label>
    <label class="vibe-preset-strength-label">
        Strength
        <span class="vibe-preset-strength">
            <input class="vibe-preset-strength-range" type="range" min="0.01" max="1" step="0.01" value="{strength_value}">
            <input class="vibe-preset-strength-number" type="number" min="0.01" max="1" step="0.01" value="{strength_value}" required>
        </span>
    </label>
    <button class="danger vibe-preset-remove" type="button">Remove</button>
</div>
"""


def _preset_card(
    preset: VibePreset,
    library: list[dict[str, object]],
    *,
    editor_id: str,
    expanded: bool = False,
) -> str:
    reference = html.escape(preset.reference, quote=True)
    hidden = "" if expanded else " hidden"
    aria_expanded = "true" if expanded else "false"
    rows = "".join(
        _vibe_set_row(
            library,
            reference=item.reference,
            information_extracted=item.information_extracted,
            strength=item.strength,
        )
        for item in preset.vibes
    )
    checked = " checked" if preset.normalize_reference_strengths else ""
    count = len(preset.vibes)
    count_label = "1 Vibe" if count == 1 else f"{count} Vibes"
    return f"""
<section class="panel preset-card vibe-preset-card" data-reference="{reference}">
    <div class="preset-card-header">
        <button class="preset-card-toggle" type="button" aria-expanded="{aria_expanded}" aria-controls="{editor_id}">
            <span class="preset-card-identity">
                <strong>{html.escape(preset.name)}</strong>
                <code>{reference}</code>
                <span class="vibe-preset-count">{count_label}</span>
            </span>
        </button>
        <div class="preset-card-controls">
            <button class="danger vibe-preset-delete" type="button">Delete</button>
            <div class="preset-order-buttons" aria-label="Reorder {html.escape(preset.name, quote=True)}">
                <button type="button" class="preset-move-button" data-direction="-1" aria-label="Move {html.escape(preset.name, quote=True)} up">↑</button>
                <button type="button" class="preset-move-button" data-direction="1" aria-label="Move {html.escape(preset.name, quote=True)} down">↓</button>
            </div>
            <button type="button" class="preset-drag-handle" draggable="true" aria-label="Reorder {html.escape(preset.name, quote=True)}" title="Drag to reorder">⠿</button>
        </div>
    </div>
    <form id="{editor_id}" class="preset-form vibe-preset-form vibe-preset-update-form" action="/admin/vibes/presets/update"{hidden}>
        <input type="hidden" name="reference" value="{reference}">
        <label class="checkbox-label">
            <input name="normalize_reference_strengths" type="checkbox"{checked}>
            Normalize reference strengths
        </label>
        <div class="vibe-preset-set-list">{rows}</div>
        <div class="vibe-preset-set-actions">
            <button class="vibe-preset-add" type="button">Add vibe</button>
            <span class="vibe-preset-total">Total strength: 0</span>
        </div>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit">Save preset</button></div>
    </form>
</section>
"""


def _new_preset_card(library: list[dict[str, object]]) -> str:
    first_reference = str(library[0]["reference"]) if library else ""
    first_information = 1.0
    if library:
        information = library[0].get("information", [])
        if isinstance(information, list) and information:
            first_information = float(information[0]["value"])
    initial_row = (
        _vibe_set_row(
            library,
            reference=first_reference,
            information_extracted=first_information,
            strength=0.6,
        )
        if library
        else ""
    )
    disabled = " disabled" if not library else ""
    return f"""
<section class="panel preset-card new-preset-card new-vibe-preset-card">
    <div class="preset-card-header">
        <div class="preset-card-identity">
            <strong>New preset</strong>
            <span>Combine encoded Vibes into a reusable preset.</span>
        </div>
        <a class="button-link" href="/admin/vibes/presets">Cancel</a>
    </div>
    <form class="preset-form vibe-preset-form vibe-preset-create-form" action="/admin/vibes/presets/create">
        <div class="field-row">
            <label>
                File ID
                <input name="file_id" maxlength="64" pattern="[A-Za-z0-9_-]{{1,64}}" placeholder="custom" required>
            </label>
            <label>
                Preset name
                <input name="name" maxlength="80" placeholder="Painterly blend" required>
            </label>
        </div>
        <label class="checkbox-label">
            <input name="normalize_reference_strengths" type="checkbox" checked>
            Normalize reference strengths
        </label>
        <div class="vibe-preset-set-list">{initial_row}</div>
        <div class="vibe-preset-set-actions">
            <button class="vibe-preset-add" type="button"{disabled}>Add vibe</button>
            <span class="vibe-preset-total">Total strength: 0</span>
        </div>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit"{disabled}>Create preset</button></div>
    </form>
</section>
"""


def _safe_script_json(value: object) -> str:
    return (
        json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )


def _vibe_presets_content(
    *,
    viewed_reference: str | None = None,
    show_new: bool = False,
) -> str:
    preset_catalog = load_preset_catalog()
    vibe_catalog = load_vibe_catalog()
    library = _library_state(vibe_catalog.vibes)
    notices = "".join(
        f'<p class="notice error">{html.escape(error)}</p>'
        for error in (*preset_catalog.errors, *vibe_catalog.errors)
    )
    cards = "".join(
        _preset_card(
            preset,
            library,
            editor_id=f"vibe-preset-editor-{index}",
            expanded=preset.reference == viewed_reference,
        )
        for index, preset in enumerate(preset_catalog.presets)
    )
    if not cards:
        cards = (
            '<section class="panel preset-list-empty">'
            '<p class="empty">No Vibe presets yet.</p></section>'
        )
    new_card = _new_preset_card(library) if show_new else ""
    top_action_href = (
        "/admin/vibes/presets" if show_new else "/admin/vibes/presets?new=1"
    )
    top_action_label = "Close new preset" if show_new else "New preset"
    preset_count = len(preset_catalog.presets)
    count_label = "1 preset" if preset_count == 1 else f"{preset_count} presets"

    return f"""
{render_vibe_tabs("presets")}
<section class="panel styles-toolbar">
    <div class="setting">
        <div>
            <strong>Vibe presets</strong>
            <span id="vibe-preset-count">{count_label}</span>
        </div>
        <div class="styles-toolbar-actions">
            <span id="vibe-preset-order-status" class="style-order-status" aria-live="polite"></span>
            <a id="new-vibe-preset-action" class="button-link" href="{top_action_href}">{top_action_label}</a>
        </div>
    </div>
</section>
{notices}
{new_card}
<div class="preset-card-list vibe-preset-card-list">{cards}</div>
<script>
(() => {{
    const vibeLibrary = {_safe_script_json(library)};
    const maxVibes = {MAX_VIBES_PER_PRESET};
    const list = document.querySelector(".vibe-preset-card-list");
    const countLabel = document.getElementById("vibe-preset-count");
    const newAction = document.getElementById("new-vibe-preset-action");
    const orderStatus = document.getElementById("vibe-preset-order-status");
    const byReference = new Map(vibeLibrary.map((vibe) => [vibe.reference, vibe]));
    let draggedCard = null;
    let orderBeforeDrag = [];
    let savingOrder = false;

    const cards = () => Array.from(list.querySelectorAll(".vibe-preset-card[data-reference]"));
    const order = () => cards().map((card) => card.dataset.reference);
    const sameOrder = (left, right) => left.length === right.length &&
        left.every((value, index) => value === right[index]);

    const setStatus = (form, message, error = false) => {{
        const status = form.querySelector(".preset-card-status");
        status.textContent = message;
        status.classList.toggle("error", error);
        status.classList.toggle("ok", !error);
        status.hidden = !message;
    }};

    const option = (value, label) => {{
        const element = document.createElement("option");
        element.value = String(value);
        element.textContent = label;
        return element;
    }};

    const populateInformation = (row, preferredValue = null) => {{
        const reference = row.querySelector(".vibe-preset-reference").value;
        const select = row.querySelector(".vibe-preset-information");
        const previous = preferredValue ?? select.value;
        select.replaceChildren();
        const vibe = byReference.get(reference);
        if (!vibe || !vibe.information.length) {{
            select.appendChild(option("", "No encodings available"));
            return;
        }}
        vibe.information.forEach((information) => {{
            const models = information.models.length
                ? ` (${{information.models.join(", ")}})`
                : "";
            select.appendChild(option(information.value, `${{information.value}}${{models}}`));
        }});
        if (Array.from(select.options).some((item) => item.value === String(previous))) {{
            select.value = String(previous);
        }}
    }};

    const updateTotal = (form) => {{
        const total = Array.from(form.querySelectorAll(".vibe-preset-strength-number"))
            .reduce((sum, input) => sum + (Number(input.value) || 0), 0);
        form.querySelector(".vibe-preset-total").textContent =
            `Total strength: ${{Number(total.toFixed(2))}}`;
        const addButton = form.querySelector(".vibe-preset-add");
        addButton.disabled = !vibeLibrary.length ||
            form.querySelectorAll(".vibe-preset-set").length >= maxVibes;
    }};

    const createRow = (item = null) => {{
        const row = document.createElement("div");
        row.className = "vibe-preset-set";
        const vibeLabel = document.createElement("label");
        vibeLabel.append("Vibe");
        const vibeSelect = document.createElement("select");
        vibeSelect.className = "vibe-preset-reference";
        vibeSelect.required = true;
        vibeLibrary.forEach((vibe) => vibeSelect.appendChild(option(vibe.reference, vibe.name)));
        if (item && byReference.has(item.reference)) vibeSelect.value = item.reference;
        vibeLabel.appendChild(vibeSelect);

        const informationLabel = document.createElement("label");
        informationLabel.append("Information extracted");
        const informationSelect = document.createElement("select");
        informationSelect.className = "vibe-preset-information";
        informationSelect.required = true;
        informationLabel.appendChild(informationSelect);

        const strengthLabel = document.createElement("label");
        strengthLabel.className = "vibe-preset-strength-label";
        strengthLabel.append("Strength");
        const strength = document.createElement("span");
        strength.className = "vibe-preset-strength";
        const range = document.createElement("input");
        range.className = "vibe-preset-strength-range";
        range.type = "range";
        range.min = "0.01";
        range.max = "1";
        range.step = "0.01";
        range.value = String(item?.strength ?? 0.6);
        const number = document.createElement("input");
        number.className = "vibe-preset-strength-number";
        number.type = "number";
        number.min = "0.01";
        number.max = "1";
        number.step = "0.01";
        number.required = true;
        number.value = range.value;
        strength.append(range, number);
        strengthLabel.appendChild(strength);

        const remove = document.createElement("button");
        remove.className = "danger vibe-preset-remove";
        remove.type = "button";
        remove.textContent = "Remove";
        row.append(vibeLabel, informationLabel, strengthLabel, remove);
        populateInformation(row, item?.information_extracted);
        return row;
    }};

    const presetPayload = (form) => {{
        const seen = new Set();
        const vibes = Array.from(form.querySelectorAll(".vibe-preset-set")).map((row) => {{
            const reference = row.querySelector(".vibe-preset-reference").value;
            const information_extracted = Number(row.querySelector(".vibe-preset-information").value);
            const strength = Number(row.querySelector(".vibe-preset-strength-number").value);
            const key = JSON.stringify([reference, information_extracted]);
            if (seen.has(key)) throw new Error("The same Vibe and Information Extracted value cannot be added twice.");
            seen.add(key);
            return {{reference, information_extracted, strength}};
        }});
        if (!vibes.length) throw new Error("Add at least one Vibe.");
        const payload = {{
            normalize_reference_strengths: form.elements.normalize_reference_strengths.checked,
            vibes,
        }};
        if (form.classList.contains("vibe-preset-create-form")) {{
            payload.file_id = form.elements.file_id.value;
            payload.name = form.elements.name.value;
        }} else {{
            payload.reference = form.elements.reference.value;
        }}
        return payload;
    }};

    const requestMutation = async (form) => {{
        const response = await fetch(form.action, {{
            method: "POST",
            headers: {{
                "Accept": "application/json",
                "Content-Type": "application/json",
                "X-Requested-With": "fetch",
            }},
            body: JSON.stringify(presetPayload(form)),
        }});
        let payload = {{}};
        try {{ payload = await response.json(); }} catch {{}}
        if (!response.ok) throw new Error(payload.detail || "Vibe preset operation failed.");
        return payload;
    }};

    const refreshMoveButtons = () => {{
        const currentCards = cards();
        currentCards.forEach((card, index) => {{
            card.querySelectorAll(".preset-move-button").forEach((button) => {{
                const direction = Number(button.dataset.direction);
                button.disabled = savingOrder ||
                    (direction < 0 ? index === 0 : index === currentCards.length - 1);
            }});
            const handle = card.querySelector(".preset-drag-handle");
            handle.draggable = !savingOrder;
            handle.disabled = savingOrder;
        }});
    }};

    const restoreOrder = (references) => {{
        const byPresetReference = new Map(
            cards().map((card) => [card.dataset.reference, card])
        );
        references.forEach((reference) => {{
            const card = byPresetReference.get(reference);
            if (card) list.appendChild(card);
        }});
    }};

    const saveOrder = async (previousOrder) => {{
        savingOrder = true;
        orderStatus.textContent = "Saving order...";
        orderStatus.classList.remove("error");
        refreshMoveButtons();
        try {{
            const response = await fetch("/admin/vibes/presets/order", {{
                method: "POST",
                headers: {{"Content-Type": "application/json"}},
                body: JSON.stringify({{references: order()}}),
            }});
            if (!response.ok) {{
                let message = "Could not save Vibe preset order.";
                try {{
                    const payload = await response.json();
                    if (payload.detail) message = payload.detail;
                }} catch {{}}
                throw new Error(message);
            }}
            orderStatus.textContent = "Order saved";
        }} catch (error) {{
            restoreOrder(previousOrder);
            orderStatus.textContent = error.message;
            orderStatus.classList.add("error");
        }} finally {{
            savingOrder = false;
            refreshMoveButtons();
        }}
    }};

    list.addEventListener("dragover", (event) => {{
        if (!draggedCard || savingOrder) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
        const target = event.target.closest(".vibe-preset-card[data-reference]");
        if (!target || target === draggedCard) return;
        const bounds = target.getBoundingClientRect();
        list.insertBefore(
            draggedCard,
            event.clientY < bounds.top + bounds.height / 2
                ? target
                : target.nextSibling,
        );
    }});

    list.addEventListener("drop", (event) => {{
        if (draggedCard) event.preventDefault();
    }});

    list.addEventListener("dragstart", (event) => {{
        const handle = event.target.closest(".preset-drag-handle");
        if (!handle) return;
        if (savingOrder) {{
            event.preventDefault();
            return;
        }}
        draggedCard = handle.closest(".vibe-preset-card[data-reference]");
        orderBeforeDrag = order();
        draggedCard.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", draggedCard.dataset.reference);
    }});

    list.addEventListener("dragend", (event) => {{
        if (!event.target.closest(".preset-drag-handle") || !draggedCard) return;
        draggedCard.classList.remove("dragging");
        draggedCard = null;
        const changed = !sameOrder(orderBeforeDrag, order());
        refreshMoveButtons();
        if (changed) saveOrder(orderBeforeDrag);
    }});

    document.addEventListener("click", async (event) => {{
        const toggle = event.target.closest(".vibe-preset-card .preset-card-toggle");
        if (toggle) {{
            const editor = document.getElementById(toggle.getAttribute("aria-controls"));
            const expanded = toggle.getAttribute("aria-expanded") === "true";
            toggle.setAttribute("aria-expanded", String(!expanded));
            editor.hidden = expanded;
            return;
        }}
        const deleteButton = event.target.closest(".vibe-preset-delete");
        if (deleteButton) {{
            if (savingOrder) return;
            const card = deleteButton.closest(".vibe-preset-card");
            const reference = card.dataset.reference;
            if (!window.confirm(`Delete Vibe preset "${{reference}}"?`)) return;

            deleteButton.disabled = true;
            deleteButton.textContent = "Deleting...";
            try {{
                const response = await fetch("/admin/vibes/presets/delete", {{
                    method: "POST",
                    headers: {{
                        "Accept": "application/json",
                        "Content-Type": "application/json",
                        "X-Requested-With": "fetch",
                    }},
                    body: JSON.stringify({{reference}}),
                }});
                let payload = {{}};
                try {{ payload = await response.json(); }} catch {{}}
                if (!response.ok) {{
                    throw new Error(payload.detail || "Could not delete Vibe preset.");
                }}

                card.remove();
                const count = payload.preset_count;
                countLabel.textContent = count === 1 ? "1 preset" : `${{count}} presets`;
                if (!list.querySelector(".vibe-preset-card")) {{
                    const empty = document.createElement("section");
                    empty.className = "panel preset-list-empty";
                    empty.innerHTML = '<p class="empty">No Vibe presets yet.</p>';
                    list.replaceChildren(empty);
                }}
                refreshMoveButtons();
                const currentUrl = new URL(window.location.href);
                if (currentUrl.searchParams.get("view") === reference) {{
                    window.history.replaceState(null, "", "/admin/vibes/presets");
                }}
            }} catch (error) {{
                const form = card.querySelector(".vibe-preset-form");
                setStatus(form, error.message, true);
                const toggle = card.querySelector(".preset-card-toggle");
                toggle.setAttribute("aria-expanded", "true");
                form.hidden = false;
                deleteButton.disabled = false;
                deleteButton.textContent = "Delete";
            }}
            return;
        }}
        const moveButton = event.target.closest(".preset-move-button");
        if (moveButton) {{
            if (savingOrder) return;
            const card = moveButton.closest(".vibe-preset-card[data-reference]");
            const previousOrder = order();
            if (Number(moveButton.dataset.direction) < 0) {{
                const previous = card.previousElementSibling;
                if (previous) list.insertBefore(card, previous);
            }} else {{
                const next = card.nextElementSibling;
                if (next) list.insertBefore(next, card);
            }}
            refreshMoveButtons();
            if (!sameOrder(previousOrder, order())) saveOrder(previousOrder);
            return;
        }}
        const addButton = event.target.closest(".vibe-preset-add");
        if (addButton) {{
            const form = addButton.closest(".vibe-preset-form");
            if (form.querySelectorAll(".vibe-preset-set").length < maxVibes && vibeLibrary.length) {{
                form.querySelector(".vibe-preset-set-list").appendChild(createRow());
                updateTotal(form);
            }}
            return;
        }}
        const removeButton = event.target.closest(".vibe-preset-remove");
        if (removeButton) {{
            const form = removeButton.closest(".vibe-preset-form");
            removeButton.closest(".vibe-preset-set").remove();
            updateTotal(form);
        }}
    }});

    document.addEventListener("change", (event) => {{
        if (event.target.matches(".vibe-preset-reference")) {{
            populateInformation(event.target.closest(".vibe-preset-set"));
        }}
    }});

    document.addEventListener("input", (event) => {{
        const row = event.target.closest(".vibe-preset-set");
        if (!row) return;
        const form = row.closest(".vibe-preset-form");
        if (event.target.matches(".vibe-preset-strength-range")) {{
            row.querySelector(".vibe-preset-strength-number").value = event.target.value;
        }} else if (event.target.matches(".vibe-preset-strength-number")) {{
            row.querySelector(".vibe-preset-strength-range").value = event.target.value;
        }}
        updateTotal(form);
        if (form.classList.contains("vibe-preset-update-form")) setStatus(form, "");
    }});

    document.addEventListener("submit", async (event) => {{
        const form = event.target.closest(".vibe-preset-form");
        if (!form) return;
        event.preventDefault();
        const creating = form.classList.contains("vibe-preset-create-form");
        const button = form.querySelector('button[type="submit"]');
        button.disabled = true;
        button.textContent = creating ? "Creating..." : "Saving...";
        try {{
            const payload = await requestMutation(form);
            if (!creating) {{
                setStatus(form, "Preset saved.");
                const count = payload.preset.vibes.length;
                form.closest(".vibe-preset-card").querySelector(".vibe-preset-count").textContent =
                    count === 1 ? "1 Vibe" : `${{count}} Vibes`;
                return;
            }}
            const template = document.createElement("template");
            template.innerHTML = payload.card_html.trim();
            const card = template.content.firstElementChild;
            if (!list.querySelector(".vibe-preset-card")) list.replaceChildren();
            list.appendChild(card);
            document.querySelector(".new-vibe-preset-card").remove();
            newAction.href = "/admin/vibes/presets?new=1";
            newAction.textContent = "New preset";
            countLabel.textContent = payload.preset_count === 1
                ? "1 preset"
                : `${{payload.preset_count}} presets`;
            window.history.replaceState(
                null,
                "",
                `/admin/vibes/presets?view=${{encodeURIComponent(payload.preset.reference)}}`,
            );
            const createdForm = card.querySelector(".vibe-preset-form");
            updateTotal(createdForm);
            setStatus(createdForm, "Preset created.");
            refreshMoveButtons();
        }} catch (error) {{
            setStatus(form, error.message, true);
        }} finally {{
            if (button.isConnected) {{
                button.disabled = false;
                button.textContent = creating ? "Create preset" : "Save preset";
            }}
        }}
    }});

    document.querySelectorAll(".vibe-preset-form").forEach(updateTotal);
    refreshMoveButtons();
}})();
</script>
"""


@router.get("/admin/vibes", include_in_schema=False)
def vibes_root() -> RedirectResponse:
    return RedirectResponse("/admin/vibes/presets")


@router.get(
    "/admin/vibes/presets",
    response_class=HTMLResponse,
    include_in_schema=False,
)
def vibe_presets_page(
    view: str | None = None,
    new: bool = False,
) -> HTMLResponse:
    return render_page(
        "Vibe presets",
        "vibes",
        _vibe_presets_content(viewed_reference=view, show_new=new),
    )


async def _read_json(request: Request) -> dict[str, object]:
    body = await request.body()
    if len(body) > MAX_REQUEST_BODY_BYTES:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=400, detail="Invalid JSON body.") from error
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid JSON body.")
    return payload


@router.post("/admin/vibes/presets/create", include_in_schema=False)
async def create_vibe_preset(request: Request) -> JSONResponse:
    require_same_origin(request)
    payload = await _read_json(request)
    try:
        preset = create_preset(
            file_id=payload.get("file_id", ""),
            name=payload.get("name", ""),
            vibes=payload.get("vibes"),
            normalize_reference_strengths=payload.get(
                "normalize_reference_strengths",
                True,
            ),
        )
    except (VibePresetError, ValueError) as error:
        return JSONResponse({"detail": str(error)}, status_code=400)

    library = _library_state(load_vibe_catalog().vibes)
    return JSONResponse(
        {
            "preset": _preset_state(preset),
            "preset_count": len(load_preset_catalog().presets),
            "card_html": _preset_card(
                preset,
                library,
                editor_id="vibe-preset-editor-created",
                expanded=True,
            ),
        },
        status_code=201,
    )


@router.post("/admin/vibes/presets/update", include_in_schema=False)
async def save_vibe_preset(request: Request) -> JSONResponse:
    require_same_origin(request)
    payload = await _read_json(request)
    try:
        preset = update_preset(
            reference=payload.get("reference", ""),
            vibes=payload.get("vibes"),
            normalize_reference_strengths=payload.get(
                "normalize_reference_strengths",
                True,
            ),
        )
    except (VibePresetError, ValueError) as error:
        return JSONResponse({"detail": str(error)}, status_code=400)
    return JSONResponse({"preset": _preset_state(preset)})


@router.post("/admin/vibes/presets/order", include_in_schema=False)
async def save_vibe_preset_order(request: Request) -> Response:
    require_same_origin(request)
    payload = await _read_json(request)
    references = payload.get("references")
    if not isinstance(references, list):
        return JSONResponse(
            {"detail": "'references' must be a list."},
            status_code=400,
        )
    try:
        save_preset_order(references)
    except (VibePresetError, ValueError) as error:
        return JSONResponse({"detail": str(error)}, status_code=400)
    return Response(status_code=204)


@router.post("/admin/vibes/presets/delete", include_in_schema=False)
async def remove_vibe_preset(request: Request) -> JSONResponse:
    require_same_origin(request)
    payload = await _read_json(request)
    reference = payload.get("reference", "")
    try:
        delete_preset(reference)
    except (VibePresetError, ValueError) as error:
        return JSONResponse({"detail": str(error)}, status_code=400)
    return JSONResponse(
        {
            "deleted_reference": reference,
            "preset_count": len(load_preset_catalog().presets),
        }
    )
