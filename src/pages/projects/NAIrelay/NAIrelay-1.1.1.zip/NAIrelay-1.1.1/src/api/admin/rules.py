import html
import json
from urllib.parse import parse_qs, quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response

import config
from services.rules import (
    Rule,
    RuleError,
    create_rule,
    delete_rule,
    load_catalog,
    save_rule_order,
    set_rule_enabled,
    update_rule,
)
from .layout import render_page
from .security import require_same_origin
from .style_navigation import render_style_navigation


router = APIRouter()


def _wants_json(request: Request) -> bool:
    return request.headers.get("x-requested-with") == "fetch"


def _rule_state(rule: Rule) -> dict[str, object]:
    return {
        "name": rule.name,
        "enabled": rule.name in config.NAIRELAY_ENABLED_RULES,
        "prompt": rule.prompt,
        "negative_prompt": rule.negative_prompt,
        "prompt_excludes": rule.prompt_excludes,
        "negative_prompt_excludes": rule.negative_prompt_excludes,
    }


def _rule_card(rule: Rule, *, editor_id: str, expanded: bool = False) -> str:
    escaped_name = html.escape(rule.name, quote=True)
    checked = " checked" if rule.name in config.NAIRELAY_ENABLED_RULES else ""
    hidden = "" if expanded else " hidden"
    aria_expanded = "true" if expanded else "false"
    return f"""
<section class="panel preset-card" data-name="{escaped_name}">
    <div class="preset-card-header">
        <button class="preset-card-toggle" type="button" aria-expanded="{aria_expanded}" aria-controls="{editor_id}">
            <span class="preset-card-identity"><strong>{html.escape(rule.name)}</strong></span>
        </button>
        <div class="preset-card-controls">
            <label class="rule-enabled-label">
                <input class="rule-enabled-toggle" type="checkbox"{checked}>
                <span>Use</span>
            </label>
            <form class="rule-delete-form" method="post" action="/admin/styles/rules/delete">
                <input type="hidden" name="name" value="{escaped_name}">
                <button class="danger" type="submit">Delete</button>
            </form>
            <div class="preset-order-buttons" aria-label="Reorder {escaped_name}">
                <button type="button" class="preset-move-button" data-direction="-1" aria-label="Move {escaped_name} up">↑</button>
                <button type="button" class="preset-move-button" data-direction="1" aria-label="Move {escaped_name} down">↓</button>
            </div>
            <button type="button" class="preset-drag-handle" draggable="true" aria-label="Reorder {escaped_name}" title="Drag to reorder">⠿</button>
        </div>
    </div>
    <form id="{editor_id}" class="preset-form rule-update-form" method="post" action="/admin/styles/rules/update"{hidden}>
        <input type="hidden" name="name" value="{escaped_name}">
        <label>
            Positive prompt
            <textarea name="prompt" maxlength="10000" placeholder="Prompt appended to the positive prompt">{html.escape(rule.prompt)}</textarea>
        </label>
        <label>
            Negative prompt
            <textarea name="negative_prompt" maxlength="10000" placeholder="Prompt appended to the negative prompt">{html.escape(rule.negative_prompt)}</textarea>
        </label>
        <label>
            Positive prompt exclusions
            <textarea class="exclusion-input" name="prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(rule.prompt_excludes)}</textarea>
        </label>
        <label>
            Negative prompt exclusions
            <textarea class="exclusion-input" name="negative_prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(rule.negative_prompt_excludes)}</textarea>
        </label>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit">Save rule</button></div>
    </form>
</section>"""


def _rules_content(
    message: str = "",
    error: bool = False,
    viewed_name: str | None = None,
    show_new: bool = False,
    create_values: dict[str, str] | None = None,
) -> str:
    notice = ""
    if message:
        notice_class = "error" if error else "ok"
        notice = f'<p class="notice {notice_class}">{html.escape(message)}</p>'

    catalog = load_catalog()
    catalog_notices = "".join(
        f'<p class="notice error">{html.escape(catalog_error)}</p>'
        for catalog_error in catalog.errors
    )
    cards = [
        _rule_card(
            rule,
            editor_id=f"rule-editor-{index}",
            expanded=rule.name == viewed_name,
        )
        for index, rule in enumerate(catalog.rules)
    ]
    if not cards:
        cards.append(
            '<section class="panel preset-list-empty"><p class="empty">No rules yet.</p></section>'
        )

    values = create_values or {}
    new_card = ""
    if show_new:
        new_card = f"""
<section class="panel preset-card new-rule-card">
    <div class="preset-card-header">
        <div class="preset-card-identity">
            <strong>New rule</strong>
            <span>Create a rule. New rules start disabled.</span>
        </div>
        <a class="button-link" href="/admin/styles/rules">Cancel</a>
    </div>
    <form class="preset-form rule-create-form" method="post" action="/admin/styles/rules/create">
        <label>
            Rule name
            <input name="name" value="{html.escape(values.get('name', ''), quote=True)}" maxlength="80" placeholder="Rule name" required>
        </label>
        <label>
            Positive prompt
            <textarea name="prompt" maxlength="10000" placeholder="Prompt appended to the positive prompt">{html.escape(values.get('prompt', ''))}</textarea>
        </label>
        <label>
            Negative prompt
            <textarea name="negative_prompt" maxlength="10000" placeholder="Prompt appended to the negative prompt">{html.escape(values.get('negative_prompt', ''))}</textarea>
        </label>
        <label>
            Positive prompt exclusions
            <textarea class="exclusion-input" name="prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(values.get('prompt_excludes', ''))}</textarea>
        </label>
        <label>
            Negative prompt exclusions
            <textarea class="exclusion-input" name="negative_prompt_excludes" maxlength="10000" placeholder="Exact tags to remove, separated by commas or new lines">{html.escape(values.get('negative_prompt_excludes', ''))}</textarea>
        </label>
        <p class="preset-card-status notice" aria-live="polite" hidden></p>
        <div class="form-actions"><button type="submit">Create rule</button></div>
    </form>
</section>"""

    action_href = "/admin/styles/rules" if show_new else "/admin/styles/rules?new=1"
    action_label = "Close new rule" if show_new else "New rule"
    enabled_count = sum(
        rule.name in config.NAIRELAY_ENABLED_RULES for rule in catalog.rules
    )
    return f"""
<section class="panel styles-toolbar">
    <div class="setting">
        <div>
            <strong>Enabled rules</strong>
            <span id="enabled-rule-count">{enabled_count} / {len(catalog.rules)}</span>
        </div>
        <div class="styles-toolbar-actions">
            <span id="rule-order-status" class="style-order-status" aria-live="polite"></span>
            <span id="rule-action-status" class="style-order-status" aria-live="polite"></span>
            <a id="new-rule-action" class="button-link" href="{action_href}">{action_label}</a>
        </div>
    </div>
</section>
{notice}
{catalog_notices}
{new_card}
<div class="preset-card-list">{''.join(cards)}</div>
<script>
(() => {{
    const list = document.querySelector(".preset-card-list");
    const orderStatus = document.getElementById("rule-order-status");
    const actionStatus = document.getElementById("rule-action-status");
    const enabledCount = document.getElementById("enabled-rule-count");
    const newRuleAction = document.getElementById("new-rule-action");
    let draggedCard = null;
    let orderBeforeDrag = [];
    let savingOrder = false;

    const cards = () => Array.from(list.querySelectorAll(".preset-card[data-name]"));
    const order = () => cards().map((card) => card.dataset.name);
    const sameOrder = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);
    const refreshEnabledCount = () => {{
        enabledCount.textContent = `${{list.querySelectorAll(".rule-enabled-toggle:checked").length}} / ${{cards().length}}`;
    }};
    const setFormStatus = (form, message, error = false) => {{
        const status = form.querySelector(".preset-card-status");
        if (!status) return;
        status.textContent = message;
        status.classList.toggle("error", error);
        status.classList.toggle("ok", !error);
        status.hidden = !message;
    }};
    const requestMutation = async (url, body) => {{
        const response = await fetch(url, {{
            method: "POST",
            headers: {{"Accept": "application/json", "X-Requested-With": "fetch"}},
            body,
        }});
        let payload = {{}};
        try {{ payload = await response.json(); }} catch {{}}
        if (!response.ok) throw new Error(payload.detail || "Rule operation failed.");
        return payload;
    }};
    const requestForm = (form) => requestMutation(
        form.action,
        new URLSearchParams(new FormData(form)),
    );
    const applyRuleState = (form, rule) => {{
        for (const field of ["prompt", "negative_prompt", "prompt_excludes", "negative_prompt_excludes"]) {{
            form.elements[field].value = rule[field];
        }}
    }};
    const refreshMoveButtons = () => {{
        const current = cards();
        current.forEach((card, index) => {{
            card.querySelectorAll(".preset-move-button").forEach((button) => {{
                const direction = Number(button.dataset.direction);
                button.disabled = savingOrder || (direction < 0 ? index === 0 : index === current.length - 1);
            }});
            const handle = card.querySelector(".preset-drag-handle");
            handle.draggable = !savingOrder;
            handle.disabled = savingOrder;
        }});
    }};
    const restoreOrder = (names) => {{
        const byName = new Map(cards().map((card) => [card.dataset.name, card]));
        names.forEach((name) => {{ if (byName.has(name)) list.appendChild(byName.get(name)); }});
    }};
    const saveOrder = async (previousOrder) => {{
        savingOrder = true;
        orderStatus.textContent = "Saving order...";
        orderStatus.classList.remove("error");
        refreshMoveButtons();
        try {{
            const response = await fetch("/admin/styles/rules/order", {{
                method: "POST",
                headers: {{"Content-Type": "application/json"}},
                body: JSON.stringify({{names: order()}}),
            }});
            if (!response.ok) {{
                let message = "Could not save rule order.";
                try {{ const payload = await response.json(); if (payload.detail) message = payload.detail; }} catch {{}}
                throw new Error(message);
            }}
            orderStatus.textContent = "Order saved";
        }} catch (error) {{
            restoreOrder(previousOrder);
            orderStatus.textContent = error.message;
            orderStatus.classList.add("error");
        }} finally {{
            savingOrder = false;
            refreshMoveButtons();
        }}
    }};

    list.addEventListener("dragover", (event) => {{
        if (!draggedCard || savingOrder) return;
        event.preventDefault();
        const target = event.target.closest(".preset-card[data-name]");
        if (!target || target === draggedCard) return;
        const bounds = target.getBoundingClientRect();
        list.insertBefore(draggedCard, event.clientY < bounds.top + bounds.height / 2 ? target : target.nextSibling);
    }});
    list.addEventListener("drop", (event) => {{ if (draggedCard) event.preventDefault(); }});
    list.addEventListener("dragstart", (event) => {{
        const handle = event.target.closest(".preset-drag-handle");
        if (!handle || savingOrder) return event.preventDefault();
        draggedCard = handle.closest(".preset-card[data-name]");
        orderBeforeDrag = order();
        draggedCard.classList.add("dragging");
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", draggedCard.dataset.name);
    }});
    list.addEventListener("dragend", (event) => {{
        if (!event.target.closest(".preset-drag-handle") || !draggedCard) return;
        draggedCard.classList.remove("dragging");
        draggedCard = null;
        const changed = !sameOrder(orderBeforeDrag, order());
        refreshMoveButtons();
        if (changed) saveOrder(orderBeforeDrag);
    }});
    list.addEventListener("click", (event) => {{
        const toggle = event.target.closest(".preset-card-toggle");
        if (toggle) {{
            const editor = document.getElementById(toggle.getAttribute("aria-controls"));
            const expanded = toggle.getAttribute("aria-expanded") === "true";
            toggle.setAttribute("aria-expanded", String(!expanded));
            editor.hidden = expanded;
            return;
        }}
        const button = event.target.closest(".preset-move-button");
        if (!button || savingOrder) return;
        const card = button.closest(".preset-card[data-name]");
        const previousOrder = order();
        if (Number(button.dataset.direction) < 0) {{
            const previous = card.previousElementSibling;
            if (previous) list.insertBefore(card, previous);
        }} else {{
            const next = card.nextElementSibling;
            if (next) list.insertBefore(next, card);
        }}
        refreshMoveButtons();
        if (!sameOrder(previousOrder, order())) saveOrder(previousOrder);
    }});
    list.addEventListener("input", (event) => {{
        const form = event.target.closest(".rule-update-form");
        if (!form) return;
        form.dataset.editRevision = String(Number(form.dataset.editRevision || "0") + 1);
        if (form.querySelector(".preset-card-status").classList.contains("ok")) setFormStatus(form, "");
    }});
    list.addEventListener("change", async (event) => {{
        const toggle = event.target.closest(".rule-enabled-toggle");
        if (!toggle) return;
        const card = toggle.closest(".preset-card[data-name]");
        const requestedState = toggle.checked;
        toggle.disabled = true;
        try {{
            await requestMutation(
                "/admin/styles/rules/toggle",
                new URLSearchParams({{name: card.dataset.name, enabled: String(requestedState)}}),
            );
            actionStatus.textContent = requestedState ? "Rule enabled" : "Rule disabled";
            actionStatus.classList.remove("error");
        }} catch (error) {{
            toggle.checked = !requestedState;
            actionStatus.textContent = error.message;
            actionStatus.classList.add("error");
        }} finally {{
            toggle.disabled = false;
            refreshEnabledCount();
        }}
    }});

    document.addEventListener("submit", async (event) => {{
        const form = event.target.closest(".rule-delete-form, .rule-update-form, .rule-create-form");
        if (!form) return;
        event.preventDefault();
        if (form.classList.contains("rule-delete-form")) {{
            const card = form.closest(".preset-card[data-name]");
            const name = card.dataset.name;
            if (!window.confirm(`Delete rule "${{name}}"?`)) return;
            const button = form.querySelector('button[type="submit"]');
            button.disabled = true;
            button.textContent = "Deleting...";
            try {{
                await requestForm(form);
                card.remove();
                if (!cards().length) {{
                    const empty = document.createElement("section");
                    empty.className = "panel preset-list-empty";
                    empty.innerHTML = '<p class="empty">No rules yet.</p>';
                    list.replaceChildren(empty);
                }}
                refreshMoveButtons();
                refreshEnabledCount();
                actionStatus.textContent = "Rule deleted";
                actionStatus.classList.remove("error");
                const currentUrl = new URL(window.location.href);
                if (currentUrl.searchParams.get("view") === name) window.history.replaceState(null, "", "/admin/styles/rules");
            }} catch (error) {{
                actionStatus.textContent = error.message;
                actionStatus.classList.add("error");
                if (button.isConnected) {{ button.disabled = false; button.textContent = "Delete"; }}
            }}
            return;
        }}

        const button = form.querySelector('button[type="submit"]');
        const creating = form.classList.contains("rule-create-form");
        const submittedRevision = form.dataset.editRevision || "0";
        button.disabled = true;
        button.textContent = creating ? "Creating..." : "Saving...";
        try {{
            const payload = await requestForm(form);
            if (!creating) {{
                if ((form.dataset.editRevision || "0") === submittedRevision) {{
                    applyRuleState(form, payload.rule);
                    setFormStatus(form, "Rule saved.");
                }}
                return;
            }}
            const template = document.createElement("template");
            template.innerHTML = payload.card_html.trim();
            const card = template.content.firstElementChild;
            if (!cards().length) list.replaceChildren();
            list.appendChild(card);
            document.querySelector(".new-rule-card").remove();
            newRuleAction.href = "/admin/styles/rules?new=1";
            newRuleAction.textContent = "New rule";
            window.history.replaceState(null, "", `/admin/styles/rules?view=${{encodeURIComponent(payload.rule.name)}}`);
            setFormStatus(card.querySelector(".rule-update-form"), "Rule created.");
            refreshMoveButtons();
            refreshEnabledCount();
        }} catch (error) {{
            setFormStatus(form, error.message, true);
        }} finally {{
            if (button.isConnected) {{
                button.disabled = false;
                button.textContent = creating ? "Create rule" : "Save rule";
            }}
        }}
    }});

    refreshMoveButtons();
    refreshEnabledCount();
}})();
</script>
"""


def _render_rules_page(**kwargs: object) -> HTMLResponse:
    return render_page(
        "Rules",
        "styles",
        render_style_navigation("rules") + _rules_content(**kwargs),
    )


async def _read_rule_form(request: Request) -> dict[str, list[str]]:
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        return parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error


def _error_response(message: str, **kwargs: object) -> HTMLResponse:
    response = _render_rules_page(message=message, error=True, **kwargs)
    response.status_code = 400
    return response


@router.get("/admin/styles/rules", response_class=HTMLResponse, include_in_schema=False)
def rules_page(view: str | None = None, new: bool = False) -> HTMLResponse:
    return _render_rules_page(viewed_name=view, show_new=new)


@router.post("/admin/styles/rules/toggle", include_in_schema=False)
async def toggle_rule(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_rule_form(request)
    name = form.get("name", [""])[0]
    raw_enabled = form.get("enabled", [""])[0].strip().casefold()
    if raw_enabled not in {"true", "false"}:
        message = "'enabled' must be true or false."
        if _wants_json(request):
            return JSONResponse({"detail": message}, status_code=400)
        return _error_response(message, viewed_name=name)
    try:
        enabled_names = set_rule_enabled(name, raw_enabled == "true")
    except (RuleError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _error_response(str(error), viewed_name=name)
    if _wants_json(request):
        return JSONResponse({"name": name, "enabled": name in enabled_names})
    return RedirectResponse("/admin/styles/rules", status_code=303)


@router.post("/admin/styles/rules/order", include_in_schema=False)
async def save_order(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 262_144:
        raise HTTPException(status_code=413, detail="Request body is too large.")
    try:
        payload = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HTTPException(status_code=400, detail="Invalid JSON body.") from error
    names = payload.get("names") if isinstance(payload, dict) else None
    if not isinstance(names, list):
        raise HTTPException(status_code=400, detail="'names' must be a list.")
    try:
        save_rule_order(names)
    except (RuleError, ValueError) as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    return Response(status_code=204)


@router.post("/admin/styles/rules/create", include_in_schema=False)
async def create_rule_endpoint(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_rule_form(request)
    try:
        rule = create_rule(
            name=form.get("name", [""])[0],
            prompt=form.get("prompt", [""])[0],
            negative_prompt=form.get("negative_prompt", [""])[0],
            prompt_excludes=form.get("prompt_excludes", [""])[0],
            negative_prompt_excludes=form.get("negative_prompt_excludes", [""])[0],
        )
    except (RuleError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _error_response(
            str(error),
            show_new=True,
            create_values={
                field: form.get(field, [""])[0]
                for field in (
                    "name",
                    "prompt",
                    "negative_prompt",
                    "prompt_excludes",
                    "negative_prompt_excludes",
                )
            },
        )
    if _wants_json(request):
        return JSONResponse(
            {
                "rule": _rule_state(rule),
                "card_html": _rule_card(
                    rule,
                    editor_id="rule-editor-created",
                    expanded=True,
                ),
            },
            status_code=201,
        )
    return RedirectResponse(
        f"/admin/styles/rules?view={quote(rule.name, safe='')}",
        status_code=303,
    )


@router.post("/admin/styles/rules/update", include_in_schema=False)
async def update_rule_endpoint(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_rule_form(request)
    name = form.get("name", [""])[0]
    try:
        rule = update_rule(
            name=name,
            prompt=form.get("prompt", [""])[0],
            negative_prompt=form.get("negative_prompt", [""])[0],
            prompt_excludes=form.get("prompt_excludes", [""])[0],
            negative_prompt_excludes=form.get("negative_prompt_excludes", [""])[0],
        )
    except (RuleError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _error_response(str(error), viewed_name=name)
    if _wants_json(request):
        return JSONResponse({"rule": _rule_state(rule)})
    return RedirectResponse(
        f"/admin/styles/rules?view={quote(rule.name, safe='')}",
        status_code=303,
    )


@router.post("/admin/styles/rules/delete", include_in_schema=False)
async def delete_rule_endpoint(request: Request) -> Response:
    require_same_origin(request)
    form = await _read_rule_form(request)
    name = form.get("name", [""])[0]
    try:
        delete_rule(name)
    except (RuleError, ValueError) as error:
        if _wants_json(request):
            return JSONResponse({"detail": str(error)}, status_code=400)
        return _error_response(str(error), viewed_name=name)
    if _wants_json(request):
        return JSONResponse({"deleted_name": name})
    return RedirectResponse("/admin/styles/rules", status_code=303)
