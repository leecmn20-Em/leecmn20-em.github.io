def render_style_navigation(active: str) -> str:
    presets_class = "active" if active == "presets" else ""
    rules_class = "active" if active == "rules" else ""
    return f"""
<nav class="section-tabs" aria-label="Style sections">
    <a class="{presets_class}" href="/admin/styles">Presets</a>
    <a class="{rules_class}" href="/admin/styles/rules">Rules</a>
</nav>
"""
