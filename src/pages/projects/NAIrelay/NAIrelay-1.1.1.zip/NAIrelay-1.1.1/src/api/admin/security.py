from urllib.parse import urlparse

from fastapi import HTTPException, Request


def require_same_origin(request: Request) -> None:
    origin = request.headers.get("origin")
    if origin and urlparse(origin).netloc != request.headers.get("host"):
        raise HTTPException(status_code=403, detail="Cross-origin admin request denied.")
