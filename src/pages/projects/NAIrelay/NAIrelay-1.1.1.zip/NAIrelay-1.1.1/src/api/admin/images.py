import html
import shutil
from pathlib import Path
from urllib.parse import parse_qs, quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response

import config
from .layout import render_page
from .security import require_same_origin


router = APIRouter()
IMAGE_LOCATIONS = ("images", "favorite", "vault")

def _image_directories() -> dict[str, Path]:
    return {
        "images": config.IMAGE_DIR,
        "favorite": config.FAVORITE_DIR,
        "vault": config.VAULT_DIR,
    }


def _image_directory(location: str) -> Path:
    try:
        return _image_directories()[location]
    except KeyError as error:
        raise HTTPException(status_code=404, detail="Image location not found.") from error


def _list_images(directory: Path) -> list[Path]:
    images = []
    for path in directory.glob("*.png"):
        try:
            if path.is_file():
                images.append(path)
        except OSError:
            continue

    def modified_at(path: Path) -> float:
        try:
            return path.stat().st_mtime
        except OSError:
            return 0.0

    return sorted(images, key=lambda path: (modified_at(path), path.name), reverse=True)


def _image_path(directory: Path, filename: str) -> Path:
    if (
        not filename
        or len(filename) > 255
        or Path(filename).name != filename
        or Path(filename).suffix.lower() != ".png"
    ):
        raise ValueError("Invalid image filename.")
    return directory / filename



def _images_content(
    active_location: str,
    page: int = 1,
    message: str = "",
    error: bool = False,
) -> str:
    directories = _image_directories()
    location_images = {
        location: _list_images(directory)
        for location, directory in directories.items()
    }

    page_size = config.IMAGE_PAGE_SIZE
    active_images = location_images[active_location]
    total_images = len(active_images)
    total_pages = max(1, (total_images + page_size - 1) // page_size)
    current_page = min(max(page, 1), total_pages)
    page_start = (current_page - 1) * page_size
    page_images = active_images[page_start : page_start + page_size]

    tabs = []
    for location in IMAGE_LOCATIONS:
        active_class = " active" if location == active_location else ""
        tabs.append(
            f'<a class="viewer-tab{active_class}" '
            f'href="/admin/images?tab={location}">'
            f"{html.escape(location.capitalize())} "
            f'<span>{len(location_images[location])}</span></a>'
        )

    cards = []
    for path in page_images:
        filename = path.name
        escaped_filename = html.escape(filename)
        encoded_filename = quote(filename, safe="")
        cards.append(
            '<label class="image-card" title="'
            f'{html.escape(filename, quote=True)}">'
            f'<input type="checkbox" name="files" value="{html.escape(filename, quote=True)}">'
            f'<img src="/admin/images/file/{active_location}/{encoded_filename}" '
            'loading="lazy" alt="">'
            f'<span>{escaped_filename}</span>'
            '</label>'
        )

    if not cards:
        gallery = '<p class="gallery-empty">No PNG images.</p>'
    else:
        gallery = f'<div class="image-grid">{"".join(cards)}</div>'

    page_size_options = []
    for option in config.IMAGE_PAGE_SIZE_OPTIONS:
        selected = " selected" if option == page_size else ""
        page_size_options.append(
            f'<option value="{option}"{selected}>{option}</option>'
        )

    previous_page = max(1, current_page - 1)
    next_page = min(total_pages, current_page + 1)
    previous_class = " disabled" if current_page == 1 else ""
    next_class = " disabled" if current_page == total_pages else ""
    pagination = f"""
<div class="pagination">
    <a class="page-button{previous_class}" href="/admin/images?tab={active_location}&amp;page={previous_page}">Previous</a>
    <span>Page {current_page} / {total_pages}</span>
    <a class="page-button{next_class}" href="/admin/images?tab={active_location}&amp;page={next_page}">Next</a>
</div>
"""

    move_buttons = []
    for destination in IMAGE_LOCATIONS:
        if destination == active_location:
            continue
        move_buttons.append(
            f'<button type="submit" name="destination" value="{destination}">'
            f'Move to {html.escape(destination.capitalize())}</button>'
        )

    notice = ""
    if message:
        notice_class = "error" if error else "ok"
        notice = f'<p class="notice {notice_class}">{html.escape(message)}</p>'

    return f"""
<section class="image-manager">
    <div class="viewer-tabs">{"".join(tabs)}</div>
    {notice}
    <div class="gallery-toolbar">
        <form class="page-size-form" method="post" action="/admin/images/page-size">
            <input type="hidden" name="tab" value="{active_location}">
            <label>
                Per page
                <select name="page_size" onchange="this.form.submit()">{"".join(page_size_options)}</select>
            </label>
        </form>
        {pagination}
    </div>
    <form id="image-manager-form" method="post" action="/admin/images/move">
        <input type="hidden" name="source" value="{active_location}">
        <input type="hidden" name="page" value="{current_page}">
        <div class="selection-actions">
            <div>
                <button id="select-all-images" type="button">Select page</button>
                <button id="clear-image-selection" type="button">Clear</button>
            </div>
            <span id="image-selection-count">0 / {len(cards)} selected</span>
        </div>
        {gallery}
        {pagination}
        <div class="image-actions">
            {"".join(move_buttons)}
            <button
                class="danger"
                type="submit"
                formaction="/admin/images/delete"
                onclick="return confirm('Permanently delete the selected images?');"
            >Delete selected images</button>
        </div>
    </form>
</section>
<script>
(() => {{
    const form = document.getElementById("image-manager-form");
    const checkboxes = Array.from(form.querySelectorAll('input[name="files"]'));
    const count = document.getElementById("image-selection-count");

    const updateCount = () => {{
        const selected = checkboxes.filter((checkbox) => checkbox.checked).length;
        count.textContent = `${{selected}} / ${{checkboxes.length}} selected`;
    }};

    document.getElementById("select-all-images").addEventListener("click", () => {{
        checkboxes.forEach((checkbox) => {{ checkbox.checked = true; }});
        updateCount();
    }});
    document.getElementById("clear-image-selection").addEventListener("click", () => {{
        checkboxes.forEach((checkbox) => {{ checkbox.checked = false; }});
        updateCount();
    }});
    form.addEventListener("change", updateCount);
}})();
</script>
"""


@router.get("/admin/images", response_class=HTMLResponse, include_in_schema=False)
def images_page(
    tab: str = "images",
    page: int = 1,
    moved: int = 0,
    deleted: int = 0,
) -> HTMLResponse:
    if tab not in IMAGE_LOCATIONS:
        raise HTTPException(status_code=404, detail="Image location not found.")

    if deleted > 0:
        message = f"Deleted {deleted} image{'s' if deleted != 1 else ''}."
    elif moved > 0:
        message = f"Moved {moved} image{'s' if moved != 1 else ''}."
    else:
        message = ""
    return render_page("Images", "images", _images_content(tab, page, message))


@router.post("/admin/images/page-size", include_in_schema=False)
async def update_image_page_size(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 4_096:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
        tab = form.get("tab", ["images"])[0]
        page_size = int(form.get("page_size", [""])[0])
    except (UnicodeDecodeError, ValueError) as error:
        raise HTTPException(status_code=400, detail="Invalid page size.") from error

    if tab not in IMAGE_LOCATIONS:
        raise HTTPException(status_code=400, detail="Invalid image location.")

    try:
        config.update_image_page_size(page_size)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error

    return RedirectResponse(f"/admin/images?tab={tab}", status_code=303)


@router.get(
    "/admin/images/file/{location}/{filename}",
    response_class=FileResponse,
    include_in_schema=False,
)
def admin_image_file(location: str, filename: str) -> FileResponse:
    directory = _image_directory(location)
    try:
        path = _image_path(directory, filename)
    except ValueError as error:
        raise HTTPException(status_code=404, detail="Image not found.") from error
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Image not found.")

    return FileResponse(
        path,
        media_type="image/png",
        headers={"Cache-Control": "no-store"},
    )


def _image_move_error(
    location: str,
    message: str,
    status_code: int = 400,
    page: int = 1,
) -> HTMLResponse:
    response = render_page(
        "Images",
        "images",
        _images_content(location, page, message, error=True),
    )
    response.status_code = status_code
    return response


@router.post("/admin/images/move", include_in_schema=False)
async def move_images(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 1_048_576:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error

    source = form.get("source", [""])[0]
    destination = form.get("destination", [""])[0]
    filenames = form.get("files", [])
    try:
        page = max(1, int(form.get("page", ["1"])[0]))
    except ValueError:
        page = 1

    if source not in IMAGE_LOCATIONS:
        raise HTTPException(status_code=400, detail="Invalid source location.")
    if destination not in IMAGE_LOCATIONS or destination == source:
        return _image_move_error(source, "Select a different destination folder.", page=page)
    if not filenames:
        return _image_move_error(source, "Select at least one image.", page=page)
    if len(filenames) > 5_000:
        return _image_move_error(source, "Too many images were selected.", page=page)

    source_directory = _image_directory(source)
    destination_directory = _image_directory(destination)
    moves: list[tuple[Path, Path]] = []

    try:
        for filename in dict.fromkeys(filenames):
            source_path = _image_path(source_directory, filename)
            destination_path = _image_path(destination_directory, filename)
            if not source_path.is_file():
                return _image_move_error(source, f"Image not found: {filename}", page=page)
            if destination_path.exists():
                return _image_move_error(
                    source,
                    f"Destination already contains: {filename}",
                    page=page,
                )
            moves.append((source_path, destination_path))
    except ValueError as error:
        return _image_move_error(source, str(error), page=page)
    except OSError:
        return _image_move_error(
            source,
            "Unable to validate the selected images.",
            500,
            page,
        )

    moved_count = 0
    try:
        for source_path, destination_path in moves:
            shutil.move(source_path, destination_path)
            moved_count += 1
    except OSError:
        return _image_move_error(
            source,
            f"Move failed after {moved_count} image{'s' if moved_count != 1 else ''}.",
            500,
            page,
        )

    return RedirectResponse(
        f"/admin/images?tab={destination}&moved={moved_count}",
        status_code=303,
    )


@router.post("/admin/images/delete", include_in_schema=False)
async def delete_images(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 1_048_576:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error

    source = form.get("source", [""])[0]
    filenames = form.get("files", [])
    try:
        page = max(1, int(form.get("page", ["1"])[0]))
    except ValueError:
        page = 1

    if source not in IMAGE_LOCATIONS:
        raise HTTPException(status_code=400, detail="Invalid source location.")
    if not filenames:
        return _image_move_error(source, "Select at least one image.", page=page)
    if len(filenames) > 5_000:
        return _image_move_error(source, "Too many images were selected.", page=page)

    source_directory = _image_directory(source)
    paths: list[Path] = []

    try:
        for filename in dict.fromkeys(filenames):
            path = _image_path(source_directory, filename)
            if not path.is_file():
                return _image_move_error(source, f"Image not found: {filename}", page=page)
            paths.append(path)
    except ValueError as error:
        return _image_move_error(source, str(error), page=page)
    except OSError:
        return _image_move_error(
            source,
            "Unable to validate the selected images.",
            500,
            page,
        )

    deleted_count = 0
    try:
        for path in paths:
            path.unlink()
            deleted_count += 1
    except OSError:
        return _image_move_error(
            source,
            f"Deletion failed after {deleted_count} image{'s' if deleted_count != 1 else ''}.",
            500,
            page,
        )

    return RedirectResponse(
        f"/admin/images?tab={source}&page={page}&deleted={deleted_count}",
        status_code=303,
    )
