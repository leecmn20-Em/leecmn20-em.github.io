import html
import json
import os
from urllib.parse import parse_qs

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse, Response

import config
import server_control
from .layout import render_page
from .security import require_same_origin


router = APIRouter()


@router.get("/admin/config", response_class=HTMLResponse, include_in_schema=False)
def config_page() -> HTMLResponse:
    return render_page("Config", "config", _config_content())


def _config_content(
    message: str = "",
    error: bool = False,
) -> str:
    notice = ""
    if message:
        notice_class = "error" if error else "ok"
        notice = f'<p class="notice {notice_class}">{html.escape(message)}</p>'

    token_status = "Configured" if config.NOVELAI_TOKEN else "Missing"
    token_class = "ok" if config.NOVELAI_TOKEN else "warn"
    relay_key_status = "Configured" if config.NAIRELAY_ACCESS_KEY else "Missing"
    relay_key_class = "ok" if config.NAIRELAY_ACCESS_KEY else "warn"

    escaped_server_host = html.escape(config.SERVER_HOST, quote=True)
    if config.SERVER_HOST in {"0.0.0.0", "::"}:
        binding_note = (
            '<span class="warn">The relay and Admin pages are accessible from '
            "the local network.</span>"
        )
    else:
        binding_note = "<span>Changing this restarts the server immediately.</span>"

    return f"""
<section class="panel">
    <div class="setting">
        <div>
            <strong>Server binding</strong>
            <code>{html.escape(config.SERVER_HOST)}:{config.SERVER_PORT}</code>
            {binding_note}
        </div>
        <form class="server-form" method="post" action="/admin/config/server">
            <input type="text" name="host" value="{escaped_server_host}" list="server-host-suggestions" maxlength="253" spellcheck="false" required>
            <datalist id="server-host-suggestions">
                <option value="127.0.0.1">This device only</option>
                <option value="0.0.0.0">Local network</option>
            </datalist>
            <input type="number" name="port" value="{config.SERVER_PORT}" min="1" max="65535" inputmode="numeric" required>
            <button type="submit">Save &amp; restart</button>
        </form>
    </div>
    <div class="setting">
        <div>
            <strong>NAIrelay folder</strong>
            <code>{html.escape(str(config.ROOT_DIR))}</code>
        </div>
        <form method="post" action="/admin/config/open-root">
            <button type="submit">Open folder</button>
        </form>
    </div>
    <div class="setting">
        <div>
            <strong>NovelAI token</strong>
            <span class="{token_class}">{token_status}</span>
        </div>
        <form class="token-form" method="post" action="/admin/config/token">
            <input type="password" name="token" placeholder="New NOVELAI_TOKEN" autocomplete="new-password" required>
            <button type="submit">Save</button>
        </form>
    </div>
    <div class="setting">
        <div>
            <strong>Relay access key</strong>
            <span class="{relay_key_class}">{relay_key_status}</span>
        </div>
        <form class="token-form" method="post" action="/admin/config/relay-key">
            <input type="password" name="key" placeholder="New numeric key" inputmode="numeric" pattern="[0-9]{{1,32}}" maxlength="32" autocomplete="new-password" required>
            <button type="submit">Save</button>
        </form>
    </div>
</section>
{notice}
"""



def _restart_content(request: Request, host: str, port: int) -> str:
    browser_host = host
    if host in {"0.0.0.0", "::"}:
        browser_host = request.url.hostname or (
            "127.0.0.1" if host == "0.0.0.0" else "::1"
        )
    if ":" in browser_host and not browser_host.startswith("["):
        browser_host = f"[{browser_host}]"

    target = f"{request.url.scheme}://{browser_host}:{port}/admin/config"
    escaped_target = html.escape(target, quote=True)
    serialized_target = (
        json.dumps(target)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
    )
    return f"""
<section class="panel restart-panel">
    <div class="setting">
        <div>
            <strong>Restarting server</strong>
            <code>{html.escape(host)}:{port}</code>
            <span id="restart-status">Waiting for the new address...</span>
            <a href="{escaped_target}">Open the new address manually</a>
        </div>
    </div>
</section>
<script>
(() => {{
    const target = {serialized_target};
    const retry = async () => {{
        try {{
            await fetch(target, {{ cache: "no-store", mode: "no-cors" }});
            window.location.replace(target);
        }} catch {{
            window.setTimeout(retry, 750);
        }}
    }};
    window.setTimeout(retry, 1000);
}})();
</script>
"""


@router.post("/admin/config/server", include_in_schema=False)
async def save_server_binding(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 4_096:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    try:
        form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    except UnicodeDecodeError as error:
        raise HTTPException(status_code=400, detail="Invalid form encoding.") from error

    old_binding = (config.SERVER_HOST, config.SERVER_PORT)
    try:
        host, port = config.update_server_binding(
            form.get("host", [""])[0],
            form.get("port", [""])[0],
        )
    except ValueError as error:
        response = render_page(
            "Config",
            "config",
            _config_content(str(error), error=True),
        )
        response.status_code = 400
        return response

    if (host, port) == old_binding:
        return RedirectResponse("/admin/config", status_code=303)

    if not server_control.request_restart():
        return render_page(
            "Config",
            "config",
            _config_content(
                "Server binding saved. Restart NAIrelay to apply it."
            ),
        )

    return render_page("Restarting", "config", _restart_content(request, host, port))



@router.post("/admin/config/open-root", include_in_schema=False)
def open_root(request: Request) -> Response:
    require_same_origin(request)
    if not hasattr(os, "startfile"):
        raise HTTPException(status_code=501, detail="Opening folders is not supported.")

    os.startfile(config.ROOT_DIR)  # type: ignore[attr-defined]
    return Response(status_code=204)


@router.post("/admin/config/token", include_in_schema=False)
async def save_token(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 16_384:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    token = form.get("token", [""])[0]

    try:
        config.update_novelai_token(token)
    except ValueError:
        response = render_page(
            "Config",
            "config",
            _config_content("Token cannot be empty.", error=True),
        )
        response.status_code = 400
        return response

    return RedirectResponse("/admin/config", status_code=303)


@router.post("/admin/config/relay-key", include_in_schema=False)
async def save_relay_key(request: Request) -> Response:
    require_same_origin(request)
    body = await request.body()
    if len(body) > 16_384:
        raise HTTPException(status_code=413, detail="Request body is too large.")

    form = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    key = form.get("key", [""])[0]

    try:
        config.update_relay_access_key(key)
    except ValueError:
        response = render_page(
            "Config",
            "config",
            _config_content("Relay key must contain 1 to 32 digits.", error=True),
        )
        response.status_code = 400
        return response

    return RedirectResponse("/admin/config", status_code=303)
