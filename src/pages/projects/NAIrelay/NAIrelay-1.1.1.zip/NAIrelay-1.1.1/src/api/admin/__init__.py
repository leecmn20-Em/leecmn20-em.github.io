from fastapi import APIRouter
from fastapi.responses import RedirectResponse

from .account import router as account_router
from .config_page import router as config_router
from .health import router as health_router
from .images import router as images_router
from .rules import router as rules_router
from .styles import router as styles_router
from .url_builder import router as url_router
from .vibe_presets import router as vibe_presets_router
from .vibes import router as vibes_router


router = APIRouter(tags=["admin"])


@router.get("/", include_in_schema=False)
def root() -> RedirectResponse:
    return RedirectResponse("/admin/health")


@router.get("/admin", include_in_schema=False)
def admin_root() -> RedirectResponse:
    return RedirectResponse("/admin/health")


router.include_router(health_router)
router.include_router(account_router)
router.include_router(config_router)
router.include_router(styles_router)
router.include_router(rules_router)
router.include_router(vibe_presets_router)
router.include_router(vibes_router)
router.include_router(url_router)
router.include_router(images_router)
