import asyncio
import hmac
import logging
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import FileResponse

import config
from models.generation import GenerationRequest
from services.image_cache import ImageCache
from services.NAI import NovelAIError, generate_image
from services.rules import RuleError, get_enabled_rules
from services.style_presets import (
    StylePreset,
    StylePresetError,
    get_selected_preset,
    load_catalog as load_style_catalog,
)
from services.vibe_presets import (
    ResolvedVibePreset,
    VibePresetError,
    load_catalog as load_vibe_preset_catalog,
    resolve_preset as resolve_vibe_preset,
)


logger = logging.getLogger(__name__)

router = APIRouter(tags=["relay"])
image_cache = ImageCache(config.IMAGE_DIR)
favorite_cache = ImageCache(config.FAVORITE_DIR)

generation_lock = asyncio.Lock()


def _require_access_key(provided_key: str | None) -> None:
    expected_key = config.NAIRELAY_ACCESS_KEY
    if not expected_key:
        raise HTTPException(
            status_code=503,
            detail="NAIrelay access key is not configured.",
        )
    if provided_key is None or not hmac.compare_digest(provided_key, expected_key):
        raise HTTPException(status_code=403, detail="Invalid NAIrelay access key.")


def _file_response(path: Path, cache_status: str) -> FileResponse:
    return FileResponse(
        path,
        media_type="image/png",
        headers={
            "Cache-Control": "no-cache",
            "X-NAIrelay-Cache": cache_status,
        },
    )


def _resolve_style_preset(
    generation_request: GenerationRequest,
) -> StylePreset | None:
    reference = generation_request.style
    if reference is None or not reference.strip():
        return get_selected_preset()
    if reference.casefold() == "none":
        return None
    return load_style_catalog().find(reference)


def _resolve_vibe_preset(
    generation_request: GenerationRequest,
) -> ResolvedVibePreset | None:
    if generation_request.vibe is None:
        return None
    preset = load_vibe_preset_catalog().find(generation_request.vibe)
    if preset is None:
        return None
    return resolve_vibe_preset(preset, model=generation_request.model)


def _get_cached_path(
    generation_request: GenerationRequest,
) -> Path | None:
    cached_path = favorite_cache.get(generation_request)
    if cached_path is None:
        cached_path = image_cache.get(generation_request)
    return cached_path


@router.get(
    "/image",
    response_class=FileResponse,
    responses={
        200: {"content": {"image/png": {}}},
        403: {"description": "Invalid NAIrelay access key."},
        422: {"description": "Invalid generation parameters."},
        502: {"description": "NovelAI API request failed."},
        503: {"description": "NAIrelay access key is not configured."},
    },
)
async def relay_image(
    request: Request,
    generation_request: Annotated[
        GenerationRequest,
        Query(),
    ],
) -> FileResponse:
    generation_request.set_cache_fields(request.query_params.keys())
    cached_path = _get_cached_path(generation_request)
    if cached_path is not None:
        return _file_response(cached_path, "HIT")

    _require_access_key(generation_request.key)

    async with generation_lock:
        cached_path = _get_cached_path(generation_request)
        if cached_path is not None:
            return _file_response(cached_path, "HIT")

        try:
            style_preset = _resolve_style_preset(generation_request)
        except StylePresetError as error:
            raise HTTPException(status_code=503, detail=str(error)) from error
        try:
            vibe_preset = _resolve_vibe_preset(generation_request)
        except VibePresetError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error

        try:
            rules = get_enabled_rules() if generation_request.rule else ()
        except RuleError as error:
            raise HTTPException(status_code=503, detail=str(error)) from error

        try:
            image_bytes = await generate_image(
                generation_request,
                style_preset=style_preset,
                vibe_preset=vibe_preset,
                rules=rules,
            )
            saved_path = image_cache.save(
                generation_request,
                image_bytes,
            )
        except NovelAIError as error:
            logger.warning("NovelAI image generation failed: %s", error)
            raise HTTPException(status_code=502, detail=str(error)) from error
        except OSError as error:
            logger.exception("Failed to save a generated image.")
            raise HTTPException(
                status_code=500,
                detail="Failed to save the generated image.",
            ) from error

    return _file_response(saved_path, "MISS")
