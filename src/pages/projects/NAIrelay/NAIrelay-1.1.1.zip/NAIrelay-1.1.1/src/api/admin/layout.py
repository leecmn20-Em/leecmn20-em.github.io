import html

from fastapi.responses import HTMLResponse

import config


def render_page(title: str, active: str, content: str) -> HTMLResponse:
    health_class = "active" if active == "health" else ""
    account_class = "active" if active == "account" else ""
    config_class = "active" if active == "config" else ""
    styles_class = "active" if active == "styles" else ""
    vibes_class = "active" if active == "vibes" else ""
    url_class = "active" if active == "url" else ""
    images_class = "active" if active == "images" else ""
    main_class = "wide" if active == "images" else ""
    stylesheet_path = config.STATIC_DIR / "admin.css"
    try:
        stylesheet_version = stylesheet_path.stat().st_mtime_ns
    except OSError:
        stylesheet_version = 0
    document = f"""<!doctype html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{html.escape(title)} · NAIrelay</title>
    <link rel="stylesheet" href="/static/admin.css?v={stylesheet_version}">
</head>
<body>
    <header>
        <a class="brand" href="/admin/health">NAIrelay</a>
        <nav>
            <a class="{health_class}" href="/admin/health">Health</a>
            <a class="{account_class}" href="/admin/account">Account</a>
            <a class="{config_class}" href="/admin/config">Config</a>
            <a class="{styles_class}" href="/admin/styles">Styles</a>
            <a class="{vibes_class}" href="/admin/vibes/presets">Vibes</a>
            <a class="{url_class}" href="/admin/url">URL</a>
            <a class="{images_class}" href="/admin/images">Images</a>
        </nav>
    </header>
    <main class="{main_class}">{content}</main>
</body>
</html>"""
    return HTMLResponse(document, headers={"Cache-Control": "no-store"})
