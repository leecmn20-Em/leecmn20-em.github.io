import html
import os
from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

import config
from .layout import render_page


router = APIRouter()

def _format_bytes(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} GB"


def _cache_stats(directory: Path) -> tuple[int, int]:
    count = 0
    size = 0

    for path in directory.rglob("*.png"):
        try:
            size += path.stat().st_size
            count += 1
        except OSError:
            continue

    return count, size



def _status_row(label: str, value: str, state: str = "") -> str:
    return (
        '<div class="row">'
        f"<span>{html.escape(label)}</span>"
        f'<strong class="{state}">{html.escape(value)}</strong>'
        "</div>"
    )


@router.get("/admin/health", response_class=HTMLResponse, include_in_schema=False)
def health_page() -> HTMLResponse:
    image_count, cache_size = _cache_stats(config.IMAGE_DIR)
    image_dir_ready = config.IMAGE_DIR.is_dir() and os.access(config.IMAGE_DIR, os.W_OK)

    content = f"""
<section class="panel">
    {_status_row('Local server', 'Connected', 'ok')}
    {_status_row('Image directory', 'Ready' if image_dir_ready else 'Unavailable', 'ok' if image_dir_ready else 'warn')}
    {_status_row('NovelAI token', 'Configured' if config.NOVELAI_TOKEN else 'Missing', 'ok' if config.NOVELAI_TOKEN else 'warn')}
    {_status_row('Relay access key', 'Configured' if config.NAIRELAY_ACCESS_KEY else 'Missing', 'ok' if config.NAIRELAY_ACCESS_KEY else 'warn')}
    {_status_row('Images', str(image_count))}
    {_status_row('Cache size', _format_bytes(cache_size))}
</section>
"""
    return render_page("Health", "health", content)
