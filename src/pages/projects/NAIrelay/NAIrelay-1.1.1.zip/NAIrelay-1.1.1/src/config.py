import ipaddress
import json
import os
import re
import threading
from pathlib import Path

from dotenv import load_dotenv, set_key

ROOT_DIR = Path(__file__).resolve().parents[1]
STATIC_DIR = Path(__file__).resolve().parent / "static"
RESOURCE_DIR = ROOT_DIR / "resource"
PRIVATE_DIR = ROOT_DIR / "private"
IMAGE_DIR = ROOT_DIR / "images"
FAVORITE_DIR = ROOT_DIR / "favorite"
VAULT_DIR = ROOT_DIR / "vault"
STYLE_DIR = RESOURCE_DIR / "styles"
STYLE_ORDER_PATH = RESOURCE_DIR / "styles-order.json"
RULES_PATH = RESOURCE_DIR / "rules.json"
RULE_ORDER_PATH = RESOURCE_DIR / "rules-order.json"
VIBE_DIR = RESOURCE_DIR / "vibes"
VIBE_ORDER_PATH = RESOURCE_DIR / "vibes-order.json"
VIBE_PRESET_DIR = RESOURCE_DIR / "vibe-presets"
VIBE_PRESET_ORDER_PATH = RESOURCE_DIR / "vibe-presets-order.json"
ENV_PATH = ROOT_DIR / ".env"
LOCAL_CONFIG_PATH = PRIVATE_DIR / "config.json"
LOG_PATH = PRIVATE_DIR / "nairelay.log"

IMAGE_PAGE_SIZE_OPTIONS = (25, 50, 100, 200, 500)
DEFAULT_IMAGE_PAGE_SIZE = 100
DEFAULT_SERVER_HOST = "127.0.0.1"
DEFAULT_SERVER_PORT = 8000

_hostname_pattern = re.compile(
    r"^(?=.{1,253}\.?$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)*"
    r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.?$"
)

_local_config_lock = threading.Lock()


def _read_local_config() -> dict[str, object]:
    try:
        data = json.loads(LOCAL_CONFIG_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_local_config(data: dict[str, object]) -> None:
    temporary_path = LOCAL_CONFIG_PATH.with_suffix(".json.tmp")
    serialized = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    temporary_path.write_text(serialized, encoding="utf-8")
    os.replace(temporary_path, LOCAL_CONFIG_PATH)


def _load_image_page_size() -> int:
    value = _read_local_config().get("image_page_size")
    if (
        isinstance(value, int)
        and not isinstance(value, bool)
        and value in IMAGE_PAGE_SIZE_OPTIONS
    ):
        return value
    return DEFAULT_IMAGE_PAGE_SIZE


def _normalize_server_host(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("Server host must be an IP address or hostname.")

    normalized = value.strip()
    if normalized.startswith("[") and normalized.endswith("]"):
        normalized = normalized[1:-1]
    if not normalized or any(character.isspace() for character in normalized):
        raise ValueError("Server host must be an IP address or hostname.")

    try:
        return str(ipaddress.ip_address(normalized))
    except ValueError:
        if (
            not _hostname_pattern.fullmatch(normalized)
            or all(character in "0123456789." for character in normalized)
        ):
            raise ValueError("Server host must be a valid IP address or hostname.")
        return normalized.rstrip(".").lower()


def _normalize_server_port(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        raise ValueError("Server port must be an integer between 1 and 65535.")
    try:
        normalized = int(value)
    except (TypeError, ValueError) as error:
        raise ValueError(
            "Server port must be an integer between 1 and 65535."
        ) from error
    if not 1 <= normalized <= 65_535:
        raise ValueError("Server port must be an integer between 1 and 65535.")
    return normalized


def _load_server_binding(image_page_size: int) -> tuple[str, int]:
    with _local_config_lock:
        local_config = _read_local_config()

        try:
            host = _normalize_server_host(local_config.get("server_host"))
        except ValueError:
            try:
                host = _normalize_server_host(
                    os.getenv("NAIRELAY_HOST", DEFAULT_SERVER_HOST)
                )
            except ValueError:
                host = DEFAULT_SERVER_HOST

        try:
            port = _normalize_server_port(local_config.get("server_port"))
        except ValueError:
            try:
                port = _normalize_server_port(
                    os.getenv("NAIRELAY_PORT", str(DEFAULT_SERVER_PORT))
                )
            except ValueError:
                port = DEFAULT_SERVER_PORT

        changed = (
            local_config.get("server_host") != host
            or local_config.get("server_port") != port
            or "image_page_size" not in local_config
        )
        local_config.setdefault("image_page_size", image_page_size)
        local_config["server_host"] = host
        local_config["server_port"] = port
        if changed:
            _write_local_config(local_config)

        return host, port


def _normalize_style_preset_reference(value: object) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    if not normalized or len(normalized) > 160:
        return None
    return normalized


def _load_style_preset(image_page_size: int) -> str | None:
    with _local_config_lock:
        local_config = _read_local_config()
        if "style_preset" in local_config:
            reference = _normalize_style_preset_reference(
                local_config.get("style_preset")
            )
            if local_config.get("style_preset") != reference:
                local_config["style_preset"] = reference
                _write_local_config(local_config)
            return reference

        local_config.setdefault("image_page_size", image_page_size)
        local_config["style_preset"] = None
        _write_local_config(local_config)
        return None


def _normalize_enabled_rules(value: object) -> list[str]:
    if not isinstance(value, list):
        return []

    normalized: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        name = item.strip()
        if name and len(name) <= 80 and name not in normalized:
            normalized.append(name)
    return normalized


def _load_enabled_rules(image_page_size: int) -> tuple[str, ...]:
    with _local_config_lock:
        local_config = _read_local_config()
        enabled_rules = _normalize_enabled_rules(
            local_config.get("enabled_rules", [])
        )
        if local_config.get("enabled_rules") != enabled_rules:
            local_config.setdefault("image_page_size", image_page_size)
            local_config["enabled_rules"] = enabled_rules
            _write_local_config(local_config)
        return tuple(enabled_rules)


PRIVATE_DIR.mkdir(parents=True, exist_ok=True)

load_dotenv(ENV_PATH)

NOVELAI_TOKEN = os.getenv("NOVELAI_TOKEN")
NAIRELAY_ACCESS_KEY = os.getenv("NAIRELAY_ACCESS_KEY")
IMAGE_PAGE_SIZE = _load_image_page_size()
NAIRELAY_STYLE_PRESET = _load_style_preset(IMAGE_PAGE_SIZE)
NAIRELAY_ENABLED_RULES = _load_enabled_rules(IMAGE_PAGE_SIZE)
SERVER_HOST, SERVER_PORT = _load_server_binding(IMAGE_PAGE_SIZE)

IMAGE_DIR.mkdir(parents=True, exist_ok=True)
FAVORITE_DIR.mkdir(parents=True, exist_ok=True)
VAULT_DIR.mkdir(parents=True, exist_ok=True)
STYLE_DIR.mkdir(parents=True, exist_ok=True)
VIBE_DIR.mkdir(parents=True, exist_ok=True)
VIBE_PRESET_DIR.mkdir(parents=True, exist_ok=True)


def update_novelai_token(token: str) -> None:
    normalized_token = token.strip()
    if not normalized_token:
        raise ValueError("NOVELAI_TOKEN cannot be empty.")

    set_key(ENV_PATH, "NOVELAI_TOKEN", normalized_token, quote_mode="always")
    os.environ["NOVELAI_TOKEN"] = normalized_token

    global NOVELAI_TOKEN
    NOVELAI_TOKEN = normalized_token


def update_relay_access_key(key: str) -> None:
    normalized_key = key.strip()
    if not (
        1 <= len(normalized_key) <= 32
        and normalized_key.isascii()
        and normalized_key.isdigit()
    ):
        raise ValueError("NAIRELAY_ACCESS_KEY must contain 1 to 32 digits.")

    set_key(
        ENV_PATH,
        "NAIRELAY_ACCESS_KEY",
        normalized_key,
        quote_mode="always",
    )
    os.environ["NAIRELAY_ACCESS_KEY"] = normalized_key

    global NAIRELAY_ACCESS_KEY
    NAIRELAY_ACCESS_KEY = normalized_key


def update_style_preset(reference: str | None) -> None:
    normalized_reference = reference.strip() if reference else ""
    if len(normalized_reference) > 160:
        raise ValueError("Style preset reference is too long.")

    with _local_config_lock:
        local_config = _read_local_config()
        local_config.setdefault("image_page_size", IMAGE_PAGE_SIZE)
        local_config["style_preset"] = normalized_reference or None
        _write_local_config(local_config)

    global NAIRELAY_STYLE_PRESET
    NAIRELAY_STYLE_PRESET = normalized_reference or None


def update_enabled_rules(names: list[str] | tuple[str, ...]) -> None:
    normalized_names = _normalize_enabled_rules(list(names))
    if len(normalized_names) != len(names):
        raise ValueError("Rule names must be unique non-empty strings up to 80 characters.")

    with _local_config_lock:
        local_config = _read_local_config()
        local_config.setdefault("image_page_size", IMAGE_PAGE_SIZE)
        local_config["enabled_rules"] = normalized_names
        _write_local_config(local_config)

    global NAIRELAY_ENABLED_RULES
    NAIRELAY_ENABLED_RULES = tuple(normalized_names)


def update_image_page_size(page_size: int) -> None:
    if page_size not in IMAGE_PAGE_SIZE_OPTIONS:
        available = ", ".join(str(value) for value in IMAGE_PAGE_SIZE_OPTIONS)
        raise ValueError(f"Image page size must be one of: {available}.")

    with _local_config_lock:
        local_config = _read_local_config()
        local_config["image_page_size"] = page_size
        _write_local_config(local_config)

    global IMAGE_PAGE_SIZE
    IMAGE_PAGE_SIZE = page_size


def update_server_binding(host: str, port: int | str) -> tuple[str, int]:
    normalized_host = _normalize_server_host(host)
    normalized_port = _normalize_server_port(port)

    with _local_config_lock:
        local_config = _read_local_config()
        local_config.setdefault("image_page_size", IMAGE_PAGE_SIZE)
        local_config["server_host"] = normalized_host
        local_config["server_port"] = normalized_port
        _write_local_config(local_config)

    global SERVER_HOST, SERVER_PORT
    SERVER_HOST = normalized_host
    SERVER_PORT = normalized_port
    return normalized_host, normalized_port
