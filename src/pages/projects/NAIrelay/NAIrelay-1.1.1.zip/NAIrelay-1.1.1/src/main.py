from typing import Any

import uvicorn
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from api.admin import router as admin_router
from api.relay import router as relay_router
import config
import server_control


def create_app(**kwargs: Any) -> FastAPI:
    kwargs.setdefault("title", "NAIrelay")
    kwargs.setdefault("version", "0.1.0")
    app = FastAPI(**kwargs)
    app.mount("/static", StaticFiles(directory=config.STATIC_DIR), name="static")
    app.include_router(relay_router)
    app.include_router(admin_router)
    return app

app = create_app(debug=False)


def run_server() -> None:
    while True:
        server = uvicorn.Server(
            uvicorn.Config(
                app,
                host=config.SERVER_HOST,
                port=config.SERVER_PORT,
            )
        )
        server_control.attach_server(server)
        try:
            server.run()
        finally:
            server_control.detach_server(server)

        if not server_control.consume_restart_request():
            break


if __name__ == "__main__":
    run_server()
