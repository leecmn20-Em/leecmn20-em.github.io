import json
import os
import re
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path

import config


FILE_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
MAX_PRESET_NAME_LENGTH = 80
MAX_PROMPT_LENGTH = 10_000
MAX_STYLE_FILE_BYTES = 1_048_576
MAX_STYLE_ORDER_FILE_BYTES = 1_048_576

_write_lock = threading.Lock()


class StylePresetError(ValueError):
    pass


@dataclass(frozen=True)
class StylePreset:
    file_id: str
    name: str
    prompt: str
    negative_prompt: str
    prompt_excludes: str = ""
    negative_prompt_excludes: str = ""

    @property
    def reference(self) -> str:
        return f"{self.file_id}:{self.name}"

    def cache_context(self) -> dict[str, str]:
        context = {
            "reference": self.reference,
            "prompt": self.prompt,
            "negative_prompt": self.negative_prompt,
        }
        if self.prompt_excludes:
            context["prompt_excludes"] = self.prompt_excludes
        if self.negative_prompt_excludes:
            context["negative_prompt_excludes"] = self.negative_prompt_excludes
        return context


@dataclass(frozen=True)
class StyleCatalog:
    presets: tuple[StylePreset, ...]
    errors: tuple[str, ...]

    def find(self, reference: str) -> StylePreset | None:
        return next(
            (preset for preset in self.presets if preset.reference == reference),
            None,
        )


def _validate_file_id(file_id: str) -> str:
    normalized = file_id.strip()
    if not FILE_ID_PATTERN.fullmatch(normalized):
        raise StylePresetError(
            "Style file ID must use 1 to 64 letters, digits, '_' or '-'."
        )
    return normalized


def _validate_preset_name(name: str) -> str:
    normalized = name.strip()
    if (
        not normalized
        or len(normalized) > MAX_PRESET_NAME_LENGTH
        or ":" in normalized
        or any(character in normalized for character in "\\/\r\n\t")
    ):
        raise StylePresetError(
            "Preset name must be 1 to 80 characters and cannot contain ':', slashes, or control characters."
        )
    return normalized


def _validate_prompt(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise StylePresetError(f"'{field_name}' must be a string.")
    normalized = value.strip(" ,")
    if len(normalized) > MAX_PROMPT_LENGTH:
        raise StylePresetError(
            f"'{field_name}' must be at most {MAX_PROMPT_LENGTH} characters."
        )
    return normalized


def _path_for(file_id: str) -> Path:
    return config.STYLE_DIR / f"{_validate_file_id(file_id)}.json"


def _load_file(path: Path) -> dict[str, dict[str, str]]:
    try:
        if path.stat().st_size > MAX_STYLE_FILE_BYTES:
            raise StylePresetError(f"{path.name} is larger than 1 MB.")
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError) as error:
        raise StylePresetError(f"Cannot read {path.name}: {error}") from error

    if not isinstance(raw_data, dict):
        raise StylePresetError(f"{path.name} must contain a JSON object.")

    normalized: dict[str, dict[str, str]] = {}
    for raw_name, raw_preset in raw_data.items():
        if not isinstance(raw_name, str):
            raise StylePresetError(f"{path.name} contains a non-string preset name.")
        name = _validate_preset_name(raw_name)
        if not isinstance(raw_preset, dict):
            raise StylePresetError(f"Preset '{name}' in {path.name} must be an object.")
        unexpected = set(raw_preset) - {
            "prompt",
            "negative_prompt",
            "prompt_excludes",
            "negative_prompt_excludes",
        }
        if unexpected:
            fields = ", ".join(sorted(str(field) for field in unexpected))
            raise StylePresetError(
                f"Preset '{name}' in {path.name} has unknown fields: {fields}."
            )
        normalized[name] = {
            "prompt": _validate_prompt(raw_preset.get("prompt", ""), "prompt"),
            "negative_prompt": _validate_prompt(
                raw_preset.get("negative_prompt", ""),
                "negative_prompt",
            ),
            "prompt_excludes": _validate_prompt(
                raw_preset.get("prompt_excludes", ""),
                "prompt_excludes",
            ),
            "negative_prompt_excludes": _validate_prompt(
                raw_preset.get("negative_prompt_excludes", ""),
                "negative_prompt_excludes",
            ),
        }
    return normalized


def _write_file(path: Path, data: dict[str, dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _load_preset_order() -> list[str]:
    path = config.STYLE_ORDER_PATH
    try:
        if path.stat().st_size > MAX_STYLE_ORDER_FILE_BYTES:
            raise StylePresetError(f"{path.name} is larger than 1 MB.")
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, json.JSONDecodeError) as error:
        raise StylePresetError(f"Cannot read {path.name}: {error}") from error

    if not isinstance(data, dict) or data.get("version") != 1:
        raise StylePresetError(f"{path.name} must be a version 1 order manifest.")
    references = data.get("references")
    if (
        not isinstance(references, list)
        or any(not isinstance(reference, str) for reference in references)
        or len(set(references)) != len(references)
    ):
        raise StylePresetError(
            f"{path.name} must contain a unique string reference list."
        )
    return references


def _write_preset_order(references: list[str]) -> None:
    path = config.STYLE_ORDER_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(
                {"version": 1, "references": references},
                file,
                ensure_ascii=False,
                indent=2,
            )
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def load_catalog() -> StyleCatalog:
    presets: list[StylePreset] = []
    errors: list[str] = []
    config.STYLE_DIR.mkdir(parents=True, exist_ok=True)

    for path in sorted(config.STYLE_DIR.glob("*.json"), key=lambda item: item.name.lower()):
        try:
            file_id = _validate_file_id(path.stem)
            data = _load_file(path)
            presets.extend(
                StylePreset(
                    file_id=file_id,
                    name=name,
                    prompt=values["prompt"],
                    negative_prompt=values["negative_prompt"],
                    prompt_excludes=values["prompt_excludes"],
                    negative_prompt_excludes=values["negative_prompt_excludes"],
                )
                for name, values in data.items()
            )
        except StylePresetError as error:
            errors.append(str(error))

    presets.sort(key=lambda preset: (preset.file_id.lower(), preset.name.lower()))
    try:
        order = _load_preset_order()
    except StylePresetError as error:
        errors.append(str(error))
    else:
        positions = {reference: index for index, reference in enumerate(order)}
        alphabetical_position = {
            preset.reference: index for index, preset in enumerate(presets)
        }
        presets.sort(
            key=lambda preset: (
                0 if preset.reference in positions else 1,
                positions.get(
                    preset.reference,
                    alphabetical_position[preset.reference],
                ),
            )
        )
    return StyleCatalog(tuple(presets), tuple(errors))


def save_preset_order(references: list[str]) -> None:
    if any(not isinstance(reference, str) for reference in references):
        raise StylePresetError("Style order must contain string references.")
    if len(set(references)) != len(references):
        raise StylePresetError("Style order cannot contain duplicate references.")

    with _write_lock:
        catalog = load_catalog()
        current_references = {preset.reference for preset in catalog.presets}
        if set(references) != current_references:
            raise StylePresetError(
                "Style presets changed while reordering. Reload the page and try again."
            )
        _write_preset_order(references)


def get_selected_preset() -> StylePreset | None:
    reference = config.NAIRELAY_STYLE_PRESET
    if not reference:
        return None

    catalog = load_catalog()
    preset = catalog.find(reference)
    if preset is None:
        detail = f"Selected style preset '{reference}' does not exist."
        if catalog.errors:
            detail = f"{detail} {' '.join(catalog.errors)}"
        raise StylePresetError(detail)
    return preset


def create_preset(
    file_id: str,
    name: str,
    prompt: str,
    negative_prompt: str,
    prompt_excludes: str = "",
    negative_prompt_excludes: str = "",
) -> StylePreset:
    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    normalized_prompt = _validate_prompt(prompt, "prompt")
    normalized_negative = _validate_prompt(negative_prompt, "negative_prompt")
    normalized_prompt_excludes = _validate_prompt(
        prompt_excludes,
        "prompt_excludes",
    )
    normalized_negative_prompt_excludes = _validate_prompt(
        negative_prompt_excludes,
        "negative_prompt_excludes",
    )
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name in data:
            raise StylePresetError(
                f"Preset '{normalized_file_id}:{normalized_name}' already exists."
            )
        data[normalized_name] = {
            "prompt": normalized_prompt,
            "negative_prompt": normalized_negative,
            "prompt_excludes": normalized_prompt_excludes,
            "negative_prompt_excludes": normalized_negative_prompt_excludes,
        }
        _write_file(path, data)

    return StylePreset(
        file_id=normalized_file_id,
        name=normalized_name,
        prompt=normalized_prompt,
        negative_prompt=normalized_negative,
        prompt_excludes=normalized_prompt_excludes,
        negative_prompt_excludes=normalized_negative_prompt_excludes,
    )


def update_preset(
    reference: str,
    prompt: str,
    negative_prompt: str,
    prompt_excludes: str = "",
    negative_prompt_excludes: str = "",
) -> StylePreset:
    try:
        file_id, name = reference.split(":", 1)
    except ValueError as error:
        raise StylePresetError("Invalid style preset reference.") from error

    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    normalized_prompt = _validate_prompt(prompt, "prompt")
    normalized_negative = _validate_prompt(negative_prompt, "negative_prompt")
    normalized_prompt_excludes = _validate_prompt(
        prompt_excludes,
        "prompt_excludes",
    )
    normalized_negative_prompt_excludes = _validate_prompt(
        negative_prompt_excludes,
        "negative_prompt_excludes",
    )
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name not in data:
            raise StylePresetError(f"Preset '{reference}' does not exist.")
        data[normalized_name] = {
            "prompt": normalized_prompt,
            "negative_prompt": normalized_negative,
            "prompt_excludes": normalized_prompt_excludes,
            "negative_prompt_excludes": normalized_negative_prompt_excludes,
        }
        _write_file(path, data)

    return StylePreset(
        file_id=normalized_file_id,
        name=normalized_name,
        prompt=normalized_prompt,
        negative_prompt=normalized_negative,
        prompt_excludes=normalized_prompt_excludes,
        negative_prompt_excludes=normalized_negative_prompt_excludes,
    )


def delete_preset(reference: str) -> None:
    if not isinstance(reference, str):
        raise StylePresetError("Invalid style preset reference.")
    try:
        file_id, name = reference.split(":", 1)
    except ValueError as error:
        raise StylePresetError("Invalid style preset reference.") from error

    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    normalized_reference = f"{normalized_file_id}:{normalized_name}"
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name not in data:
            raise StylePresetError(f"Preset '{normalized_reference}' does not exist.")

        order = _load_preset_order()
        del data[normalized_name]
        if data:
            _write_file(path, data)
        else:
            try:
                path.unlink()
            except OSError as error:
                raise StylePresetError(
                    f"Cannot delete {path.name}: {error}"
                ) from error

        if normalized_reference in order:
            _write_preset_order(
                [item for item in order if item != normalized_reference]
            )
