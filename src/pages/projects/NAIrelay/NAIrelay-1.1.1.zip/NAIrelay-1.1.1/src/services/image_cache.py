import hashlib
import json
import os
import tempfile
from datetime import datetime
from pathlib import Path

from models.generation import GenerationRequest


CACHE_KEY_VERSION = 2
IMAGE_SUFFIX = ".png"
TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S"


class ImageCache:
    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def key_for(
        request: GenerationRequest,
    ) -> str:
        cache_data = {
            "version": CACHE_KEY_VERSION,
            "request": request.cache_request_data(),
        }
        serialized = json.dumps(
            cache_data,
            ensure_ascii=False,
            separators=(",", ":"),
            sort_keys=True,
        )
        return hashlib.sha256(serialized.encode("utf-8")).hexdigest()

    def path_for(
        self,
        request: GenerationRequest,
        *,
        timestamp: datetime | None = None,
    ) -> Path:
        saved_at = timestamp or datetime.now()
        return self.directory / (
            f"{saved_at.strftime(TIMESTAMP_FORMAT)}_"
            f"{self.key_for(request)}{IMAGE_SUFFIX}"
        )

    def _find_by_key(self, cache_key: str) -> Path | None:
        timestamped_paths = []
        pattern = f"*_{cache_key}{IMAGE_SUFFIX}"

        for path in self.directory.glob(pattern):
            timestamp_text = path.name[: -(len(cache_key) + len(IMAGE_SUFFIX) + 1)]
            try:
                datetime.strptime(timestamp_text, TIMESTAMP_FORMAT)
            except ValueError:
                continue
            if path.is_file():
                timestamped_paths.append(path)

        if timestamped_paths:
            return max(timestamped_paths, key=lambda path: path.name)

        legacy_path = self.directory / f"{cache_key}{IMAGE_SUFFIX}"
        return legacy_path if legacy_path.is_file() else None

    def get(
        self,
        request: GenerationRequest,
    ) -> Path | None:
        return self._find_by_key(self.key_for(request))

    def save(
        self,
        request: GenerationRequest,
        image: bytes,
    ) -> Path:
        if not image:
            raise ValueError("Cannot cache an empty image.")

        destination = self.path_for(request)
        file_descriptor, temporary_name = tempfile.mkstemp(
            dir=self.directory,
            prefix=f".{destination.stem}.",
            suffix=".tmp",
        )
        temporary_path = Path(temporary_name)

        try:
            with os.fdopen(file_descriptor, "wb") as temporary_file:
                temporary_file.write(image)
                temporary_file.flush()
                os.fsync(temporary_file.fileno())

            os.replace(temporary_path, destination)
        except BaseException:
            temporary_path.unlink(missing_ok=True)
            raise

        return destination
