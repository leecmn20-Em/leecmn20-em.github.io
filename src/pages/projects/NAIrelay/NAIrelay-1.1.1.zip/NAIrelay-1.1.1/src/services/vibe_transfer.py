import asyncio
import base64
import binascii
import hashlib
import json
import os
import re
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path

import httpx

import config


ENCODE_VIBE_URL = "https://image.novelai.net/ai/encode-vibe"
REQUEST_TIMEOUT_SECONDS = 60.0
MAX_RETRIES = 3
RETRYABLE_STATUS_CODES = {502, 503, 504, 520}
MAX_SOURCE_IMAGE_BYTES = 20_971_520
MAX_STORED_VIBE_BYTES = 67_108_864
MAX_VIBE_ORDER_FILE_BYTES = 1_048_576
VIBE_HASH_PATTERN = re.compile(r"^[a-f0-9]{64}$")
VIBE_REFERENCE_PATTERN = re.compile(
    r"^(?!(?:[A-Za-z0-9._-]+/)*\.{1,2}(?:/|$))"
    r"(?:[A-Za-z0-9._-]+/)*[A-Za-z0-9._-]+$"
)

MODEL_NAMES = {
    "naid4.5f": "nai-diffusion-4-5-full",
    "naid4.5c": "nai-diffusion-4-5-curated",
    "naid4f": "nai-diffusion-4-full",
    "naid4c": "nai-diffusion-4-curated-preview",
}
MODEL_KEYS = {model: key for key, model in MODEL_NAMES.items()}

_encoding_lock = asyncio.Lock()
_storage_lock = threading.Lock()


class VibeTransferError(RuntimeError):
    pass


@dataclass(frozen=True)
class VibeEncoding:
    file_hash: str
    name: str
    encoded: str
    model: str
    information_extracted: float
    path: Path
    cached: bool


@dataclass(frozen=True)
class StoredVibeEncoding:
    model: str
    information_extracted: float

    @property
    def model_abbreviation(self) -> str:
        return MODEL_KEYS.get(self.model, self.model).upper()


@dataclass(frozen=True)
class StoredVibe:
    reference: str
    file_hash: str
    name: str
    encodings: tuple[StoredVibeEncoding, ...]
    image_data_url: str
    path: Path

    @property
    def model_abbreviations(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(encoding.model_abbreviation for encoding in self.encodings))


@dataclass(frozen=True)
class VibeCatalog:
    vibes: tuple[StoredVibe, ...]
    errors: tuple[str, ...]

    def find(self, reference: str) -> StoredVibe | None:
        return next((vibe for vibe in self.vibes if vibe.reference == reference), None)


def _resolve_model(model: str) -> str:
    if not isinstance(model, str):
        raise ValueError("Vibe model must be a string.")
    normalized = model.strip().lower()
    model_name = MODEL_NAMES.get(normalized, normalized)
    if model_name not in MODEL_KEYS:
        available = ", ".join(MODEL_NAMES)
        raise ValueError(f"Unsupported Vibe model. Available models: {available}.")
    return model_name


def _model_key(model: str) -> str:
    return MODEL_KEYS[_resolve_model(model)]


def _normalize_information_extracted(value: object) -> float:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise ValueError("information_extracted must be between 0.01 and 1.0.")
    try:
        normalized = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(
            "information_extracted must be between 0.01 and 1.0."
        ) from error
    if not 0.01 <= normalized <= 1.0:
        raise ValueError("information_extracted must be between 0.01 and 1.0.")
    return normalized


def _information_key(information_extracted: float) -> str:
    return format(information_extracted, ".15g")


def _normalize_name(name: str | None) -> str | None:
    if name is None:
        return None
    if not isinstance(name, str):
        raise ValueError("Vibe name must be a string.")
    normalized = name.strip()
    if not normalized:
        raise ValueError("Vibe name cannot be empty.")
    if len(normalized) > 100:
        raise ValueError("Vibe name must be at most 100 characters.")
    if any(ord(character) < 32 or ord(character) == 127 for character in normalized):
        raise ValueError("Vibe name cannot contain control characters.")
    return normalized


def _image_media_type(image: bytes) -> str | None:
    if image.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if image.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if image.startswith((b"GIF87a", b"GIF89a")):
        return "image/gif"
    if len(image) >= 12 and image[:4] == b"RIFF" and image[8:12] == b"WEBP":
        return "image/webp"
    return None


def _validate_source_image(image: bytes) -> str:
    if not image:
        raise ValueError("Vibe source image cannot be empty.")
    if len(image) > MAX_SOURCE_IMAGE_BYTES:
        raise ValueError("Vibe source image must be at most 20 MB.")
    media_type = _image_media_type(image)
    if media_type is None:
        raise ValueError("Vibe source image must be PNG, JPEG, GIF, or WebP.")
    return media_type


def _reference_for_path(path: Path) -> str:
    return path.relative_to(config.VIBE_DIR).with_suffix("").as_posix()


def _path_for_reference(reference: str) -> Path:
    if not isinstance(reference, str):
        raise VibeTransferError("Invalid Vibe reference.")
    normalized = reference.strip()
    reference_parts = normalized.split("/")
    if (
        not VIBE_REFERENCE_PATTERN.fullmatch(normalized)
        or any(part in {".", ".."} for part in reference_parts)
    ):
        raise VibeTransferError("Invalid Vibe reference.")

    try:
        vibe_directory = config.VIBE_DIR.resolve()
        path = vibe_directory.joinpath(*reference_parts).with_suffix(".json").resolve()
        path.relative_to(vibe_directory)
    except (OSError, RuntimeError, ValueError) as error:
        raise VibeTransferError("Invalid Vibe reference.") from error

    try:
        if not path.is_file():
            raise VibeTransferError(f"Vibe '{reference}' does not exist.")
    except OSError as error:
        raise VibeTransferError(f"Cannot access Vibe '{reference}'.") from error
    return path


def _read_raw_document(path: Path) -> dict[str, object]:
    try:
        if path.stat().st_size > MAX_STORED_VIBE_BYTES:
            raise VibeTransferError(f"{path.name} is larger than 64 MB.")
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise VibeTransferError(f"Cannot read stored Vibe: {path}") from error
    if not isinstance(data, dict):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")
    return data


def _normalize_encodings(
    data: dict[str, object],
    path: Path,
) -> dict[str, dict[str, str]]:
    raw_encodings = data.get("encodings", {})
    if not isinstance(raw_encodings, dict):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")

    # Compatibility with the previous one-model format:
    # {"model": "nai-diffusion-...", "encodings": {"1": "..."}}
    raw_model = data.get("model")
    if raw_encodings and all(isinstance(value, str) for value in raw_encodings.values()):
        if not isinstance(raw_model, str):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        raw_encodings = {raw_model: raw_encodings}

    normalized: dict[str, dict[str, str]] = {}
    for raw_model_key, raw_model_encodings in raw_encodings.items():
        if not isinstance(raw_model_key, str) or not isinstance(raw_model_encodings, dict):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        try:
            model_key = _model_key(raw_model_key)
        except ValueError as error:
            raise VibeTransferError(f"Stored Vibe is invalid: {path}: {error}") from error

        model_encodings: dict[str, str] = {}
        for raw_information, encoded in raw_model_encodings.items():
            if not isinstance(encoded, str) or not encoded:
                raise VibeTransferError(f"Stored Vibe is invalid: {path}")
            try:
                information = _normalize_information_extracted(raw_information)
            except ValueError as error:
                raise VibeTransferError(
                    f"Stored Vibe is invalid: {path}: {error}"
                ) from error
            model_encodings[_information_key(information)] = encoded
        normalized[model_key] = model_encodings
    return normalized


def _read_document(path: Path) -> dict[str, object]:
    data = _read_raw_document(path)
    file_hash = data.get("file_hash")
    if not isinstance(file_hash, str) or not VIBE_HASH_PATTERN.fullmatch(file_hash):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")

    raw_name = data.get("name")
    if not isinstance(raw_name, str):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")
    try:
        name = _normalize_name(raw_name)
    except ValueError as error:
        raise VibeTransferError(f"Stored Vibe is invalid: {path}: {error}") from error
    if name is None:
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")

    image_base64 = data.get("image_base64")
    if not isinstance(image_base64, str) or not image_base64:
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")
    try:
        image = base64.b64decode(image_base64, validate=True)
        _validate_source_image(image)
    except (ValueError, binascii.Error) as error:
        raise VibeTransferError(f"Stored Vibe has an invalid source image: {path}") from error

    return {
        "file_hash": file_hash,
        "name": name,
        "image_base64": image_base64,
        "encodings": _normalize_encodings(data, path),
    }


def _write_document(path: Path, data: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _load_vibe_order() -> list[str]:
    path = config.VIBE_ORDER_PATH
    try:
        if path.stat().st_size > MAX_VIBE_ORDER_FILE_BYTES:
            raise VibeTransferError(f"{path.name} is larger than 1 MB.")
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, json.JSONDecodeError) as error:
        raise VibeTransferError(f"Cannot read {path.name}: {error}") from error

    if not isinstance(data, dict) or data.get("version") != 1:
        raise VibeTransferError(f"{path.name} must be a version 1 order manifest.")
    references = data.get("references")
    if (
        not isinstance(references, list)
        or any(not isinstance(reference, str) for reference in references)
        or len(set(references)) != len(references)
    ):
        raise VibeTransferError(
            f"{path.name} must contain a unique string reference list."
        )
    return references


def _write_vibe_order(references: list[str]) -> None:
    path = config.VIBE_ORDER_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(
                {"version": 1, "references": references},
                file,
                ensure_ascii=False,
                indent=2,
            )
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _stored_vibe(path: Path, data: dict[str, object] | None = None) -> StoredVibe:
    document = data or _read_document(path)
    image_base64 = document["image_base64"]
    if not isinstance(image_base64, str):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")
    image = base64.b64decode(image_base64, validate=True)
    media_type = _validate_source_image(image)
    summaries: list[StoredVibeEncoding] = []
    encodings = document["encodings"]
    if not isinstance(encodings, dict):
        raise VibeTransferError(f"Stored Vibe is invalid: {path}")
    for model_key, model_encodings in encodings.items():
        if not isinstance(model_key, str) or not isinstance(model_encodings, dict):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        model = _resolve_model(model_key)
        for information_key in model_encodings:
            if not isinstance(information_key, str):
                raise VibeTransferError(f"Stored Vibe is invalid: {path}")
            summaries.append(
                StoredVibeEncoding(
                    model=model,
                    information_extracted=float(information_key),
                )
            )
    summaries.sort(
        key=lambda encoding: (
            encoding.model_abbreviation,
            encoding.information_extracted,
        )
    )
    return StoredVibe(
        reference=_reference_for_path(path),
        file_hash=str(document["file_hash"]),
        name=str(document["name"]),
        encodings=tuple(summaries),
        image_data_url=f"data:{media_type};base64,{image_base64}",
        path=path,
    )


def load_vibe_catalog() -> VibeCatalog:
    config.VIBE_DIR.mkdir(parents=True, exist_ok=True)
    vibes: list[StoredVibe] = []
    errors: list[str] = []
    paths = sorted(
        config.VIBE_DIR.rglob("*.json"),
        key=lambda path: path.relative_to(config.VIBE_DIR).as_posix().lower(),
    )
    for path in paths:
        try:
            vibes.append(_stored_vibe(path))
        except (VibeTransferError, ValueError, binascii.Error) as error:
            errors.append(str(error))
    vibes.sort(key=lambda vibe: (vibe.name.lower(), vibe.file_hash))
    try:
        order = _load_vibe_order()
    except VibeTransferError as error:
        errors.append(str(error))
    else:
        positions = {reference: index for index, reference in enumerate(order)}
        alphabetical_position = {
            vibe.reference: index for index, vibe in enumerate(vibes)
        }
        vibes.sort(
            key=lambda vibe: (
                0 if vibe.reference in positions else 1,
                positions.get(
                    vibe.reference,
                    alphabetical_position[vibe.reference],
                ),
            )
        )
    return VibeCatalog(tuple(vibes), tuple(errors))


def save_vibe_order(references: list[str]) -> None:
    if any(not isinstance(reference, str) for reference in references):
        raise VibeTransferError("Vibe order must contain string references.")
    if len(set(references)) != len(references):
        raise VibeTransferError("Vibe order cannot contain duplicate references.")

    with _storage_lock:
        catalog = load_vibe_catalog()
        current_references = {vibe.reference for vibe in catalog.vibes}
        if set(references) != current_references:
            raise VibeTransferError(
                "Vibes changed while reordering. Reload the page and try again."
            )
        _write_vibe_order(references)


def create_vibe(*, name: str, image: bytes) -> StoredVibe:
    normalized_name = _normalize_name(name)
    if normalized_name is None:
        raise ValueError("Vibe name cannot be empty.")
    _validate_source_image(image)
    file_hash = hashlib.sha256(image).hexdigest()
    destination = config.VIBE_DIR / f"{file_hash}.json"
    document: dict[str, object] = {
        "file_hash": file_hash,
        "name": normalized_name,
        "image_base64": base64.b64encode(image).decode("ascii"),
        "encodings": {},
    }

    with _storage_lock:
        matches = list(config.VIBE_DIR.rglob(f"{file_hash}.json"))
        if matches:
            raise VibeTransferError("This source image already exists as a Vibe.")
        try:
            _write_document(destination, document)
        except OSError as error:
            raise VibeTransferError(f"Cannot save Vibe: {destination}") from error
    return _stored_vibe(destination, document)


def rename_vibe(reference: str, *, name: str) -> StoredVibe:
    path = _path_for_reference(reference)
    normalized_name = _normalize_name(name)
    if normalized_name is None:
        raise ValueError("Vibe name cannot be empty.")

    with _storage_lock:
        document = _read_document(path)
        document["name"] = normalized_name
        try:
            _write_document(path, document)
        except OSError as error:
            raise VibeTransferError(f"Cannot rename Vibe: {path}") from error
    return _stored_vibe(path, document)


async def delete_vibe(reference: str) -> None:
    path = _path_for_reference(reference)
    async with _encoding_lock:
        with _storage_lock:
            order = _load_vibe_order()
            try:
                path.unlink()
            except FileNotFoundError as error:
                raise VibeTransferError(
                    f"Vibe '{reference}' does not exist."
                ) from error
            except OSError as error:
                raise VibeTransferError(f"Cannot delete Vibe: {path}") from error
            if reference in order:
                _write_vibe_order([item for item in order if item != reference])


async def delete_vibe_encoding(
    reference: str,
    *,
    model: str,
    information_extracted: str | int | float,
) -> None:
    path = _path_for_reference(reference)
    model_key = _model_key(model)
    information_key = _information_key(
        _normalize_information_extracted(information_extracted)
    )

    async with _encoding_lock:
        with _storage_lock:
            document = _read_document(path)
            encodings = document["encodings"]
            if not isinstance(encodings, dict):
                raise VibeTransferError(f"Stored Vibe is invalid: {path}")
            model_encodings = encodings.get(model_key)
            if (
                not isinstance(model_encodings, dict)
                or information_key not in model_encodings
            ):
                raise VibeTransferError("The selected Vibe encoding does not exist.")
            del model_encodings[information_key]
            if not model_encodings:
                del encodings[model_key]
            try:
                _write_document(path, document)
            except OSError as error:
                raise VibeTransferError(f"Cannot save Vibe: {path}") from error


async def add_vibe_encoding(
    reference: str,
    *,
    model: str,
    information_extracted: str | int | float = 1.0,
    token: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> VibeEncoding:
    path = _path_for_reference(reference)
    model_name = _resolve_model(model)
    model_key = MODEL_KEYS[model_name]
    information = _normalize_information_extracted(information_extracted)
    information_key = _information_key(information)

    async with _encoding_lock:
        document = _read_document(path)
        encodings = document["encodings"]
        if not isinstance(encodings, dict):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        model_encodings = encodings.setdefault(model_key, {})
        if not isinstance(model_encodings, dict):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        stored = model_encodings.get(information_key)
        if isinstance(stored, str) and stored:
            return VibeEncoding(
                file_hash=str(document["file_hash"]),
                name=str(document["name"]),
                encoded=stored,
                model=model_name,
                information_extracted=information,
                path=path,
                cached=True,
            )

        image_base64 = document["image_base64"]
        if not isinstance(image_base64, str):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        image = base64.b64decode(image_base64, validate=True)
        encoded = await encode_vibe(
            image,
            model=model_name,
            information_extracted=information,
            token=token,
            client=client,
        )

        with _storage_lock:
            current_document = _read_document(path)
            current_encodings = current_document["encodings"]
            if not isinstance(current_encodings, dict):
                raise VibeTransferError(f"Stored Vibe is invalid: {path}")
            current_model_encodings = current_encodings.setdefault(model_key, {})
            if not isinstance(current_model_encodings, dict):
                raise VibeTransferError(f"Stored Vibe is invalid: {path}")
            current_model_encodings[information_key] = encoded
            try:
                _write_document(path, current_document)
            except OSError as error:
                raise VibeTransferError(f"Cannot save Vibe encoding: {path}") from error

    return VibeEncoding(
        file_hash=str(document["file_hash"]),
        name=str(document["name"]),
        encoded=encoded,
        model=model_name,
        information_extracted=information,
        path=path,
        cached=False,
    )


def get_vibe_encoding(
    reference: str,
    *,
    model: str,
    information_extracted: str | int | float,
) -> VibeEncoding:
    """Return an existing exact model/IE encoding without calling NovelAI."""
    path = _path_for_reference(reference)
    model_name = _resolve_model(model)
    model_key = MODEL_KEYS[model_name]
    information = _normalize_information_extracted(information_extracted)
    information_key = _information_key(information)

    with _storage_lock:
        document = _read_document(path)
        encodings = document["encodings"]
        if not isinstance(encodings, dict):
            raise VibeTransferError(f"Stored Vibe is invalid: {path}")
        model_encodings = encodings.get(model_key)
        encoded = (
            model_encodings.get(information_key)
            if isinstance(model_encodings, dict)
            else None
        )
        if not isinstance(encoded, str) or not encoded:
            raise VibeTransferError(
                f"Vibe '{reference}' has no {model_key.upper()} encoding at "
                f"Information Extracted {information_key}."
            )

    return VibeEncoding(
        file_hash=str(document["file_hash"]),
        name=str(document["name"]),
        encoded=encoded,
        model=model_name,
        information_extracted=information,
        path=path,
        cached=True,
    )


def _read_image(image_path: str | Path) -> tuple[Path, bytes]:
    path = Path(image_path).expanduser()
    try:
        if not path.is_file():
            raise VibeTransferError(f"Vibe source image does not exist: {path}")
        image = path.read_bytes()
    except OSError as error:
        raise VibeTransferError(f"Cannot read Vibe source image: {path}") from error
    _validate_source_image(image)
    return path, image


async def encode_vibe(
    image: bytes,
    *,
    model: str,
    information_extracted: float = 1.0,
    token: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> str:
    """Encode image bytes with NovelAI and return the base64 API artifact."""
    _validate_source_image(image)
    model_name = _resolve_model(model)
    information = _normalize_information_extracted(information_extracted)
    api_token = token or config.NOVELAI_TOKEN
    if not api_token:
        raise VibeTransferError("NOVELAI_TOKEN is not configured.")

    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json",
    }
    payload = {
        "image": base64.b64encode(image).decode("ascii"),
        "information_extracted": information,
        "model": model_name,
    }

    if client is not None:
        encoded = await _post_encode(client, headers, payload)
    else:
        timeout = httpx.Timeout(REQUEST_TIMEOUT_SECONDS)
        async with httpx.AsyncClient(timeout=timeout) as owned_client:
            encoded = await _post_encode(owned_client, headers, payload)
    return base64.b64encode(encoded).decode("ascii")


async def encode_vibe_file(
    image_path: str | Path,
    *,
    name: str | None = None,
    model: str = "naid4.5f",
    information_extracted: float = 1.0,
    token: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> VibeEncoding:
    """Create or reuse a stored source image, then add a model encoding."""
    source_path, image = _read_image(image_path)
    requested_name = _normalize_name(name) or _normalize_name(source_path.stem)
    file_hash = hashlib.sha256(image).hexdigest()
    default_destination = config.VIBE_DIR / f"{file_hash}.json"

    with _storage_lock:
        matches = sorted(config.VIBE_DIR.rglob(f"{file_hash}.json"))
        destination = (
            default_destination
            if default_destination in matches or not matches
            else matches[0]
        )
        if destination.is_file():
            document = _read_document(destination)
            if requested_name and document["name"] != requested_name:
                document["name"] = requested_name
                _write_document(destination, document)
        else:
            document = {
                "file_hash": file_hash,
                "name": requested_name,
                "image_base64": base64.b64encode(image).decode("ascii"),
                "encodings": {},
            }
            _write_document(destination, document)

    return await add_vibe_encoding(
        _reference_for_path(destination),
        model=model,
        information_extracted=information_extracted,
        token=token,
        client=client,
    )


async def _post_encode(
    client: httpx.AsyncClient,
    headers: dict[str, str],
    payload: dict[str, object],
) -> bytes:
    last_error = "Unknown error"
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.post(
                ENCODE_VIBE_URL,
                headers=headers,
                json=payload,
            )
        except (httpx.TimeoutException, httpx.NetworkError) as error:
            last_error = str(error)
        else:
            if response.status_code == 401:
                raise VibeTransferError(
                    "NovelAI authentication failed. Check NOVELAI_TOKEN."
                )
            if response.status_code == 429:
                raise VibeTransferError(
                    "NovelAI rate limit exceeded. Try again later."
                )
            if response.status_code < 400:
                if not response.content:
                    raise VibeTransferError(
                        "NovelAI returned an empty Vibe encoding."
                    )
                return response.content
            if response.status_code not in RETRYABLE_STATUS_CODES:
                detail = response.text[:200]
                raise VibeTransferError(
                    f"NovelAI API returned HTTP {response.status_code}: {detail}"
                )
            last_error = f"HTTP {response.status_code}"

        if attempt < MAX_RETRIES:
            await asyncio.sleep(2 * attempt)

    raise VibeTransferError(
        f"Vibe encoding failed after {MAX_RETRIES} attempts: {last_error}"
    )
