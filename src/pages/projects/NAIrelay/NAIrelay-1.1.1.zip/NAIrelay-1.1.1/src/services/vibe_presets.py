import hashlib
import json
import os
import re
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path

import config
from services.vibe_transfer import (
    VIBE_REFERENCE_PATTERN,
    VibeTransferError,
    get_vibe_encoding,
    load_vibe_catalog,
)


FILE_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
MAX_PRESET_NAME_LENGTH = 80
MAX_PRESET_FILE_BYTES = 1_048_576
MAX_PRESET_ORDER_FILE_BYTES = 1_048_576
MAX_VIBES_PER_PRESET = 16

_write_lock = threading.Lock()


class VibePresetError(ValueError):
    pass


@dataclass(frozen=True)
class VibePresetItem:
    reference: str
    information_extracted: float
    strength: float


@dataclass(frozen=True)
class VibePreset:
    file_id: str
    name: str
    vibes: tuple[VibePresetItem, ...]
    normalize_reference_strengths: bool = True

    @property
    def reference(self) -> str:
        return f"{self.file_id}:{self.name}"


@dataclass(frozen=True)
class ResolvedVibePresetItem:
    encoded: str
    information_extracted: float
    strength: float


@dataclass(frozen=True)
class ResolvedVibePreset:
    vibes: tuple[ResolvedVibePresetItem, ...]
    normalize_reference_strengths: bool

    def cache_context(self) -> dict[str, object]:
        return {
            "version": 1,
            "normalize_reference_strength_multiple": (
                self.normalize_reference_strengths
            ),
            "vibes": [
                {
                    "encoding_sha256": hashlib.sha256(
                        item.encoded.encode("utf-8")
                    ).hexdigest(),
                    "information_extracted": item.information_extracted,
                    "strength": item.strength,
                }
                for item in self.vibes
            ],
        }


@dataclass(frozen=True)
class VibePresetCatalog:
    presets: tuple[VibePreset, ...]
    errors: tuple[str, ...]

    def find(self, reference: str) -> VibePreset | None:
        return next(
            (preset for preset in self.presets if preset.reference == reference),
            None,
        )


def _validate_file_id(file_id: str) -> str:
    if not isinstance(file_id, str):
        raise VibePresetError("Vibe preset file ID must be a string.")
    normalized = file_id.strip()
    if not FILE_ID_PATTERN.fullmatch(normalized):
        raise VibePresetError(
            "Vibe preset file ID must use 1 to 64 letters, digits, '_' or '-'."
        )
    return normalized


def _validate_preset_name(name: str) -> str:
    if not isinstance(name, str):
        raise VibePresetError("Preset name must be a string.")
    normalized = name.strip()
    if (
        not normalized
        or len(normalized) > MAX_PRESET_NAME_LENGTH
        or ":" in normalized
        or any(character in normalized for character in "\\/\r\n\t")
    ):
        raise VibePresetError(
            "Preset name must be 1 to 80 characters and cannot contain ':', "
            "slashes, or control characters."
        )
    return normalized


def _normalize_fraction(value: object, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        raise VibePresetError(f"'{field_name}' must be between 0.01 and 1.0.")
    try:
        normalized = float(value)
    except (TypeError, ValueError) as error:
        raise VibePresetError(
            f"'{field_name}' must be between 0.01 and 1.0."
        ) from error
    if not 0.01 <= normalized <= 1.0:
        raise VibePresetError(f"'{field_name}' must be between 0.01 and 1.0.")
    return normalized


def _fraction_key(value: float) -> str:
    return format(value, ".15g")


def _normalize_items(
    raw_items: object,
    *,
    require_available: bool,
) -> tuple[VibePresetItem, ...]:
    if not isinstance(raw_items, (list, tuple)):
        raise VibePresetError("'vibes' must be a list.")
    if not raw_items:
        raise VibePresetError("A Vibe preset must contain at least one Vibe.")
    if len(raw_items) > MAX_VIBES_PER_PRESET:
        raise VibePresetError(
            f"A Vibe preset can contain at most {MAX_VIBES_PER_PRESET} Vibes."
        )

    available = {}
    if require_available:
        available = {
            vibe.reference: {
                _fraction_key(encoding.information_extracted)
                for encoding in vibe.encodings
            }
            for vibe in load_vibe_catalog().vibes
        }

    items: list[VibePresetItem] = []
    seen: set[tuple[str, str]] = set()
    for index, raw_item in enumerate(raw_items, start=1):
        if not isinstance(raw_item, dict):
            raise VibePresetError(f"Vibe set {index} must be an object.")
        unexpected = set(raw_item) - {
            "reference",
            "information_extracted",
            "strength",
        }
        if unexpected:
            fields = ", ".join(sorted(str(field) for field in unexpected))
            raise VibePresetError(
                f"Vibe set {index} has unknown fields: {fields}."
            )

        reference = raw_item.get("reference")
        if (
            not isinstance(reference, str)
            or not VIBE_REFERENCE_PATTERN.fullmatch(reference.strip())
        ):
            raise VibePresetError(f"Vibe set {index} must select a Vibe.")
        reference = reference.strip()
        information = _normalize_fraction(
            raw_item.get("information_extracted"),
            f"vibes[{index}].information_extracted",
        )
        strength = _normalize_fraction(
            raw_item.get("strength"),
            f"vibes[{index}].strength",
        )
        pair = (reference, _fraction_key(information))
        if pair in seen:
            raise VibePresetError(
                f"Vibe set {index} duplicates the same Vibe and "
                "Information Extracted value."
            )
        seen.add(pair)

        if require_available:
            if reference not in available:
                raise VibePresetError(
                    f"Vibe set {index} references a Vibe that does not exist."
                )
            if pair[1] not in available[reference]:
                raise VibePresetError(
                    f"Vibe set {index} uses an Information Extracted value "
                    "that has not been encoded for this Vibe."
                )

        items.append(VibePresetItem(reference, information, strength))
    return tuple(items)


def _path_for(file_id: str) -> Path:
    return config.VIBE_PRESET_DIR / f"{_validate_file_id(file_id)}.json"


def _load_file(path: Path) -> dict[str, dict[str, object]]:
    try:
        if path.stat().st_size > MAX_PRESET_FILE_BYTES:
            raise VibePresetError(f"{path.name} is larger than 1 MB.")
        raw_data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, json.JSONDecodeError) as error:
        raise VibePresetError(f"Cannot read {path.name}: {error}") from error

    if not isinstance(raw_data, dict):
        raise VibePresetError(f"{path.name} must contain a JSON object.")

    normalized: dict[str, dict[str, object]] = {}
    for raw_name, raw_preset in raw_data.items():
        if not isinstance(raw_name, str):
            raise VibePresetError(f"{path.name} contains a non-string preset name.")
        name = _validate_preset_name(raw_name)
        if not isinstance(raw_preset, dict):
            raise VibePresetError(f"Preset '{name}' in {path.name} must be an object.")
        unexpected = set(raw_preset) - {
            "normalize_reference_strengths",
            "vibes",
        }
        if unexpected:
            fields = ", ".join(sorted(str(field) for field in unexpected))
            raise VibePresetError(
                f"Preset '{name}' in {path.name} has unknown fields: {fields}."
            )
        normalize = raw_preset.get("normalize_reference_strengths", True)
        if not isinstance(normalize, bool):
            raise VibePresetError(
                f"Preset '{name}' in {path.name} must use a boolean "
                "normalize_reference_strengths value."
            )
        items = _normalize_items(
            raw_preset.get("vibes"),
            require_available=False,
        )
        normalized[name] = {
            "normalize_reference_strengths": normalize,
            "vibes": [
                {
                    "reference": item.reference,
                    "information_extracted": item.information_extracted,
                    "strength": item.strength,
                }
                for item in items
            ],
        }
    return normalized


def _write_file(path: Path, data: dict[str, dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _load_preset_order() -> list[str]:
    path = config.VIBE_PRESET_ORDER_PATH
    try:
        if path.stat().st_size > MAX_PRESET_ORDER_FILE_BYTES:
            raise VibePresetError(f"{path.name} is larger than 1 MB.")
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, json.JSONDecodeError) as error:
        raise VibePresetError(f"Cannot read {path.name}: {error}") from error

    if not isinstance(data, dict) or data.get("version") != 1:
        raise VibePresetError(f"{path.name} must be a version 1 order manifest.")
    references = data.get("references")
    if (
        not isinstance(references, list)
        or any(not isinstance(reference, str) for reference in references)
        or len(set(references)) != len(references)
    ):
        raise VibePresetError(
            f"{path.name} must contain a unique string reference list."
        )
    return references


def _write_preset_order(references: list[str]) -> None:
    path = config.VIBE_PRESET_ORDER_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(
                {"version": 1, "references": references},
                file,
                ensure_ascii=False,
                indent=2,
            )
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _serialize_items(items: tuple[VibePresetItem, ...]) -> list[dict[str, object]]:
    return [
        {
            "reference": item.reference,
            "information_extracted": item.information_extracted,
            "strength": item.strength,
        }
        for item in items
    ]


def load_catalog() -> VibePresetCatalog:
    config.VIBE_PRESET_DIR.mkdir(parents=True, exist_ok=True)
    presets: list[VibePreset] = []
    errors: list[str] = []
    for path in sorted(
        config.VIBE_PRESET_DIR.glob("*.json"),
        key=lambda item: item.name.lower(),
    ):
        try:
            file_id = _validate_file_id(path.stem)
            data = _load_file(path)
            for name, values in data.items():
                presets.append(
                    VibePreset(
                        file_id=file_id,
                        name=name,
                        vibes=_normalize_items(
                            values["vibes"],
                            require_available=False,
                        ),
                        normalize_reference_strengths=bool(
                            values["normalize_reference_strengths"]
                        ),
                    )
                )
        except VibePresetError as error:
            errors.append(str(error))
    presets.sort(key=lambda preset: (preset.file_id.lower(), preset.name.lower()))
    try:
        order = _load_preset_order()
    except VibePresetError as error:
        errors.append(str(error))
    else:
        positions = {reference: index for index, reference in enumerate(order)}
        alphabetical_position = {
            preset.reference: index for index, preset in enumerate(presets)
        }
        presets.sort(
            key=lambda preset: (
                0 if preset.reference in positions else 1,
                positions.get(
                    preset.reference,
                    alphabetical_position[preset.reference],
                ),
            )
        )
    return VibePresetCatalog(tuple(presets), tuple(errors))


def save_preset_order(references: list[str]) -> None:
    if any(not isinstance(reference, str) for reference in references):
        raise VibePresetError("Vibe preset order must contain string references.")
    if len(set(references)) != len(references):
        raise VibePresetError("Vibe preset order cannot contain duplicate references.")

    with _write_lock:
        catalog = load_catalog()
        current_references = {preset.reference for preset in catalog.presets}
        if set(references) != current_references:
            raise VibePresetError(
                "Vibe presets changed while reordering. Reload the page and try again."
            )
        _write_preset_order(references)


def resolve_preset(preset: VibePreset, *, model: str) -> ResolvedVibePreset:
    resolved_items = []
    for item in preset.vibes:
        try:
            encoding = get_vibe_encoding(
                item.reference,
                model=model,
                information_extracted=item.information_extracted,
            )
        except (ValueError, VibeTransferError) as error:
            raise VibePresetError(
                f"Cannot resolve Vibe preset '{preset.reference}': {error}"
            ) from error
        resolved_items.append(
            ResolvedVibePresetItem(
                encoded=encoding.encoded,
                information_extracted=item.information_extracted,
                strength=item.strength,
            )
        )
    return ResolvedVibePreset(
        vibes=tuple(resolved_items),
        normalize_reference_strengths=preset.normalize_reference_strengths,
    )


def create_preset(
    *,
    file_id: str,
    name: str,
    vibes: object,
    normalize_reference_strengths: object = True,
) -> VibePreset:
    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    if not isinstance(normalize_reference_strengths, bool):
        raise VibePresetError("'normalize_reference_strengths' must be a boolean.")
    items = _normalize_items(vibes, require_available=True)
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name in data:
            raise VibePresetError(
                f"Preset '{normalized_file_id}:{normalized_name}' already exists."
            )
        data[normalized_name] = {
            "normalize_reference_strengths": normalize_reference_strengths,
            "vibes": _serialize_items(items),
        }
        _write_file(path, data)

    return VibePreset(
        normalized_file_id,
        normalized_name,
        items,
        normalize_reference_strengths,
    )


def update_preset(
    *,
    reference: str,
    vibes: object,
    normalize_reference_strengths: object = True,
) -> VibePreset:
    if not isinstance(reference, str):
        raise VibePresetError("Invalid Vibe preset reference.")
    try:
        file_id, name = reference.split(":", 1)
    except ValueError as error:
        raise VibePresetError("Invalid Vibe preset reference.") from error
    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    if not isinstance(normalize_reference_strengths, bool):
        raise VibePresetError("'normalize_reference_strengths' must be a boolean.")
    items = _normalize_items(vibes, require_available=True)
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name not in data:
            raise VibePresetError(f"Preset '{reference}' does not exist.")
        data[normalized_name] = {
            "normalize_reference_strengths": normalize_reference_strengths,
            "vibes": _serialize_items(items),
        }
        _write_file(path, data)

    return VibePreset(
        normalized_file_id,
        normalized_name,
        items,
        normalize_reference_strengths,
    )


def delete_preset(reference: str) -> None:
    if not isinstance(reference, str):
        raise VibePresetError("Invalid Vibe preset reference.")
    try:
        file_id, name = reference.split(":", 1)
    except ValueError as error:
        raise VibePresetError("Invalid Vibe preset reference.") from error

    normalized_file_id = _validate_file_id(file_id)
    normalized_name = _validate_preset_name(name)
    normalized_reference = f"{normalized_file_id}:{normalized_name}"
    path = _path_for(normalized_file_id)

    with _write_lock:
        data = _load_file(path)
        if normalized_name not in data:
            raise VibePresetError(
                f"Preset '{normalized_reference}' does not exist."
            )
        order = _load_preset_order()
        del data[normalized_name]
        if data:
            _write_file(path, data)
        else:
            try:
                path.unlink()
            except OSError as error:
                raise VibePresetError(
                    f"Cannot delete {path.name}: {error}"
                ) from error
        if normalized_reference in order:
            _write_preset_order(
                [item for item in order if item != normalized_reference]
            )
