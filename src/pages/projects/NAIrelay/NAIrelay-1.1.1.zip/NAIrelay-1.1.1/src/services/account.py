from dataclasses import dataclass

import httpx

import config


SUBSCRIPTION_URL = "https://image.novelai.net/user/subscription"
REQUEST_TIMEOUT_SECONDS = 10.0


class NovelAIAccountError(RuntimeError):
    pass


@dataclass(frozen=True)
class NovelAIAccountInfo:
    fixed_anlas: int
    purchased_anlas: int
    opus: bool

    @property
    def total_anlas(self) -> int:
        return self.fixed_anlas + self.purchased_anlas


def _anlas_value(value: object) -> int:
    if isinstance(value, bool):
        return 0
    try:
        amount = int(value)
    except (TypeError, ValueError):
        return 0
    return max(amount, 0)


def _parse_account_info(data: object) -> NovelAIAccountInfo:
    if not isinstance(data, dict):
        raise NovelAIAccountError("NovelAI returned an invalid subscription response.")

    raw_steps = data.get("trainingStepsLeft", {})
    steps = raw_steps if isinstance(raw_steps, dict) else {}
    raw_perks = data.get("perks", {})
    perks = raw_perks if isinstance(raw_perks, dict) else {}

    return NovelAIAccountInfo(
        fixed_anlas=_anlas_value(steps.get("fixedTrainingStepsLeft", 0)),
        purchased_anlas=_anlas_value(steps.get("purchasedTrainingSteps", 0)),
        opus=perks.get("unlimitedMaxPriority") is True,
    )


async def get_account_info(
    *,
    token: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> NovelAIAccountInfo:
    """Fetch the current NovelAI Anlas balance and Opus generation benefit."""
    api_token = token or config.NOVELAI_TOKEN
    if not api_token:
        raise NovelAIAccountError("NOVELAI_TOKEN is not configured.")

    headers = {"Authorization": f"Bearer {api_token}"}

    try:
        if client is not None:
            response = await client.get(SUBSCRIPTION_URL, headers=headers)
        else:
            timeout = httpx.Timeout(REQUEST_TIMEOUT_SECONDS)
            async with httpx.AsyncClient(timeout=timeout) as owned_client:
                response = await owned_client.get(SUBSCRIPTION_URL, headers=headers)
    except httpx.TimeoutException as error:
        raise NovelAIAccountError("NovelAI account request timed out.") from error
    except httpx.RequestError as error:
        raise NovelAIAccountError(f"NovelAI network error: {error}") from error

    if response.status_code == 401:
        raise NovelAIAccountError(
            "NovelAI authentication failed. Check NOVELAI_TOKEN."
        )
    if response.status_code == 429:
        raise NovelAIAccountError(
            "NovelAI rate limit exceeded. Try again later."
        )
    if response.status_code >= 400:
        detail = response.text[:200]
        raise NovelAIAccountError(
            f"NovelAI account API returned HTTP {response.status_code}: {detail}"
        )

    try:
        data = response.json()
    except ValueError as error:
        raise NovelAIAccountError(
            "NovelAI returned an invalid subscription response."
        ) from error
    return _parse_account_info(data)
