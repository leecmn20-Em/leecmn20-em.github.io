import json
import os
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path

import config


MAX_RULE_NAME_LENGTH = 80
MAX_PROMPT_LENGTH = 10_000
MAX_RULE_FILE_BYTES = 1_048_576

_write_lock = threading.Lock()


class RuleError(ValueError):
    pass


@dataclass(frozen=True)
class Rule:
    name: str
    prompt: str
    negative_prompt: str
    prompt_excludes: str = ""
    negative_prompt_excludes: str = ""


@dataclass(frozen=True)
class RuleCatalog:
    rules: tuple[Rule, ...]
    errors: tuple[str, ...]

    def find(self, name: str) -> Rule | None:
        return next((rule for rule in self.rules if rule.name == name), None)


def _validate_name(name: object) -> str:
    if not isinstance(name, str):
        raise RuleError("Rule name must be a string.")
    normalized = name.strip()
    if (
        not normalized
        or len(normalized) > MAX_RULE_NAME_LENGTH
        or any(character in normalized for character in "\\/\r\n\t")
    ):
        raise RuleError(
            "Rule name must be 1 to 80 characters and cannot contain slashes or control characters."
        )
    return normalized


def _validate_prompt(value: object, field_name: str) -> str:
    if not isinstance(value, str):
        raise RuleError(f"'{field_name}' must be a string.")
    normalized = value.strip(" ,")
    if len(normalized) > MAX_PROMPT_LENGTH:
        raise RuleError(
            f"'{field_name}' must be at most {MAX_PROMPT_LENGTH} characters."
        )
    return normalized


def _read_json(path: Path) -> object:
    try:
        if path.stat().st_size > MAX_RULE_FILE_BYTES:
            raise RuleError(f"{path.name} is larger than 1 MB.")
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except (OSError, json.JSONDecodeError) as error:
        raise RuleError(f"Cannot read {path.name}: {error}") from error


def _load_rules() -> dict[str, dict[str, str]]:
    raw_data = _read_json(config.RULES_PATH)
    if raw_data is None:
        return {}
    if not isinstance(raw_data, dict):
        raise RuleError(f"{config.RULES_PATH.name} must contain a JSON object.")

    normalized: dict[str, dict[str, str]] = {}
    allowed_fields = {
        "prompt",
        "negative_prompt",
        "prompt_excludes",
        "negative_prompt_excludes",
    }
    for raw_name, raw_rule in raw_data.items():
        name = _validate_name(raw_name)
        if not isinstance(raw_rule, dict):
            raise RuleError(f"Rule '{name}' must be an object.")
        unexpected = set(raw_rule) - allowed_fields
        if unexpected:
            fields = ", ".join(sorted(str(field) for field in unexpected))
            raise RuleError(f"Rule '{name}' has unknown fields: {fields}.")
        normalized[name] = {
            field: _validate_prompt(raw_rule.get(field, ""), field)
            for field in allowed_fields
        }
    return normalized


def _load_order() -> list[str]:
    raw_data = _read_json(config.RULE_ORDER_PATH)
    if raw_data is None:
        return []
    if not isinstance(raw_data, dict) or raw_data.get("version") != 1:
        raise RuleError(
            f"{config.RULE_ORDER_PATH.name} must be a version 1 order manifest."
        )
    names = raw_data.get("names")
    if (
        not isinstance(names, list)
        or any(not isinstance(name, str) for name in names)
        or len(set(names)) != len(names)
    ):
        raise RuleError(
            f"{config.RULE_ORDER_PATH.name} must contain a unique string name list."
        )
    return names


def _write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.stem}.",
        suffix=".tmp",
        text=True,
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8", newline="\n") as file:
            json.dump(data, file, ensure_ascii=False, indent=2)
            file.write("\n")
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary_path, path)
    except BaseException:
        temporary_path.unlink(missing_ok=True)
        raise


def _reconcile_enabled_rules(existing_names: set[str]) -> None:
    reconciled = tuple(
        name
        for name in config.NAIRELAY_ENABLED_RULES
        if name in existing_names
    )
    if reconciled != config.NAIRELAY_ENABLED_RULES:
        config.update_enabled_rules(reconciled)


def load_catalog() -> RuleCatalog:
    try:
        data = _load_rules()
    except RuleError as error:
        return RuleCatalog((), (str(error),))

    rules = [
        Rule(
            name=name,
            prompt=values["prompt"],
            negative_prompt=values["negative_prompt"],
            prompt_excludes=values["prompt_excludes"],
            negative_prompt_excludes=values["negative_prompt_excludes"],
        )
        for name, values in data.items()
    ]
    _reconcile_enabled_rules(set(data))

    rules.sort(key=lambda rule: rule.name.casefold())
    errors: list[str] = []
    try:
        order = _load_order()
    except RuleError as error:
        errors.append(str(error))
    else:
        positions = {name: index for index, name in enumerate(order)}
        alphabetical = {rule.name: index for index, rule in enumerate(rules)}
        rules.sort(
            key=lambda rule: (
                0 if rule.name in positions else 1,
                positions.get(rule.name, alphabetical[rule.name]),
            )
        )
    return RuleCatalog(tuple(rules), tuple(errors))


def get_enabled_rules() -> tuple[Rule, ...]:
    enabled = set(config.NAIRELAY_ENABLED_RULES)
    if not enabled:
        return ()
    catalog = load_catalog()
    if catalog.errors:
        raise RuleError(" ".join(catalog.errors))
    return tuple(rule for rule in catalog.rules if rule.name in enabled)


def set_rule_enabled(name: str, enabled: bool) -> tuple[str, ...]:
    normalized_name = _validate_name(name)
    catalog = load_catalog()
    if catalog.errors:
        raise RuleError(" ".join(catalog.errors))
    if catalog.find(normalized_name) is None:
        raise RuleError(f"Rule '{normalized_name}' does not exist.")

    enabled_names = list(config.NAIRELAY_ENABLED_RULES)
    if enabled and normalized_name not in enabled_names:
        enabled_names.append(normalized_name)
    elif not enabled:
        enabled_names = [item for item in enabled_names if item != normalized_name]
    config.update_enabled_rules(enabled_names)
    return config.NAIRELAY_ENABLED_RULES


def save_rule_order(names: list[str]) -> None:
    if any(not isinstance(name, str) for name in names):
        raise RuleError("Rule order must contain string names.")
    if len(set(names)) != len(names):
        raise RuleError("Rule order cannot contain duplicate names.")

    with _write_lock:
        catalog = load_catalog()
        if catalog.errors:
            raise RuleError(" ".join(catalog.errors))
        if set(names) != {rule.name for rule in catalog.rules}:
            raise RuleError(
                "Rules changed while reordering. Reload the page and try again."
            )
        _write_json(config.RULE_ORDER_PATH, {"version": 1, "names": names})


def create_rule(
    name: str,
    prompt: str,
    negative_prompt: str,
    prompt_excludes: str = "",
    negative_prompt_excludes: str = "",
) -> Rule:
    normalized_name = _validate_name(name)
    values = {
        "prompt": _validate_prompt(prompt, "prompt"),
        "negative_prompt": _validate_prompt(negative_prompt, "negative_prompt"),
        "prompt_excludes": _validate_prompt(prompt_excludes, "prompt_excludes"),
        "negative_prompt_excludes": _validate_prompt(
            negative_prompt_excludes,
            "negative_prompt_excludes",
        ),
    }
    with _write_lock:
        data = _load_rules()
        _reconcile_enabled_rules(set(data))
        if normalized_name in data:
            raise RuleError(f"Rule '{normalized_name}' already exists.")
        data[normalized_name] = values
        _write_json(config.RULES_PATH, data)
    return Rule(name=normalized_name, **values)


def update_rule(
    name: str,
    prompt: str,
    negative_prompt: str,
    prompt_excludes: str = "",
    negative_prompt_excludes: str = "",
) -> Rule:
    normalized_name = _validate_name(name)
    values = {
        "prompt": _validate_prompt(prompt, "prompt"),
        "negative_prompt": _validate_prompt(negative_prompt, "negative_prompt"),
        "prompt_excludes": _validate_prompt(prompt_excludes, "prompt_excludes"),
        "negative_prompt_excludes": _validate_prompt(
            negative_prompt_excludes,
            "negative_prompt_excludes",
        ),
    }
    with _write_lock:
        data = _load_rules()
        if normalized_name not in data:
            raise RuleError(f"Rule '{normalized_name}' does not exist.")
        data[normalized_name] = values
        _write_json(config.RULES_PATH, data)
    return Rule(name=normalized_name, **values)


def delete_rule(name: str) -> None:
    normalized_name = _validate_name(name)
    with _write_lock:
        data = _load_rules()
        if normalized_name not in data:
            raise RuleError(f"Rule '{normalized_name}' does not exist.")
        del data[normalized_name]
        if data:
            _write_json(config.RULES_PATH, data)
        else:
            try:
                config.RULES_PATH.unlink(missing_ok=True)
            except OSError as error:
                raise RuleError(
                    f"Cannot delete {config.RULES_PATH.name}: {error}"
                ) from error

        order = _load_order()
        if normalized_name in order:
            _write_json(
                config.RULE_ORDER_PATH,
                {
                    "version": 1,
                    "names": [item for item in order if item != normalized_name],
                },
            )

    if normalized_name in config.NAIRELAY_ENABLED_RULES:
        config.update_enabled_rules(
            [
                item
                for item in config.NAIRELAY_ENABLED_RULES
                if item != normalized_name
            ]
        )
