import asyncio
import io
import re
import zipfile

import httpx

import config
from models.generation import GenerationRequest
from services.rules import Rule
from services.style_presets import StylePreset
from services.vibe_presets import ResolvedVibePreset


IMAGE_GENERATION_URL = "https://image.novelai.net/ai/generate-image"
REQUEST_TIMEOUT_SECONDS = 180.0
MAX_RETRIES = 3

MODEL_NAMES = {
    "naid5f": "nai-diffusion-5-full",
    "naid5c": "nai-diffusion-5-curated",
    "naid4.5f": "nai-diffusion-4-5-full",
    "naid4.5c": "nai-diffusion-4-5-curated",
    "naid4f": "nai-diffusion-4-full",
    "naid4c": "nai-diffusion-4-curated-preview",
    "naid3": "nai-diffusion-3",
}

QUALITY_TAGS = {
    "naid5f": "very aesthetic, masterpiece, no text",
    "naid5c": "very aesthetic, masterpiece, no text",
    "naid4.5f": "very aesthetic, masterpiece, no text",
    "naid4.5c": "very aesthetic, masterpiece, no text, -0.8::feet::",
    "naid4f": "no text, best quality, very aesthetic, absurdres",
    "naid4c": "amazing quality, very aesthetic, absurdres",
    "naid3": "best quality, amazing quality, very aesthetic, absurdres",
}

UC_PRESETS = {
    "naid5f": {
        "heavy": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page",
        "light": "lowres, bad hands, bad anatomy, artistic error, sepia, white haze, worst quality, very displeasing, jpeg artifacts, 0::ai-generated::",
        "human_focus": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page, @_@, mismatched pupils, glowing eyes, bad anatomy",
        "furry_focus": "{worst quality}, distracting watermark, unfinished, bad quality, {widescreen}, upscale, {sequence}, {{grandfathered content}}, blurred foreground, chromatic aberration, sketch, everyone, [sketch background], simple, [flat colors], ych (character), outline, multiple scenes, [[horror (theme)]], comic",
        "none": "",
    },
    "naid5c": {
        "heavy": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page",
        "light": "lowres, bad hands, bad anatomy, artistic error, sepia, white haze, worst quality, very displeasing, jpeg artifacts, 0::ai-generated::",
        "human_focus": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page, @_@, mismatched pupils, glowing eyes, bad anatomy",
        "furry_focus": "{worst quality}, distracting watermark, unfinished, bad quality, {widescreen}, upscale, {sequence}, {{grandfathered content}}, blurred foreground, chromatic aberration, sketch, everyone, [sketch background], simple, [flat colors], ych (character), outline, multiple scenes, [[horror (theme)]], comic",
        "none": "",
    },
    "naid4.5f": {
        "heavy": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page",
        "light": "lowres, artistic error, scan artifacts, worst quality, bad quality, jpeg artifacts, multiple views, very displeasing, too many watermarks, negative space, blank page",
        "human_focus": "lowres, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, dithering, halftone, screentone, multiple views, logo, too many watermarks, negative space, blank page, @_@, mismatched pupils, glowing eyes, bad anatomy",
        "furry_focus": "{worst quality}, distracting watermark, unfinished, bad quality, {widescreen}, upscale, {sequence}, {{grandfathered content}}, blurred foreground, chromatic aberration, sketch, everyone, [sketch background], simple, [flat colors], ych (character), outline, multiple scenes, [[horror (theme)]], comic",
        "none": "",
    },
    "naid4.5c": {
        "heavy": "blurry, lowres, upscaled, artistic error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, halftone, multiple views, logo, too many watermarks, negative space, blank page",
        "light": "blurry, lowres, upscaled, artistic error, scan artifacts, jpeg artifacts, logo, too many watermarks, negative space, blank page",
        "human_focus": "blurry, lowres, upscaled, artistic error, film grain, scan artifacts, bad anatomy, bad hands, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, halftone, multiple views, logo, too many watermarks, @_@, mismatched pupils, glowing eyes, negative space, blank page",
        "furry_focus": "{worst quality}, distracting watermark, unfinished, bad quality, {widescreen}, upscale, {sequence}, {{grandfathered content}}, blurred foreground, chromatic aberration, sketch, everyone, [sketch background], simple, [flat colors], ych (character), outline, multiple scenes, [[horror (theme)]], comic",
        "none": "",
    },
    "naid4f": {
        "heavy": "blurry, lowres, error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, multiple views, logo, too many watermarks",
        "light": "blurry, lowres, error, worst quality, bad quality, jpeg artifacts, very displeasing",
        "none": "",
    },
    "naid4c": {
        "heavy": "blurry, lowres, error, film grain, scan artifacts, worst quality, bad quality, jpeg artifacts, very displeasing, chromatic aberration, logo, dated, signature, multiple views, gigantic breasts",
        "light": "blurry, lowres, error, worst quality, bad quality, jpeg artifacts, very displeasing, logo, dated, signature",
        "none": "",
    },
    "naid3": {
        "heavy": "lowres, {bad}, error, fewer, extra, missing, worst quality, jpeg artifacts, bad quality, watermark, unfinished, displeasing, chromatic aberration, signature, extra digits, artistic error, username, scan, [abstract]",
        "light": "lowres, jpeg artifacts, worst quality, watermark, blurry, very displeasing",
        "human_focus": "lowres, {bad}, error, fewer, extra, missing, worst quality, jpeg artifacts, bad quality, watermark, unfinished, displeasing, chromatic aberration, signature, extra digits, artistic error, username, scan, [abstract], bad anatomy, bad hands, @_@, mismatched pupils, heart-shaped pupils, glowing eyes",
        "none": "",
    },
}

RATING_TAGS = {
    "general": {
        "positive": "rating:general, safe",
        "negative": "nsfw",
    },
    "sensitive": {
        "positive": "rating:sensitive",
        "negative": "nsfw",
    },
    "questionable": {
        "positive": "rating:questionable, nsfw",
        "negative": "",
    },
    "explicit": {
        "positive": "rating:explicit, nsfw",
        "negative": "",
    },
}


class NovelAIError(RuntimeError):
    pass


def _join_prompt_parts(*parts: str) -> str:
    normalized = [part.strip(" ,") for part in parts if part.strip(" ,")]
    return ", ".join(normalized)


def _prompt_item_key(value: str) -> str:
    return " ".join(value.split()).casefold()


def _remove_excluded_prompt_items(prompt: str, exclusions: str) -> str:
    excluded_items = {
        _prompt_item_key(item)
        for item in re.split(r"[,\r\n]+", exclusions)
        if item.strip()
    }
    if not excluded_items:
        return prompt

    remaining_items = [
        item.strip()
        for item in prompt.split(",")
        if item.strip() and _prompt_item_key(item) not in excluded_items
    ]
    return ", ".join(remaining_items)


def compose_prompts(
    request: GenerationRequest,
    style_preset: StylePreset | None = None,
    rules: tuple[Rule, ...] = (),
) -> tuple[str, str]:
    model_presets = UC_PRESETS[request.model]
    if request.uc_preset not in model_presets:
        available = ", ".join(model_presets)
        raise NovelAIError(
            f"UC preset '{request.uc_preset}' is not available for {request.model}. "
            f"Available presets: {available}."
        )

    rating_tags = RATING_TAGS[request.rating]
    quality_tags = QUALITY_TAGS[request.model] if request.quality_tags else ""

    positive_prompt = _join_prompt_parts(
        "fur dataset" if request.furry else "",
        request.prompt,
        style_preset.prompt if style_preset else "",
        *(rule.prompt for rule in rules),
        rating_tags["positive"],
        quality_tags,
    )
    negative_prompt = _join_prompt_parts(
        model_presets[request.uc_preset],
        request.negative_prompt,
        style_preset.negative_prompt if style_preset else "",
        *(rule.negative_prompt for rule in rules),
        rating_tags["negative"],
    )
    prompt_exclusions = _join_prompt_parts(
        style_preset.prompt_excludes if style_preset else "",
        *(rule.prompt_excludes for rule in rules),
    )
    negative_prompt_exclusions = _join_prompt_parts(
        style_preset.negative_prompt_excludes if style_preset else "",
        *(rule.negative_prompt_excludes for rule in rules),
    )
    if prompt_exclusions:
        positive_prompt = _remove_excluded_prompt_items(
            positive_prompt,
            prompt_exclusions,
        )
    if negative_prompt_exclusions:
        negative_prompt = _remove_excluded_prompt_items(
            negative_prompt,
            negative_prompt_exclusions,
        )
    return positive_prompt, negative_prompt


def build_payload(
    request: GenerationRequest,
    style_preset: StylePreset | None = None,
    vibe_preset: ResolvedVibePreset | None = None,
    rules: tuple[Rule, ...] = (),
) -> dict:
    model_name = MODEL_NAMES[request.model]
    positive_prompt, negative_prompt = compose_prompts(
        request,
        style_preset,
        rules,
    )
    character_prompts = request.character_prompts()
    character_captions = [
        {
            "char_caption": prompt,
            "centers": [{"x": 0.5, "y": 0.5}],
        }
        for prompt, _ in character_prompts
    ]
    negative_character_captions = [
        {
            "char_caption": character_negative_prompt,
            "centers": [{"x": 0.5, "y": 0.5}],
        }
        for _, character_negative_prompt in character_prompts
    ]

    parameters = {
        "width": request.width,
        "height": request.height,
        "n_samples": 1,
        "sampler": request.sampler,
        "steps": request.steps,
        "noise_schedule": request.scheduler,
        "deliberate_euler_ancestral_bug": request.deliberate_euler_ancestral_bug,
        "scale": request.cfg_scale,
        "cfg_rescale": request.cfg_rescale,
        "negative_prompt": negative_prompt,
        "params_version": 4 if model_name.startswith("nai-diffusion-5") else 3,
        "legacy": False,
        "legacy_v3_extend": False,
        "skip_cfg_above_sigma": (
            58 if "4-5" in model_name else 19
        ) if request.var_plus else None,
    }

    if request.seed is not None:
        parameters["seed"] = request.seed
        parameters["extra_noise_seed"] = request.seed
    elif not model_name.startswith(("nai-diffusion-4", "nai-diffusion-5")):
        parameters["seed"] = 0
        parameters["extra_noise_seed"] = 0

    if model_name.startswith(("nai-diffusion-4", "nai-diffusion-5")):
        parameters.update({
            "autoSmea": True,
            "prefer_brownian": True,
            "ucPreset": 0,
            "use_coords": False,
            "legacy_uc": False,
            "add_original_image": True,
            "v4_prompt": {
                "caption": {
                    "base_caption": positive_prompt,
                    "char_captions": character_captions,
                },
                "use_coords": False,
                "use_order": True,
            },
            "v4_negative_prompt": {
                "caption": {
                    "base_caption": negative_prompt,
                    "char_captions": negative_character_captions,
                },
                "legacy_uc": False,
            },
        })

    if vibe_preset is not None:
        parameters.update({
            "reference_image_multiple": [
                vibe.encoded for vibe in vibe_preset.vibes
            ],
            "reference_strength_multiple": [
                vibe.strength for vibe in vibe_preset.vibes
            ],
            "reference_information_extracted_multiple": [
                vibe.information_extracted for vibe in vibe_preset.vibes
            ],
            "normalize_reference_strength_multiple": (
                vibe_preset.normalize_reference_strengths
            ),
        })

    return {
        "input": positive_prompt,
        "model": model_name,
        "action": "generate",
        "parameters": parameters,
    }


async def generate_image(
    request: GenerationRequest,
    *,
    style_preset: StylePreset | None = None,
    vibe_preset: ResolvedVibePreset | None = None,
    rules: tuple[Rule, ...] = (),
    token: str | None = None,
    client: httpx.AsyncClient | None = None,
) -> bytes:
    api_token = token or config.NOVELAI_TOKEN
    if not api_token:
        raise NovelAIError("NOVELAI_TOKEN is not configured.")

    payload = build_payload(request, style_preset, vibe_preset, rules)
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json",
    }

    if client is not None:
        archive = await _post(client, headers, payload)
    else:
        timeout = httpx.Timeout(REQUEST_TIMEOUT_SECONDS)
        async with httpx.AsyncClient(timeout=timeout) as owned_client:
            archive = await _post(owned_client, headers, payload)

    return _extract_png(archive)


async def _post(
    client: httpx.AsyncClient,
    headers: dict[str, str],
    payload: dict,
) -> bytes:
    last_error = "Unknown error"

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await client.post(
                IMAGE_GENERATION_URL,
                headers=headers,
                json=payload,
            )
        except (httpx.TimeoutException, httpx.NetworkError) as error:
            last_error = str(error)
        else:
            if response.status_code == 401:
                raise NovelAIError("NovelAI authentication failed. Check NOVELAI_TOKEN.")
            if response.status_code == 429:
                raise NovelAIError("NovelAI rate limit exceeded. Try again later.")
            if response.status_code < 400:
                return response.content
            if response.status_code not in {502, 503, 504, 520}:
                detail = response.text[:200]
                raise NovelAIError(
                    f"NovelAI API returned HTTP {response.status_code}: {detail}"
                )
            last_error = f"HTTP {response.status_code}"

        if attempt < MAX_RETRIES:
            await asyncio.sleep(2 * attempt)

    raise NovelAIError(
        f"NovelAI API request failed after {MAX_RETRIES} attempts: {last_error}"
    )


def _extract_png(archive: bytes) -> bytes:
    try:
        with zipfile.ZipFile(io.BytesIO(archive)) as zip_file:
            png_files = [
                entry
                for entry in zip_file.infolist()
                if not entry.is_dir() and entry.filename.lower().endswith(".png")
            ]
            if not png_files:
                raise NovelAIError("NovelAI response ZIP did not contain a PNG image.")
            return zip_file.read(png_files[0])
    except zipfile.BadZipFile as error:
        raise NovelAIError("NovelAI returned an invalid ZIP response.") from error
