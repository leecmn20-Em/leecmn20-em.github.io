import threading
from typing import Protocol


class StoppableServer(Protocol):
    should_exit: bool


_lock = threading.Lock()
_current_server: StoppableServer | None = None
_restart_requested = False


def attach_server(server: StoppableServer) -> None:
    global _current_server
    with _lock:
        _current_server = server


def detach_server(server: StoppableServer) -> None:
    global _current_server
    with _lock:
        if _current_server is server:
            _current_server = None


def request_restart() -> bool:
    global _restart_requested
    with _lock:
        server = _current_server
        if server is None:
            return False
        _restart_requested = True
        server.should_exit = True
        return True


def consume_restart_request() -> bool:
    global _restart_requested
    with _lock:
        requested = _restart_requested
        _restart_requested = False
        return requested


def clear_restart_request() -> None:
    global _restart_requested
    with _lock:
        _restart_requested = False
