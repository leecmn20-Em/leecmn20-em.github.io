import atexit
import ctypes
import logging
import sys
import threading
import time
import webbrowser
from ctypes import wintypes


if sys.platform != "win32":
    raise SystemExit("The NAIrelay tray launcher is only available on Windows.")


ERROR_ALREADY_EXISTS = 183
MUTEX_NAME = r"Local\NAIrelay.Tray"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.CreateMutexW.argtypes = (
    ctypes.c_void_p,
    wintypes.BOOL,
    wintypes.LPCWSTR,
)
kernel32.CreateMutexW.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
kernel32.CloseHandle.restype = wintypes.BOOL


def _acquire_single_instance_mutex() -> int | None:
    mutex = kernel32.CreateMutexW(None, False, MUTEX_NAME)
    last_error = ctypes.get_last_error()
    if not mutex:
        raise ctypes.WinError(last_error)
    if last_error == ERROR_ALREADY_EXISTS:
        kernel32.CloseHandle(mutex)
        return None
    return mutex


instance_mutex = _acquire_single_instance_mutex()
if instance_mutex is None:
    raise SystemExit(0)


@atexit.register
def _release_single_instance_mutex() -> None:
    if instance_mutex:
        kernel32.CloseHandle(instance_mutex)


import pystray  # noqa: E402
import uvicorn  # noqa: E402
from PIL import Image, ImageDraw  # noqa: E402

import config  # noqa: E402
import server_control  # noqa: E402
from main import app  # noqa: E402


STARTUP_TIMEOUT_SECONDS = 10.0
SHUTDOWN_TIMEOUT_SECONDS = 10.0

logging.basicConfig(
    filename=config.LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    encoding="utf-8",
)
logger = logging.getLogger("nairelay.tray")


def _create_tray_image() -> Image.Image:
    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((4, 4, 60, 60), radius=13, fill=(48, 86, 211, 255))
    draw.line((18, 46, 18, 18, 46, 46, 46, 18), fill="white", width=7)
    return image


def _browser_host(host: str) -> str:
    if host in {"0.0.0.0", "::"}:
        return "127.0.0.1"
    if ":" in host and not host.startswith("["):
        return f"[{host}]"
    return host


class TrayApplication:
    def __init__(self) -> None:
        self._shutdown_requested = threading.Event()
        self._server = self._create_server()
        self._server_thread = threading.Thread(
            target=self._run_server,
            name="nairelay-server",
            daemon=True,
        )
        self._icon = pystray.Icon(
            name="NAIrelay",
            title="NAIrelay",
            icon=_create_tray_image(),
            menu=pystray.Menu(
                pystray.MenuItem(self._status_text, self._ignore, enabled=False),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(
                    "Open admin page",
                    self._open_admin,
                ),
                pystray.MenuItem("Exit", self._exit),
            ),
        )

    @staticmethod
    def _create_server() -> uvicorn.Server:
        return uvicorn.Server(
            uvicorn.Config(
                app,
                host=config.SERVER_HOST,
                port=config.SERVER_PORT,
                log_config=None,
            )
        )

    def _status_text(self, item: pystray.MenuItem) -> str:
        del item
        if self._server.started and self._server_thread.is_alive():
            return f"Running on {config.SERVER_HOST}:{config.SERVER_PORT}"
        return "Server stopped"

    @staticmethod
    def _ignore(icon: pystray.Icon, item: pystray.MenuItem) -> None:
        del icon, item

    @staticmethod
    def _open_admin(icon: pystray.Icon, item: pystray.MenuItem) -> None:
        del icon, item
        host = _browser_host(config.SERVER_HOST)
        webbrowser.open(f"http://{host}:{config.SERVER_PORT}/admin")

    def _exit(self, icon: pystray.Icon, item: pystray.MenuItem) -> None:
        del item
        self._shutdown_requested.set()
        self._server.should_exit = True
        icon.stop()

    def _run_server(self) -> None:
        while not self._shutdown_requested.is_set():
            current_server = self._server
            server_control.attach_server(current_server)
            try:
                current_server.run()
            except BaseException:
                if not self._shutdown_requested.is_set():
                    logger.exception("The server stopped with an unexpected error.")
            finally:
                server_control.detach_server(current_server)

            if self._shutdown_requested.is_set():
                break
            if server_control.consume_restart_request():
                logger.info(
                    "Restarting NAIrelay on %s:%s.",
                    config.SERVER_HOST,
                    config.SERVER_PORT,
                )
                self._server = self._create_server()
                continue

            logger.error("The server stopped unexpectedly; closing the tray icon.")
            self._icon.stop()
            break

    def _start_server(self, icon: pystray.Icon) -> None:
        logger.info(
            "Starting NAIrelay on %s:%s.",
            config.SERVER_HOST,
            config.SERVER_PORT,
        )
        self._server_thread.start()

        deadline = time.monotonic() + STARTUP_TIMEOUT_SECONDS
        while (
            self._server_thread.is_alive()
            and not self._server.started
            and time.monotonic() < deadline
        ):
            time.sleep(0.05)

        if not self._server.started:
            logger.error(
                "NAIrelay did not start on %s:%s; closing the tray application.",
                config.SERVER_HOST,
                config.SERVER_PORT,
            )
            self._shutdown_requested.set()
            self._server.should_exit = True
            icon.stop()
            return

        icon.visible = True
        icon.update_menu()
        logger.info("NAIrelay started successfully.")

    def run(self) -> None:
        try:
            self._icon.run(setup=self._start_server)
        finally:
            self._shutdown_requested.set()
            self._server.should_exit = True
            if self._server_thread.is_alive():
                self._server_thread.join(timeout=SHUTDOWN_TIMEOUT_SECONDS)
            if self._server_thread.is_alive():
                logger.warning("The server did not stop within the shutdown timeout.")
            else:
                logger.info("NAIrelay stopped.")


if __name__ == "__main__":
    TrayApplication().run()
